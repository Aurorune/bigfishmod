package net.aurorune.bigfishmod.client.gui;

import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, "bigfishmod");

    public static final RegistryObject<MenuType<FishBoxMenu>> FISH_BOX_MENU =
            MENUS.register("fish_box", () -> IForgeMenuType.create(ModMenuTypes::createFishBoxMenu));
    private static FishBoxMenu createFishBoxMenu(int containerId, Inventory inv, FriendlyByteBuf data) {
        BlockPos pos = data.readBlockPos();
        Level level = inv.player.level();
        BlockEntity blockEntity = level.getBlockEntity(pos);

        if (blockEntity instanceof FishBoxBlockEntity fishBox) {
            return new FishBoxMenu(containerId, inv, fishBox);
        }
        throw new IllegalStateException("Block entity at " + pos + " is not a FishBox!");
    }
}