package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.aurorune.bigfishmod.entity.custom.TestFish;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

public class SchoolingGoal extends Goal {
    private int goalCheckTimer = 0; // 累计tick数，用于控制每5秒的判定
    private static final int GOAL_CHECK_INTERVAL = 80;
    private final AbstractCustomFish fish;
    private final double speedModifier;
    private final int checkInterval;
    private final int maxSchoolSize;
    private final double followRange;
    private final double cohesionFactor;
    private final double separationFactor;
    private final double alignmentFactor;
    private final double joinProbability;
    private final double leaveProbability;
    private int detectionCooldown = 0;
    private static final int DETECTION_INTERVAL = 20;
    private AbstractCustomFish leader;
    private int timeToRecalcPath;
    private int noLeaderTime;
    private Vec3 currentDirection = Vec3.ZERO;
    private static final boolean DEBUG = false; // 关闭调试输出

    public SchoolingGoal(AbstractCustomFish fish, double speedModifier, int checkInterval,
                         int maxSchoolSize, double followRange,
                         double cohesionFactor, double separationFactor,
                         double alignmentFactor, double joinProbability,
                         double leaveProbability) {
        this.fish = fish;
        this.speedModifier = speedModifier;
        this.checkInterval = checkInterval;
        this.maxSchoolSize = maxSchoolSize;
        this.followRange = followRange;
        this.cohesionFactor = cohesionFactor;
        this.separationFactor = separationFactor;
        this.alignmentFactor = alignmentFactor;
        this.joinProbability = joinProbability;
        this.leaveProbability = leaveProbability;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }
    
    @Override
    public boolean canUse() {
        // 每100 tick（约5秒）检查一次是否加入鱼群
        if (++goalCheckTimer < GOAL_CHECK_INTERVAL) {
            return false;
        }
        goalCheckTimer = 0;

        if (detectionCooldown > 0) {
            detectionCooldown--;
            return false;
        }
        detectionCooldown = DETECTION_INTERVAL;

        // 检查鱼群功能是否启用
        if (!fish.isSchoolingEnabled()) {
            return false;
        }

        // 有一定概率不加入鱼群，确保其他目标有机会执行
        if (fish.getRandom().nextFloat() < leaveProbability || !fish.isInWater()) {
            return false;
        }

        // 如果已经有领导者，继续跟随
        if (leader != null && leader.isAlive() &&
                fish.distanceToSqr(leader) < followRange * followRange * 4) {
            return true;
        }

        // 寻找附近的鱼群领导者
        if (fish.getRandom().nextFloat() < joinProbability) {
            List<AbstractCustomFish> nearbyFish = fish.level().getEntitiesOfClass(
                    AbstractCustomFish.class,
                    fish.getBoundingBox().inflate(followRange * 1.5),
                    f -> f != fish && f.isInWater() && f.isSchoolingEnabled() &&
                            (f.isSchoolLeader() || f.hasSchoolLeader())
            );

            if (!nearbyFish.isEmpty()) {
                // 优先加入已有鱼群
                for (AbstractCustomFish otherFish : nearbyFish) {
                    if (otherFish.isSchoolLeader() &&
                            otherFish.getSchoolSize() < maxSchoolSize) {
                        leader = otherFish;
                        leader.addToSchool(fish);
                        return true;
                    } else if (otherFish.hasSchoolLeader() &&
                            otherFish.getSchoolLeader().getSchoolSize() < maxSchoolSize) {
                        leader = otherFish.getSchoolLeader();
                        leader.addToSchool(fish);
                        return true;
                    }
                }
            } else if (fish.getRandom().nextFloat() < 0.05f && fish.getLevel() > 30) {
                // 没有找到鱼群，有小概率自己成为领导者（需要等级大于30）
                fish.setSchoolLeader(true);
                leader = fish;
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean canContinueToUse() {
        if (leader == null || !leader.isAlive() || !fish.isInWater() || !fish.isSchoolingEnabled()) {
            leaveSchool();
            return false;
        }

        // 有一定概率离开鱼群
        if (fish.getRandom().nextFloat() < leaveProbability) {
            leaveSchool();
            return false;
        }

        // 如果距离太远，离开鱼群
        if (fish.distanceToSqr(leader) > followRange * followRange * 9) {
            leaveSchool();
            return false;
        }

        return true;
    }

    @Override
    public void start() {
        timeToRecalcPath = 0;
        noLeaderTime = 0;
        fish.setInSchool(true);
    }

    @Override
    public void stop() {
        leaveSchool();
        fish.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (leader == null || !leader.isAlive()) {
            noLeaderTime++;
            if (noLeaderTime > 100) {
                leaveSchool();
                return;
            }

            // 尝试寻找新的领导者
            if (noLeaderTime % 20 == 0) {
                List<AbstractCustomFish> nearbyFish = fish.level().getEntitiesOfClass(
                        AbstractCustomFish.class,
                        fish.getBoundingBox().inflate(followRange),
                        f -> f != fish && f.isInWater() && f.isSchoolingEnabled() && f.isSchoolLeader()
                );

                if (!nearbyFish.isEmpty()) {
                    leader = nearbyFish.get(0);
                    leader.addToSchool(fish);
                    noLeaderTime = 0;
                }
            }
            return;
        }

        if (fish.isSchoolLeader()) {
            // 领导者定期选择新目标
            if (--timeToRecalcPath <= 0) {
                timeToRecalcPath = adjustedTickDelay(checkInterval);

                // 选择一个随机方向移动
                double angle = fish.getRandom().nextDouble() * Math.PI * 2;
                double distance = followRange * (0.5 + fish.getRandom().nextDouble());

                double targetX = fish.getX() + Math.cos(angle) * distance;
                double targetZ = fish.getZ() + Math.sin(angle) * distance;

                // 保持在水中的适当深度
                double waterSurfaceY = fish.getCachedWaterSurfaceY();
                double waterBottomY = getWaterBottomY();
                double targetY = waterBottomY + (waterSurfaceY - waterBottomY) *
                        (0.3 + fish.getRandom().nextDouble() * 0.4);

                fish.getNavigation().moveTo(targetX, targetY, targetZ, speedModifier * 1.2);
            }
        } else {
            Vec3 cohesion = calculateCohesion();
            Vec3 separation = calculateSeparation();
            Vec3 alignment = calculateAlignment();

            Vec3 combinedBehavior = new Vec3(
                    cohesion.x * cohesionFactor + separation.x * separationFactor + alignment.x * alignmentFactor,
                    (cohesion.y * cohesionFactor + separation.y * separationFactor + alignment.y * alignmentFactor) * 0.3,
                    cohesion.z * cohesionFactor + separation.z * separationFactor + alignment.z * alignmentFactor
            );

            if (combinedBehavior.length() > 0) {
                combinedBehavior = combinedBehavior.normalize();
            }

            // ✨ 平滑方向调整
            double smoothingFactor = 0.15; // 越小，转向越柔和
            currentDirection = currentDirection.scale(1 - smoothingFactor).add(combinedBehavior.scale(smoothingFactor));
            if (currentDirection.length() > 0) {
                currentDirection = currentDirection.normalize();
            }

            // 计算目标点
            Vec3 targetPos = fish.position().add(currentDirection.scale(followRange * 0.8));

            // 限制高度
            double waterSurfaceY = fish.getCachedWaterSurfaceY();
            double waterBottomY = getWaterBottomY();
            targetPos = new Vec3(
                    targetPos.x,
                    Mth.clamp(targetPos.y, waterBottomY + 0.5, waterSurfaceY - 0.5),
                    targetPos.z
            );

            // 持续移动，不是瞬移
            if (--timeToRecalcPath <= 0) {
                timeToRecalcPath = adjustedTickDelay(checkInterval);
                fish.getNavigation().moveTo(
                        targetPos.x,
                        targetPos.y,
                        targetPos.z,
                        speedModifier * (0.9f + fish.getRandom().nextFloat() * 0.2f)
                );
            }
        }}

    // 添加获取水面高度的方法

    // 添加获取水底高度的方法
    private double getWaterBottomY() {
        BlockPos bottom = findWaterBottom();
        return bottom != null ? bottom.getY() + 1.0 : fish.getY();
    }

    // 添加寻找水底的方法
    private BlockPos findWaterBottom() {
        BlockPos currentPos = fish.blockPosition();
        BlockPos bottomPos = currentPos;

        // 向下寻找非水方块
        while (bottomPos.getY() > fish.level().getMinBuildHeight() &&
                fish.level().getFluidState(bottomPos).is(FluidTags.WATER)) {
            bottomPos = bottomPos.below();
        }

        // 如果找到了底部，返回其上方的位置
        if (bottomPos.getY() > fish.level().getMinBuildHeight()) {
            return bottomPos.above();
        }

        return null;
    }

    private Vec3 calculateCohesion() {
        if (leader == null) return Vec3.ZERO;

        // 向鱼群中心移动，但减少垂直方向的权重
        Vec3 center = leader.position();
        Vec3 toCenter = center.subtract(fish.position());

        return new Vec3(
                toCenter.x * 0.8,
                toCenter.y * 0.3,
                toCenter.z * 0.8
        ).normalize();
    }

    private Vec3 calculateSeparation() {
        // 避免与鱼群中其他鱼碰撞，但减少垂直方向的分离
        Vec3 separation = Vec3.ZERO;
        int count = 0;

        for (AbstractCustomFish otherFish : leader.getSchoolMembers()) {
            if (otherFish == fish) continue;

            double distSqr = fish.distanceToSqr(otherFish);
            if (distSqr < 9.0) {
                Vec3 away = fish.position().subtract(otherFish.position());
                away = new Vec3(away.x * 1.2, away.y * 0.5, away.z * 1.2);
                separation = separation.add(away);
                count++;
            }
        }

        return count > 0 ? separation.scale(1.0 / count).normalize() : Vec3.ZERO;
    }

    private Vec3 calculateAlignment() {
        // 与鱼群移动方向对齐，但减少垂直方向的影响
        if (leader == null) return Vec3.ZERO;

        Vec3 movement = leader.getDeltaMovement();
        if (movement.length() > 0) {
            movement = movement.normalize();
            return new Vec3(movement.x, movement.y * 0.4, movement.z);
        }

        return Vec3.ZERO;
    }

    private void leaveSchool() {
        if (leader != null) {
            leader.removeFromSchool(fish);
        }
        fish.setInSchool(false);
        fish.setSchoolLeader(false);
        leader = null;
    }
}