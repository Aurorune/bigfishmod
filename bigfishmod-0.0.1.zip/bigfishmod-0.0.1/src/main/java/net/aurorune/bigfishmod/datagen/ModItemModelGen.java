package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraftforge.client.model.generators.ItemModelProvider;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.registries.ForgeRegistries;
//物品模型JSON文件生成
public class ModItemModelGen  extends ItemModelProvider {
    public static final String GENERATED = "item/generated";
    public static final String HANDHELD = "item/handheld";

    public ModItemModelGen(PackOutput output, ExistingFileHelper existingFileHelper){
        super(output,BigFishMod.MOD_ID,existingFileHelper);

    }


    @Override
    protected void registerModels() {
        itemGeneratedModel(ModItems.GOLDEN_SCALES.get(),resourceItem(itemName(ModItems.GOLDEN_SCALES.get())));
        itemGeneratedModel(ModItems.COLORFUL_SCALES.get(),resourceItem(itemName(ModItems.COLORFUL_SCALES.get())));
        itemGeneratedModel(ModItems.SILVER_SCALES.get(),resourceItem(itemName(ModItems.SILVER_SCALES.get())));
        itemGeneratedModel(ModItems.GRAPHITE.get(),resourceItem(itemName(ModItems.GRAPHITE.get())));
        itemGeneratedModel(ModItems.DUNKLEOSTEUS_CRUSHED_BONE.get(),resourceItem(itemName(ModItems.DUNKLEOSTEUS_CRUSHED_BONE.get())));
        itemGeneratedModel(ModItems.CARBON_FIBRE.get(),resourceItem(itemName(ModItems.CARBON_FIBRE.get())));
        itemGeneratedModel(ModItems.CORN.get(),resourceItem(itemName(ModItems.CORN.get())));
        itemGeneratedModel(ModItems.CORN_SEED.get(),resourceItem(itemName(ModItems.CORN_SEED.get())));
        itemGeneratedModel(ModItems.BELUGA_STURGEON_MEAT.get(),resourceItem(itemName(ModItems.BELUGA_STURGEON_MEAT.get())));
        itemGeneratedModel(ModItems.BLACK_CAVIAR.get(),resourceItem(itemName(ModItems.BLACK_CAVIAR.get())));
        itemGeneratedModel(ModItems.COOKED_STURGEON_MEAT.get(),resourceItem(itemName(ModItems.COOKED_STURGEON_MEAT.get())));
        itemGeneratedModel(ModItems.COOKED_PERCH_FILLET.get(),resourceItem(itemName(ModItems.COOKED_PERCH_FILLET.get())));
        itemGeneratedModel(ModItems.COOKED_BULK_FISH_MEAT.get(),resourceItem(itemName(ModItems.COOKED_BULK_FISH_MEAT.get())));
        itemGeneratedModel(ModItems.COOKED_PREMIUM_TUNA_MEAT.get(),resourceItem(itemName(ModItems.COOKED_PREMIUM_TUNA_MEAT.get())));
        itemGeneratedModel(ModItems.COOKED_SAILFISH_STEAK.get(),resourceItem(itemName(ModItems.COOKED_SAILFISH_STEAK.get())));
        itemGeneratedModel(ModItems.FISH_FILLET_A.get(),resourceItem(itemName(ModItems.FISH_FILLET_A.get())));
        itemGeneratedModel(ModItems.COOKED_FISH_FILLET_A.get(),resourceItem(itemName(ModItems.COOKED_FISH_FILLET_A.get())));
        itemGeneratedModel(ModItems.FISH_FILLET_B.get(),resourceItem(itemName(ModItems.FISH_FILLET_B.get())));
        itemGeneratedModel(ModItems.COOKED_FISH_FILLET_B.get(),resourceItem(itemName(ModItems.COOKED_FISH_FILLET_B.get())));
        itemGeneratedModel(ModItems.EMPTY_WOODEN_BUCKET.get(),resourceItem(itemName(ModItems.EMPTY_WOODEN_BUCKET.get())));
        itemGeneratedModel(ModItems.WATER_WOODEN_BUCKET.get(),resourceItem(itemName(ModItems.WATER_WOODEN_BUCKET.get())));


        itemGeneratedModel(ModItems.LUCKY_STAR.get(),resourceItem(itemName(ModItems.LUCKY_STAR.get())));
        itemGeneratedModel(ModItems.PERCH_FILLET.get(),resourceItem(itemName(ModItems.PERCH_FILLET.get())));
        itemGeneratedModel(ModItems.PUTRID_GLAND.get(),resourceItem(itemName(ModItems.PUTRID_GLAND.get())));
        itemGeneratedModel(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(),resourceItem(itemName(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get())));
        itemGeneratedModel(ModItems.ANCIENT_GASTROLITH.get(),resourceItem(itemName(ModItems.ANCIENT_GASTROLITH.get())));
        itemGeneratedModel(ModItems.BULK_FISH_MEAT.get(),resourceItem(itemName(ModItems.BULK_FISH_MEAT.get())));
        itemGeneratedModel(ModItems.CONCEBTRATED_PHEROMONER.get(),resourceItem(itemName(ModItems.CONCEBTRATED_PHEROMONER.get())));
        itemGeneratedModel(ModItems.ACERATED_SEAWEED.get(),resourceItem(itemName(ModItems.ACERATED_SEAWEED.get())));
        itemGeneratedModel(ModItems.FISH_OIL.get(),resourceItem(itemName(ModItems.FISH_OIL.get())));
        itemGeneratedModel(ModItems.FISHBOOK.get(),resourceItem(itemName(ModItems.FISHBOOK.get())));
        itemGeneratedModel(ModItems.MEAT_FEED.get(),resourceItem(itemName(ModItems.MEAT_FEED.get())));
        itemGeneratedModel(ModItems.OCEAN_GEM.get(),resourceItem(itemName(ModItems.OCEAN_GEM.get())));
        itemGeneratedModel(ModItems.PRIME_TUNA_MEAT.get(),resourceItem(itemName(ModItems.PRIME_TUNA_MEAT.get())));
        itemGeneratedModel(ModItems.ROE.get(),resourceItem(itemName(ModItems.ROE.get())));
        itemGeneratedModel(ModItems.SAILFISH_STEAK.get(),resourceItem(itemName(ModItems.SAILFISH_STEAK.get())));
        itemGeneratedModel(ModItems.SEA_BREEZE_ESSENCE.get(),resourceItem(itemName(ModItems.SEA_BREEZE_ESSENCE.get())));
        itemGeneratedModel(ModItems.SHARP_FISH_TOOTH.get(),resourceItem(itemName(ModItems.SHARP_FISH_TOOTH.get())));
        itemGeneratedModel(ModItems.SWORDFISH_BILL.get(),resourceItem(itemName(ModItems.SWORDFISH_BILL.get())));
        itemGeneratedModel(ModItems.VEGETARIAN_FEED.get(),resourceItem(itemName(ModItems.VEGETARIAN_FEED.get())));
        itemGeneratedModel(ModItems.WATER_DROPLET.get(),resourceItem(itemName(ModItems.WATER_DROPLET.get())));

        itemRotatedRightModel(ModItems.IRON_FISHING_ROD.get(),resourceItem(itemName(ModItems.IRON_FISHING_ROD.get())));
        itemRotatedRightModel(ModItems.GOLD_FISHING_ROD.get(),resourceItem(itemName(ModItems.GOLD_FISHING_ROD.get())));
        itemRotatedRightModel(ModItems.DIAMOND_FISHING_ROD.get(),resourceItem(itemName(ModItems.DIAMOND_FISHING_ROD.get())));
        itemRotatedRightModel(ModItems.CARBON_FIBER_FISHING_ROD.get(),resourceItem(itemName(ModItems.CARBON_FIBER_FISHING_ROD.get())));
        itemGeneratedModel(ModItems.TESTFISH.get(),resourceItem(itemName(ModItems.TESTFISH_ITEM.get())));
        itemGeneratedModel(ModItems.TESTFISH_ITEM.get(),resourceItem(itemName(ModItems.TESTFISH_ITEM.get())));
        itemGeneratedModel(ModItems.TESTFISH_BUCKET.get(),resourceItem(itemName(ModItems.TESTFISH_BUCKET.get())));
        itemGeneratedModel(ModItems.TEXTFISH_WOODEN.get(),resourceItem(itemName(ModItems.TEXTFISH_WOODEN.get())));
        itemGeneratedModel(ModItems.LOACH.get(),resourceItem(itemName(ModItems.LOACH_ITEM.get())));
        itemGeneratedModel(ModItems.LOACH_ITEM.get(),resourceItem(itemName(ModItems.LOACH_ITEM.get())));
        itemGeneratedModel(ModItems.LOACH_BUCKET.get(),resourceItem(itemName(ModItems.LOACH_BUCKET.get())));
        itemGeneratedModel(ModItems.LOACH_WOODEN.get(),resourceItem(itemName(ModItems.LOACH_WOODEN.get())));
        itemGeneratedModel(ModItems.MINNOW.get(),resourceItem(itemName(ModItems.MINNOW_ITEM.get())));
        itemGeneratedModel(ModItems.MINNOW_ITEM.get(),resourceItem(itemName(ModItems.MINNOW_ITEM.get())));
        itemGeneratedModel(ModItems.MINNOW_BUCKET.get(),resourceItem(itemName(ModItems.MINNOW_BUCKET.get())));
        itemGeneratedModel(ModItems.MINNOW_WOODEN.get(),resourceItem(itemName(ModItems.MINNOW_WOODEN.get())));
        itemGeneratedModel(ModItems.PIRANHA.get(),resourceItem(itemName(ModItems.PIRANHA_ITEM.get())));
        itemGeneratedModel(ModItems.PIRANHA_ITEM.get(),resourceItem(itemName(ModItems.PIRANHA_ITEM.get())));
        itemGeneratedModel(ModItems.PIRANHA_BUCKET.get(),resourceItem(itemName(ModItems.PIRANHA_BUCKET.get())));
        itemGeneratedModel(ModItems.PIRANHA_WOODEN.get(),resourceItem(itemName(ModItems.PIRANHA_WOODEN.get())));
        itemGeneratedModel(ModItems.SARDINE.get(),resourceItem(itemName(ModItems.SARDINE_ITEM.get())));
        itemGeneratedModel(ModItems.SARDINE_ITEM.get(),resourceItem(itemName(ModItems.SARDINE_ITEM.get())));
        itemGeneratedModel(ModItems.SARDINE_BUCKET.get(),resourceItem(itemName(ModItems.SARDINE_BUCKET.get())));
        itemGeneratedModel(ModItems.SARDINE_WOODEN.get(),resourceItem(itemName(ModItems.SARDINE_WOODEN.get())));
        itemGeneratedModel(ModItems.PLECOSTOMUS.get(),resourceItem(itemName(ModItems.PLECOSTOMUS_ITEM.get())));
        itemGeneratedModel(ModItems.PLECOSTOMUS_ITEM.get(),resourceItem(itemName(ModItems.PLECOSTOMUS_ITEM.get())));
        itemGeneratedModel(ModItems.PLECOSTOMUS_BUCKET.get(),resourceItem(itemName(ModItems.PLECOSTOMUS_BUCKET.get())));
        itemGeneratedModel(ModItems.PLECOSTOMUS_WOODEN.get(),resourceItem(itemName(ModItems.PLECOSTOMUS_WOODEN.get())));
        itemGeneratedModel(ModItems.BELUGA_STURGEON.get(),resourceItem(itemName(ModItems.BELUGA_STURGEON_ITEM.get())));
        itemGeneratedModel(ModItems.BELUGA_STURGEON_ITEM.get(),resourceItem(itemName(ModItems.BELUGA_STURGEON_ITEM.get())));
        itemGeneratedModel(ModItems.BELUGA_STURGEON_BUCKET.get(),resourceItem(itemName(ModItems.BELUGA_STURGEON_BUCKET.get())));
        itemGeneratedModel(ModItems.BELUGA_STURGEON_WOODEN.get(),resourceItem(itemName(ModItems.BELUGA_STURGEON_WOODEN.get())));
        itemGeneratedModel(ModItems.NILE_PERCH.get(),resourceItem(itemName(ModItems.NILE_PERCH_ITEM.get())));
        itemGeneratedModel(ModItems.NILE_PERCH_ITEM.get(),resourceItem(itemName(ModItems.NILE_PERCH_ITEM.get())));
        itemGeneratedModel(ModItems.NILE_PERCH_BUCKET.get(),resourceItem(itemName(ModItems.NILE_PERCH_BUCKET.get())));
        itemGeneratedModel(ModItems.NILE_PERCH_WOODEN.get(),resourceItem(itemName(ModItems.NILE_PERCH_WOODEN.get())));
        itemGeneratedModel(ModItems.MEKONG_GIANT_CATFISH.get(),resourceItem(itemName(ModItems.MEKONG_GIANT_CATFISH_ITEM.get())));
        itemGeneratedModel(ModItems.MEKONG_GIANT_CATFISH_ITEM.get(),resourceItem(itemName(ModItems.MEKONG_GIANT_CATFISH_ITEM.get())));
        itemGeneratedModel(ModItems.MEKONG_GIANT_CATFISH_BUCKET.get(),resourceItem(itemName(ModItems.MEKONG_GIANT_CATFISH_BUCKET.get())));
        itemGeneratedModel(ModItems.MEKONG_GIANT_CATFISH_WOODEN.get(),resourceItem(itemName(ModItems.MEKONG_GIANT_CATFISH_WOODEN.get())));
        itemGeneratedModel(ModItems.TILAPIA.get(),resourceItem(itemName(ModItems.TILAPIA_ITEM.get())));
        itemGeneratedModel(ModItems.TILAPIA_ITEM.get(),resourceItem(itemName(ModItems.TILAPIA_ITEM.get())));
        itemGeneratedModel(ModItems.TILAPIA_BUCKET.get(),resourceItem(itemName(ModItems.TILAPIA_BUCKET.get())));
        itemGeneratedModel(ModItems.TILAPIA_WOODEN.get(),resourceItem(itemName(ModItems.TILAPIA_WOODEN.get())));
        itemGeneratedModel(ModItems.GUPPY.get(),resourceItem(itemName(ModItems.GUPPY_ITEM.get())));
        itemGeneratedModel(ModItems.GUPPY_ITEM.get(),resourceItem(itemName(ModItems.GUPPY_ITEM.get())));
        itemGeneratedModel(ModItems.GUPPY_BUCKET.get(),resourceItem(itemName(ModItems.GUPPY_BUCKET.get())));
        itemGeneratedModel(ModItems.GUPPY_WOODEN.get(),resourceItem(itemName(ModItems.GUPPY_WOODEN.get())));
        itemGeneratedModel(ModItems.SAILFISH.get(),resourceItem(itemName(ModItems.SAILFISH_ITEM.get())));
        itemGeneratedModel(ModItems.SAILFISH_ITEM.get(),resourceItem(itemName(ModItems.SAILFISH_ITEM.get())));
        itemGeneratedModel(ModItems.SAILFISH_BUCKET.get(),resourceItem(itemName(ModItems.SAILFISH_BUCKET.get())));
        itemGeneratedModel(ModItems.SAILFISH_WOODEN.get(),resourceItem(itemName(ModItems.SAILFISH_WOODEN.get())));
        itemGeneratedModel(ModItems.HADDOCK.get(),resourceItem(itemName(ModItems.HADDOCK_ITEM.get())));
        itemGeneratedModel(ModItems.HADDOCK_ITEM.get(),resourceItem(itemName(ModItems.HADDOCK_ITEM.get())));
        itemGeneratedModel(ModItems.HADDOCK_BUCKET.get(),resourceItem(itemName(ModItems.HADDOCK_BUCKET.get())));
        itemGeneratedModel(ModItems.HADDOCK_WOODEN.get(),resourceItem(itemName(ModItems.HADDOCK_WOODEN.get())));
        itemGeneratedModel(ModItems.NORTHERN_PIKE.get(),resourceItem(itemName(ModItems.NORTHERN_PIKE_ITEM.get())));
        itemGeneratedModel(ModItems.NORTHERN_PIKE_ITEM.get(),resourceItem(itemName(ModItems.NORTHERN_PIKE_ITEM.get())));
        itemGeneratedModel(ModItems.NORTHERN_PIKE_BUCKET.get(),resourceItem(itemName(ModItems.NORTHERN_PIKE_BUCKET.get())));
        itemGeneratedModel(ModItems.NORTHERN_PIKE_WOODEN.get(),resourceItem(itemName(ModItems.NORTHERN_PIKE_WOODEN.get())));
        itemGeneratedModel(ModItems.SIAMESE_FIGHTING_FISH.get(),resourceItem(itemName(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get())));
        itemGeneratedModel(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get(),resourceItem(itemName(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get())));
        itemGeneratedModel(ModItems.SIAMESE_FIGHTING_FISH_BUCKET.get(),resourceItem(itemName(ModItems.SIAMESE_FIGHTING_FISH_BUCKET.get())));
        itemGeneratedModel(ModItems.SIAMESE_FIGHTING_FISH_WOODEN.get(),resourceItem(itemName(ModItems.SIAMESE_FIGHTING_FISH_WOODEN.get())));
        itemGeneratedModel(ModItems.LANTERNFISH.get(),resourceItem(itemName(ModItems.LANTERNFISH_ITEM.get())));
        itemGeneratedModel(ModItems.LANTERNFISH_ITEM.get(),resourceItem(itemName(ModItems.LANTERNFISH_ITEM.get())));
        itemGeneratedModel(ModItems.LANTERNFISH_BUCKET.get(),resourceItem(itemName(ModItems.LANTERNFISH_BUCKET.get())));
        itemGeneratedModel(ModItems.LANTERNFISH_WOODEN.get(),resourceItem(itemName(ModItems.LANTERNFISH_WOODEN.get())));
        itemGeneratedModel(ModItems.ATLANTIC_BLUEFIN_TUNA.get(),resourceItem(itemName(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get())));
        itemGeneratedModel(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get(),resourceItem(itemName(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get())));
        itemGeneratedModel(ModItems.ATLANTIC_BLUEFIN_TUNA_BUCKET.get(),resourceItem(itemName(ModItems.ATLANTIC_BLUEFIN_TUNA_BUCKET.get())));
        itemGeneratedModel(ModItems.ATLANTIC_BLUEFIN_TUNA_WOODEN.get(),resourceItem(itemName(ModItems.ATLANTIC_BLUEFIN_TUNA_WOODEN.get())));
        itemGeneratedModel(ModItems.GRASS_CARP.get(),resourceItem(itemName(ModItems.GRASS_CARP_ITEM.get())));
        itemGeneratedModel(ModItems.GRASS_CARP_ITEM.get(),resourceItem(itemName(ModItems.GRASS_CARP_ITEM.get())));
        itemGeneratedModel(ModItems.GRASS_CARP_BUCKET.get(),resourceItem(itemName(ModItems.GRASS_CARP_BUCKET.get())));
        itemGeneratedModel(ModItems.GRASS_CARP_WOODEN.get(),resourceItem(itemName(ModItems.GRASS_CARP_WOODEN.get())));
        itemGeneratedModel(ModItems.ARCHER_FISH.get(),resourceItem(itemName(ModItems.ARCHER_FISH_ITEM.get())));
        itemGeneratedModel(ModItems.ARCHER_FISH_ITEM.get(),resourceItem(itemName(ModItems.ARCHER_FISH_ITEM.get())));
        itemGeneratedModel(ModItems.ARCHER_FISH_BUCKET.get(),resourceItem(itemName(ModItems.ARCHER_FISH_BUCKET.get())));
        itemGeneratedModel(ModItems.ARCHER_FISH_WOODEN.get(),resourceItem(itemName(ModItems.ARCHER_FISH_WOODEN.get())));
        registerWoodenBucketModel();

    }
    private void registerWoodenBucketModel() {
        // 空木桶模型
        ModelFile emptyModel = withExistingParent("wooden_bucket_empty", GENERATED)
                .texture("layer0", resourceItem("empty_wooden_bucket"));

        // 有水木桶模型
        ModelFile waterModel = withExistingParent("wooden_bucket_water", GENERATED)
                .texture("layer0", resourceItem("water_wooden_bucket"));

        // 主木桶模型，使用 override 根据 predicate 切换
        withExistingParent(itemName(ModItems.WOODEN_BUCKET.get()), "item/generated")
                .texture("layer0", resourceItem("empty_wooden_bucket")) // 默认纹理
                .override()
                .predicate(ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "has_water"), 1.0f)
                .model(waterModel)
                .end();
    }
    private ResourceLocation resourceItem(String path) {
        return ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"item/"+path);
    }

    private void itemGeneratedModel(Item item, ResourceLocation texture) {
        withExistingParent(itemName(item),GENERATED).texture("layer0",texture);
    }
    // 新增：镜像物品模型方法
    private void itemRotatedRightModel(Item item, ResourceLocation texture) {
        withExistingParent(itemName(item), GENERATED)
                .texture("layer0", texture)
                .transforms()
                .transform(ItemDisplayContext.THIRD_PERSON_RIGHT_HAND)
                .rotation(0, 90, 0)
                .end()
                .transform(ItemDisplayContext.THIRD_PERSON_LEFT_HAND)
                .rotation(0, 90, 0)
                .end()
                .transform(ItemDisplayContext.FIRST_PERSON_RIGHT_HAND)
                .rotation(0, 90, 0)
                .translation(1, 3, 1) // 调整第一人称右手位置
                .end()
                .transform(ItemDisplayContext.FIRST_PERSON_LEFT_HAND)
                .rotation(0, 90, 0)
                .end();
    }

    private String itemName(Item item) {return ForgeRegistries.ITEMS.getKey(item).getPath();
    }
}
