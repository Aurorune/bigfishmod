package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.custom.CronCropBlock;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.data.loot.packs.VanillaBlockLoot;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.ApplyBonusCount;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;
import java.util.stream.Collectors;
//掉落物设定
public class ModLootTableGen  extends VanillaBlockLoot {
    @Override
    protected void generate (){
        dropSelf(ModBlocks.GRAPHITE_BLOCK.get());
        dropSelf(ModBlocks.FISH_STAND.get());
        add(ModBlocks.FISH_BOX.get(), noDrop());
        dropSelf(ModBlocks.TROPHY_BASE.get());

        add(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get(), this::creategraphoteOreDrops);
        add(ModBlocks.GRAPHITE_ORE.get(), this::creategraphoteOreDrops);

        add(ModBlocks.CORN_CROP.get(),pBlock->{
            LootItemCondition.Builder  matureCondition= LootItemBlockStatePropertyCondition
                    .hasBlockStateProperties(ModBlocks.CORN_CROP.get())
                    .setProperties(StatePropertiesPredicate.Builder.properties()
                            .hasProperty(CronCropBlock.AGE, 6));
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            // 成熟作物掉落玉米（受时运影响）
                            .add(LootItem.lootTableItem(ModItems.CORN.get())
                                    .when(matureCondition)
                                    .apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 3.0F))) // 基础数量
                                    .apply(ApplyBonusCount.addBonusBinomialDistributionCount(
                                            Enchantments.BLOCK_FORTUNE, 0.57F, 2))));
        });
    }

    //copy小麦
    LootItemCondition.Builder cornCropConditionBuiler= LootItemBlockStatePropertyCondition
            .hasBlockStateProperties(ModBlocks.CORN_CROP.get())
            .setProperties(StatePropertiesPredicate.Builder.properties()
                    .hasProperty(CronCropBlock.AGE, 6));

    //得到石墨
    protected LootTable.Builder creategraphoteOreDrops(Block pBlock) {
        return createSilkTouchDispatchTable(pBlock,
                this.applyExplosionDecay(pBlock,
                        LootItem.lootTableItem(ModItems.GRAPHITE.get())
                                .apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0F, 4.0F)))
                                .apply(ApplyBonusCount.addUniformBonusCount(Enchantments.BLOCK_FORTUNE))));
    }
//得到原方块
    @Override
    protected Iterable<Block> getKnownBlocks(){
        return ForgeRegistries.BLOCKS.getEntries().stream()
                .filter(e->e.getKey().location().getNamespace().equals(BigFishMod.MOD_ID))
                .map(Map.Entry::getValue)
                .collect(Collectors.toList());
    }
}
