package net.aurorune.bigfishmod.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FishBoxModel extends GeoModel<FishBoxBlockEntity> {
    @Override
    public ResourceLocation getModelResource(FishBoxBlockEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/fish_box.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(FishBoxBlockEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/block/fish_box.png");
    }

    @Override
    public ResourceLocation getAnimationResource(FishBoxBlockEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/fish_box.animation.json");
    }
}