package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.aurorune.bigfishmod.datagen.provider.ModTags;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.advancements.critereon.InventoryChangeTrigger;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;

import java.util.List;
import java.util.function.Consumer;
//合成表
public class ModRecipesGen extends RecipeProvider {

    public ModRecipesGen (PackOutput packOutput){
        super(packOutput);
    }

    @Override
    protected void buildRecipes(Consumer<FinishedRecipe> pWriter) {

        ShapedRecipeBuilder.shaped(RecipeCategory.MISC, ModBlocks.GRAPHITE_BLOCK.get())
                .pattern("###")
                .pattern("###")
                .pattern("###")
                .define('#', ModItems.GRAPHITE.get())
                .unlockedBy("has_graphite",has(ModItems.GRAPHITE.get()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"graphite_from_items"));

        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, ModItems.GRAPHITE.get(),9)
                .requires(ModBlocks.GRAPHITE_BLOCK.get())
                .unlockedBy("has_graphite_block", has(ModBlocks.GRAPHITE_BLOCK.get()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"graphite_block_from_items"));

        ShapelessRecipeBuilder.shapeless(RecipeCategory.FOOD, ModItems.CORN_SEED.get(),4)
                .requires(ModItems.CORN.get())
                .group("bigfish")
                .unlockedBy("has_cron", has(ModItems.CORN.get()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"cron_from_items"));
//鱼竿
        ShapedRecipeBuilder.shaped(RecipeCategory.TOOLS, ModItems.CARBON_FIBER_FISHING_ROD.get())
                .pattern("  #")
                .pattern(" #X")
                .pattern("Y X")
                .define('#', ModItems.CARBON_FIBRE.get())
                .define('X', Items.STRING)
                .define('Y',Items.STICK)
                .unlockedBy("has_carbon_fibre", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(ModItems.CARBON_FIBRE.get()).build()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"carbon_fibre_from_items"));

        ShapedRecipeBuilder.shaped(RecipeCategory.TOOLS, ModItems.IRON_FISHING_ROD.get())
                .pattern("  #")
                .pattern(" #X")
                .pattern("Y X")
                .define('#', Items.IRON_INGOT)
                .define('X', Items.STRING)
                .define('Y',Items.STICK)
                .unlockedBy("has_iron_ingot", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.IRON_INGOT).build()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"iron_fishing_rod_from_items"));

        ShapedRecipeBuilder.shaped(RecipeCategory.TOOLS, ModItems.GOLD_FISHING_ROD.get())
                .pattern("  #")
                .pattern(" #X")
                .pattern("Y X")
                .define('#', Items.GOLD_INGOT)
                .define('X', Items.STRING)
                .define('Y',Items.STICK)
                .unlockedBy("has_gold_ingot", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.GOLD_INGOT).build()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"gold_fishing_rod_from_items"));

        ShapedRecipeBuilder.shaped(RecipeCategory.TOOLS, ModItems.DIAMOND_FISHING_ROD.get())
                .pattern("  #")
                .pattern(" #X")
                .pattern("Y X")
                .define('#', Items.DIAMOND)
                .define('X', Items.STRING)
                .define('Y',Items.STICK)
                .unlockedBy("has_diamond", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.DIAMOND).build()))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"diamond_fishing_rod_from_items"));

        ShapedRecipeBuilder.shaped(RecipeCategory.TOOLS, ModItems.WOODEN_BUCKET.get())
                .pattern("# #")
                .pattern("# #")
                .pattern(" # ")
                .define('#', ItemTags.PLANKS)
                .unlockedBy("has_planks", has(ItemTags.PLANKS))
                .save(pWriter,ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID,"wooden_bucket_from_items"));
        // 1. PUTRID_GLAND合成CONCENTRATED_PHEROMONER（腐烂腺体制作浓缩信息素）
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, ModItems.CONCEBTRATED_PHEROMONER.get(), 16)
                .requires(ModItems.PUTRID_GLAND.get())
                .requires(Items.SPIDER_EYE)
                .requires(Items.FERMENTED_SPIDER_EYE)
                .requires(Items.BONE_MEAL)
                .unlockedBy("has_putrid_gland", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(ModItems.PUTRID_GLAND.get()).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "concentrated_pheromoner_biological"));

// 2. SHARP_FISH_TOOTH合成箭（锋利鱼牙制作箭矢）
        ShapedRecipeBuilder.shaped(RecipeCategory.COMBAT, Items.ARROW, 4)
                .pattern("T  ")
                .pattern(" S " )
                .pattern("  F")
                .define('T', ModItems.SHARP_FISH_TOOTH.get())
                .define('S', Items.STICK)
                .define('F', Items.FEATHER)
                .unlockedBy("has_sharp_fish_tooth", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(ModItems.SHARP_FISH_TOOTH.get()).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "arrow_from_fish_tooth"));

// 3. 合成FISH_STAND（鱼架）
        ShapedRecipeBuilder.shaped(RecipeCategory.DECORATIONS, ModBlocks.FISH_STAND.get())
                .pattern("TTT")
                .pattern("P P")
                .pattern("PPP")
                .define('P', Items.CLAY)
                .define('T', ItemTags.PLANKS)
                .unlockedBy("has_terracotta", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.TERRACOTTA).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "fish_stand_terracotta"));

// 4. 合成FISH_BOX（鱼箱）
        ShapedRecipeBuilder.shaped(RecipeCategory.MISC, ModBlocks.FISH_BOX.get())
                .pattern("GBG")
                .pattern("WCW")
                .pattern("GIG")
                .define('G', Items.LIGHT_BLUE_WOOL)
                .define('B', Items.DIAMOND)
                .define('W', ModItems.CARBON_FIBRE.get())
                .define('C', Items.CHEST)
                .define('I', Items.IRON_INGOT)
                .unlockedBy("has_golden_scales", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(ModItems.CARBON_FIBRE.get()).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "fish_box_luxury"));

// 5. 合成VEGETARIAN_FEED（素食饲料）
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, ModItems.VEGETARIAN_FEED.get(), 2)
                .requires(Items.PAPER)
                .requires(ModTags.Items.VEGETARIAN_FOOD)
                .requires(ModTags.Items.VEGETARIAN_FOOD)
                .unlockedBy("has_paper", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.PAPER).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "vegetarian_feed_crops"));

// 5. 合成MEAT_FEED（肉食饲料）
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, ModItems.MEAT_FEED.get(), 2)
                .requires(Items.PAPER)
                .requires(ModTags.Items.MEAT_FOOD)
                .requires(ModTags.Items.MEAT_FOOD)
                .unlockedBy("has_beef", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.BEEF).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "meat_feed_recipe"));


        ShapedRecipeBuilder.shaped(RecipeCategory.DECORATIONS, ModItems.TROPHY_BASE.get())
                .pattern("SCS")
                .pattern("CBC")
                .pattern("SCS")
                .define('C', Items.COPPER_INGOT)
                .define('B', Items.ITEM_FRAME)
                .define('S', Items.GLASS)
                .unlockedBy("has_copper_ingot", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.COPPER_INGOT).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "trophy_base_copper"));
// 7. 合成FISHBOOK（渔业手册）
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, ModItems.FISHBOOK.get())
                .requires(Items.BOOK)
                .requires(Items.COD)
                .unlockedBy("has_book", InventoryChangeTrigger.TriggerInstance.hasItems(
                        ItemPredicate.Builder.item().of(Items.BOOK).build()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "fishbook_recipe"));
//熔炉方法
        oreSmelting(pWriter, List.of(ModItems.GRAPHITE.get()),RecipeCategory.MISC,ModItems.CARBON_FIBRE.get(),0.7F,100, BigFishMod.MOD_ID);
        oreBlasting(pWriter, List.of(ModItems.GRAPHITE.get()),RecipeCategory.MISC,ModItems.CARBON_FIBRE.get(),0.7F,50, BigFishMod.MOD_ID);
// 熔炉配方 - 鱼肉烹饪
        oreSmelting(pWriter, List.of(ModItems.BELUGA_STURGEON_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_STURGEON_MEAT.get(), 0.35F, 200, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.PERCH_FILLET.get()), RecipeCategory.FOOD, ModItems.COOKED_PERCH_FILLET.get(), 0.35F, 200, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.BULK_FISH_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_BULK_FISH_MEAT.get(), 0.5F, 250, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.PRIME_TUNA_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_PREMIUM_TUNA_MEAT.get(), 0.6F, 300, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.SAILFISH_STEAK.get()), RecipeCategory.FOOD, ModItems.COOKED_SAILFISH_STEAK.get(), 0.5F, 250, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.FISH_FILLET_A.get()), RecipeCategory.FOOD, ModItems.COOKED_FISH_FILLET_A.get(), 0.3F, 180, BigFishMod.MOD_ID);
        oreSmelting(pWriter, List.of(ModItems.FISH_FILLET_B.get()), RecipeCategory.FOOD, ModItems.COOKED_FISH_FILLET_B.get(), 0.4F, 220, BigFishMod.MOD_ID);

// 烟熏炉配方 - 鱼肉烹饪（更快，更多经验）
        oreSmoking(pWriter, List.of(ModItems.BELUGA_STURGEON_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_STURGEON_MEAT.get(), 0.35F, 100, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.PERCH_FILLET.get()), RecipeCategory.FOOD, ModItems.COOKED_PERCH_FILLET.get(), 0.35F, 100, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.BULK_FISH_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_BULK_FISH_MEAT.get(), 0.5F, 125, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.PRIME_TUNA_MEAT.get()), RecipeCategory.FOOD, ModItems.COOKED_PREMIUM_TUNA_MEAT.get(), 0.6F, 150, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.SAILFISH_STEAK.get()), RecipeCategory.FOOD, ModItems.COOKED_SAILFISH_STEAK.get(), 0.5F, 125, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.FISH_FILLET_A.get()), RecipeCategory.FOOD, ModItems.COOKED_FISH_FILLET_A.get(), 0.3F, 90, BigFishMod.MOD_ID);
        oreSmoking(pWriter, List.of(ModItems.FISH_FILLET_B.get()), RecipeCategory.FOOD, ModItems.COOKED_FISH_FILLET_B.get(), 0.4F, 110, BigFishMod.MOD_ID);


        addFishRecipes(pWriter, ModItems.TESTFISH.get(), ModItems.TESTFISH_BUCKET.get(), "textfish");
        addFishRecipes(pWriter, ModItems.LOACH.get(), ModItems.LOACH_BUCKET.get(), "loach");
        addFishRecipes(pWriter, ModItems.MINNOW.get(), ModItems.MINNOW_BUCKET.get(), "minnow");
        addFishRecipes(pWriter, ModItems.PIRANHA.get(), ModItems.PIRANHA_BUCKET.get(), "piranha");
        addFishRecipes(pWriter, ModItems.SARDINE.get(), ModItems.SARDINE_BUCKET.get(), "sardine");
        addFishRecipes(pWriter, ModItems.PLECOSTOMUS.get(), ModItems.PLECOSTOMUS_BUCKET.get(), "plecostomus");
        addFishRecipes(pWriter, ModItems.BELUGA_STURGEON.get(), ModItems.BELUGA_STURGEON_BUCKET.get(), "beluga_sturgeon");
        addFishRecipes(pWriter, ModItems.NILE_PERCH.get(), ModItems.NILE_PERCH_BUCKET.get(), "nile_perch");
        addFishRecipes(pWriter, ModItems.MEKONG_GIANT_CATFISH.get(), ModItems.MEKONG_GIANT_CATFISH_BUCKET.get(), "mekong_giant_catfish");
        addFishRecipes(pWriter, ModItems.TILAPIA.get(), ModItems.TILAPIA_BUCKET.get(), "tilapia");
        addFishRecipes(pWriter, ModItems.GUPPY.get(), ModItems.GUPPY_BUCKET.get(), "guppy");
        addFishRecipes(pWriter, ModItems.SAILFISH.get(), ModItems.SAILFISH_BUCKET.get(), "sailfish");
        addFishRecipes(pWriter, ModItems.HADDOCK.get(), ModItems.HADDOCK_BUCKET.get(), "haddock");
        addFishRecipes(pWriter, ModItems.NORTHERN_PIKE.get(), ModItems.NORTHERN_PIKE_BUCKET.get(), "northern_pike");
        addFishRecipes(pWriter, ModItems.SIAMESE_FIGHTING_FISH.get(), ModItems.SIAMESE_FIGHTING_FISH_BUCKET.get(), "siamese_fighting_fish");
        addFishRecipes(pWriter, ModItems.LANTERNFISH.get(), ModItems.LANTERNFISH_BUCKET.get(), "lanternfish");
        addFishRecipes(pWriter, ModItems.ATLANTIC_BLUEFIN_TUNA.get(), ModItems.ATLANTIC_BLUEFIN_TUNA_BUCKET.get(), "atlantic_bluefin_tuna");
        addFishRecipes(pWriter, ModItems.GRASS_CARP.get(), ModItems.GRASS_CARP_BUCKET.get(), "grass_carp");
        addFishRecipes(pWriter, ModItems.ARCHER_FISH.get(), ModItems.ARCHER_FISH_BUCKET.get(), "archer_fish");

        addWoodenFishRecipes(pWriter, ModItems.TESTFISH.get(), ModItems.TEXTFISH_WOODEN.get(), "testfish");
        addWoodenFishRecipes(pWriter, ModItems.LOACH.get(), ModItems.LOACH_WOODEN.get(), "loach");
        addWoodenFishRecipes(pWriter, ModItems.MINNOW.get(), ModItems.MINNOW_WOODEN.get(), "minnow");
        addWoodenFishRecipes(pWriter, ModItems.PIRANHA.get(), ModItems.PIRANHA_WOODEN.get(), "piranha");
        addWoodenFishRecipes(pWriter, ModItems.SARDINE.get(), ModItems.SARDINE_WOODEN.get(), "sardine");
        addWoodenFishRecipes(pWriter, ModItems.PLECOSTOMUS.get(), ModItems.PLECOSTOMUS_WOODEN.get(), "plecostomus");
        addWoodenFishRecipes(pWriter, ModItems.BELUGA_STURGEON.get(), ModItems.BELUGA_STURGEON_WOODEN.get(), "beluga_sturgeon");
        addWoodenFishRecipes(pWriter, ModItems.NILE_PERCH.get(), ModItems.NILE_PERCH_WOODEN.get(), "nile_perch");
        addWoodenFishRecipes(pWriter, ModItems.MEKONG_GIANT_CATFISH.get(), ModItems.MEKONG_GIANT_CATFISH_WOODEN.get(), "mekong_giant_catfish");
        addWoodenFishRecipes(pWriter, ModItems.TILAPIA.get(), ModItems.TILAPIA_WOODEN.get(), "tilapia");
        addWoodenFishRecipes(pWriter, ModItems.GUPPY.get(), ModItems.GUPPY_WOODEN.get(), "guppy");
        addWoodenFishRecipes(pWriter, ModItems.SAILFISH.get(), ModItems.SAILFISH_WOODEN.get(), "sailfish");
        addWoodenFishRecipes(pWriter, ModItems.HADDOCK.get(), ModItems.HADDOCK_WOODEN.get(), "haddock");
        addWoodenFishRecipes(pWriter, ModItems.NORTHERN_PIKE.get(), ModItems.NORTHERN_PIKE_WOODEN.get(), "northern_pike");
        addWoodenFishRecipes(pWriter, ModItems.SIAMESE_FIGHTING_FISH.get(), ModItems.SIAMESE_FIGHTING_FISH_WOODEN.get(), "siamese_fighting_fish");
        addWoodenFishRecipes(pWriter, ModItems.LANTERNFISH.get(), ModItems.LANTERNFISH_WOODEN.get(), "lanternfish");
        addWoodenFishRecipes(pWriter, ModItems.ATLANTIC_BLUEFIN_TUNA.get(), ModItems.ATLANTIC_BLUEFIN_TUNA_WOODEN.get(), "atlantic_bluefin_tuna");
        addWoodenFishRecipes(pWriter, ModItems.GRASS_CARP.get(), ModItems.GRASS_CARP_WOODEN.get(), "grass_carp");
        addWoodenFishRecipes(pWriter, ModItems.ARCHER_FISH.get(), ModItems.ARCHER_FISH_WOODEN.get(), "archer_fish");
    }
    private void addFishRecipes(Consumer<FinishedRecipe> pWriter, Item trophy, Item bucket, String fishName) {
        // 鱼 + 水桶 → 鱼桶 (消耗水桶和鱼标本)
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, bucket)
                .requires(trophy)
                .requires(Items.WATER_BUCKET)
                .unlockedBy("has_" + fishName + "_trophy", has(trophy))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(
                        BigFishMod.MOD_ID,
                        fishName + "_bucket_from_trophy"
                ));

        // 鱼桶 → 鱼标本 + 水桶
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, trophy)
                .requires(bucket)
                .unlockedBy("has_" + fishName + "_bucket", has(bucket))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(
                        BigFishMod.MOD_ID,
                        "trophy_from_" + fishName + "_bucket"
                ));
    }
    private void addWoodenFishRecipes(Consumer<FinishedRecipe> pWriter, Item trophy, Item woodenBucket, String fishName) {
        // 鱼 + 空木桶 → 木鱼桶 (消耗空木桶和鱼标本)
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, woodenBucket)
                .requires(trophy)
                .requires(ModItems.WOODEN_BUCKET.get()) // 使用空木桶作为原料
                .unlockedBy("has_" + fishName + "_trophy", has(trophy))
                .unlockedBy("has_wooden_bucket", has(ModItems.WOODEN_BUCKET.get()))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(
                        BigFishMod.MOD_ID,
                        fishName + "_wooden_bucket_from_trophy"
                ));

        // 木鱼桶 → 鱼标本 + 空木桶
        ShapelessRecipeBuilder.shapeless(RecipeCategory.MISC, trophy)
                .requires(woodenBucket)
                .unlockedBy("has_" + fishName + "_wooden_bucket", has(woodenBucket))
                .save(pWriter, ResourceLocation.fromNamespaceAndPath(
                        BigFishMod.MOD_ID,
                        "trophy_from_" + fishName + "_wooden_bucket"
                ));
    }
    protected static void oreSmoking(Consumer<FinishedRecipe> pFinishedRecipeConsumer, List<ItemLike> pIngredients, RecipeCategory pCategory, ItemLike pResult, float pExperience, int pCookingTime, String pGroup) {
        oreCooking(pFinishedRecipeConsumer, RecipeSerializer.SMOKING_RECIPE, pIngredients, pCategory, pResult, pExperience, pCookingTime, pGroup, "_from_smoking");
    }
}
