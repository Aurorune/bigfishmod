package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.client.model.GenericFishModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.model.GeoModel;

public interface FishModelProvider {
    /**
     * 获取鱼的模型层位置
     */
    ModelLayerLocation getModelLayer();

    /**
     * 创建鱼的模型
     */
    default EntityModel<?> createModel(ModelPart root) {
        return new GenericFishModel<>(root);
    }
    /**
     * 获取鱼的纹理位置
     */
    ResourceLocation getTextureLocation();
    float[] getStageScales();
    default int getMaxStages() {
        return 10; // 默认10个阶段
}
    default boolean useGeckoModel() {
        return false;
    }
    default EntityType<?> getEntityType() {
        return null;
    }
}
