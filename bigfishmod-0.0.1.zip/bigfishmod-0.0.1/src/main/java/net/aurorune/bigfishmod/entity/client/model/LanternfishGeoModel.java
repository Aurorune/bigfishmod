package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Lanternfish;
import net.aurorune.bigfishmod.entity.custom.SiameseFightingFish;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class LanternfishGeoModel extends GeoModel<Lanternfish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/lanternfish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/lanternfish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/lanternfish.animation.json");

    @Override
    public ResourceLocation getModelResource( Lanternfish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( Lanternfish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( Lanternfish object) {
        return ANIMATION;
    }

}