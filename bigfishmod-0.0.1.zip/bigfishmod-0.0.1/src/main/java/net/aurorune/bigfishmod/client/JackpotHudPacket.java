package net.aurorune.bigfishmod.client;

import net.aurorune.bigfishmod.api.BuffMessageUtil;
import net.aurorune.bigfishmod.client.renderer.JackpotHudRenderer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class JackpotHudPacket {
    private final String message;
    private final BuffMessageUtil.BuffType type; // 新增类型字段

    public JackpotHudPacket(String message, BuffMessageUtil.BuffType type) {
        this.message = message;
        this.type = type;
    }

    public static void encode(JackpotHudPacket packet, FriendlyByteBuf buffer) {
        buffer.writeUtf(packet.message);
        buffer.writeEnum(packet.type); // 将枚举类型写入缓冲区
    }

    public static JackpotHudPacket decode(FriendlyByteBuf buffer) {
        return new JackpotHudPacket(buffer.readUtf(), buffer.readEnum(BuffMessageUtil.BuffType.class));
    }

    public static void handle(JackpotHudPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() -> {
            // 在客户端显示HUD消息，持续5秒（100ticks）
            JackpotHudRenderer.showSpecialMessage(packet.message, packet.type);
        });
        context.get().setPacketHandled(true);
    }
}
