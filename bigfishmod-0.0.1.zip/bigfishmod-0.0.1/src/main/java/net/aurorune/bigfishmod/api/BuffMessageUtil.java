package net.aurorune.bigfishmod.api;


import net.aurorune.bigfishmod.client.Handler.NetworkHandler;
import net.aurorune.bigfishmod.client.JackpotHudPacket;
import net.minecraft.ChatFormatting;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerPlayer;


import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class BuffMessageUtil {

    // 定义Buff类型
    public enum BuffType {
        POSITIVE_MINOR,
        POSITIVE_MAJOR,
        MIXED,
        JACKPOT,
        CURSE
    }

    // 发送定制化的消息
    // 发送定制化的消息
    public static void sendStyledMessage(ServerPlayer player, String key, BuffType type) {
        // 从本地化文件获取消息
        String message = getMessageFromKey(key);

        // 关键修正: 根据类型决定是显示HUD还是聊天信息
        if (type == BuffType.JACKPOT || type == BuffType.CURSE) {
            // Jackpot 和 Curse 使用特殊的 HUD 渲染
            showSpecialHud(message, player, type);
            return; // 立即返回，不执行下面的 player.displayClientMessage
        }

        MutableComponent styledMessage = Component.literal(message);

        // 其他Buff类型则正常应用样式并发送到聊天框
        switch (type) {
            case POSITIVE_MINOR:
                styledMessage = applyPositiveMinorEffect(styledMessage);
                break;
            case POSITIVE_MAJOR:
                styledMessage = applyPositiveMajorEffect(styledMessage);
                break;
            case MIXED:
                styledMessage = applyMixedEffect(styledMessage);
                break;
            default:
                break;
        }
        player.displayClientMessage(styledMessage, true);
    }
    // 使用 I18n 从本地化文件中获取对应的文本
    private static String getMessageFromKey(String key) {
        List<String> messages = getMessagesForKey(key);
        Random random = new Random();
        return messages.get(random.nextInt(messages.size()));
    }

    // 根据key获取多条消息
    private static List<String> getMessagesForKey(String key) {
        // 获取当前玩家的语言环境
        String language = Locale.getDefault().getLanguage();  // 获取系统默认语言环境

        switch (key) {
            case "positive_minor":
                return getLocalizedMessages(language,
                        "一丝幸运的光芒！", "星辰为你排列。", "你感受到了一个轻微的祝福。",
                        "命运对你微笑。", "温柔的宇宙之息。", "星空低语着佳音。",
                        "A glimmer of fortune!", "The stars align for you.", "You feel a gentle blessing.",
                        "Destiny smiles upon you.", "A soft cosmic breeze.", "The stars whisper good omens."
                );
            case "positive_major":
                return getLocalizedMessages(language,
                        "史诗级的恩赐！", "一股星辰之力涌向你！", "星辰之力在你体内涌动！",
                        "天界降下祝福！", "星运璀璨闪耀！",
                        "An epic blessing!", "A surge of stellar power flows to you!", "Stellar energy courses through you!",
                        "Divine blessings descend!", "Stellar fortune shines brilliantly!"
                );
            case "mixed":
                return getLocalizedMessages(language,
                        "星光变得扭曲了...", "一个祸福参半的命运之袋...", "混沌与秩序共舞...",
                        "星辰之光在颤抖...", "命运的天平在摇摆...",
                        "Starlight twists and warps...", "A mixed bag of fate...", "Chaos and order dance together...",
                        "The starlight trembles...", "he scales of fate are wavering..."
                );
            case "jackpot":
                return getLocalizedMessages(language,
                        "宇宙奇迹！", "超凡之运加身！", "命运的齿轮为你转动!",
                        "星界和谐在体内共鸣！", "众星为你加冕！",
                        "A cosmic miracle!", "Extraordinary luck embraces you!", "The gears of fate turn for you!",
                        "Celestial harmony resonates within!", "The stars crown you!"
                );
            case "curse":
                return getLocalizedMessages(language,
                        "星辰诅咒了你！", "黑暗能量腐蚀了星光！", "恶意的命运正在展开...",
                        "星辰流下黑色的眼泪！", "宇宙的不幸降临于你！",
                        "The stars curse you!", "Dark energy corrupts the starlight!", "A malevolent destiny unfolds...",
                        "The stars shed black tears!", "Cosmic misfortune befalls you!"
                );
            default:
                return List.of("未知效果", "Unknown effect");
        }
    }

    // 根据语言选择正确的本地化文本
    private static List<String> getLocalizedMessages(String language, String... messages) {
        if ("en".equals(language)) {
            // 英文语言环境，返回英文部分
            return List.of(messages[5], messages[6], messages[8], messages[9], messages[7]);
        } else {
            // 其他语言环境（默认是中文）
            return List.of(messages[0], messages[1], messages[2], messages[3], messages[4]);
        }
    }


    // 原有的样式效果方法保持不变，但修改为返回MutableComponent
    private static MutableComponent applyPositiveMinorEffect(MutableComponent message) {
        return message.withStyle(Style.EMPTY.withColor(ChatFormatting.GREEN));
    }

    private static MutableComponent applyPositiveMajorEffect(MutableComponent message) {
        return message.withStyle(Style.EMPTY.withBold(true).withColor(ChatFormatting.GOLD));
    }

    private static MutableComponent applyMixedEffect(MutableComponent message) {
        return message.withStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xBFBF00)));
    }

    // 统一的特殊HUD显示方法
    private static void showSpecialHud(String message, ServerPlayer player, BuffType type) {
        NetworkHandler.sendToClient(new JackpotHudPacket(message, type), player);
    }
}