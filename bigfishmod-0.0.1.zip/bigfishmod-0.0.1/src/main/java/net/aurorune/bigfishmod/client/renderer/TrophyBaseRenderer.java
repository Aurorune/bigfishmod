package net.aurorune.bigfishmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.api.FishDisplayAdjuster;
import net.aurorune.bigfishmod.api.FishModelProvider;
import net.aurorune.bigfishmod.block.custom.TrophyBaseBlock;
import net.aurorune.bigfishmod.blockentity.custom.TrophyBaseBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.registries.ForgeRegistries;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@OnlyIn(Dist.CLIENT)
public class TrophyBaseRenderer implements BlockEntityRenderer<TrophyBaseBlockEntity> {
    private final ItemRenderer itemRenderer;
    private final Map<String, EntityModel<?>> fishModels = new HashMap<>();
    private final Map<String, ResourceLocation> modelTextures = new HashMap<>();
    private final EntityModelSet modelSet;

    // 用于缓存实体渲染器和静态实体
    private final Map<String, EntityRenderer<?>> entityRendererCache = new HashMap<>();
    private final Map<String, Entity> staticEntityCache = new HashMap<>();

    public TrophyBaseRenderer(BlockEntityRendererProvider.Context context) {
        this.itemRenderer = context.getItemRenderer();
        this.modelSet = context.getModelSet();
    }

    @Override
    public void render(TrophyBaseBlockEntity blockEntity, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource,
                       int packedLight, int packedOverlay) {
        if (blockEntity.isEmpty()) return;

        BlockState blockState = blockEntity.getBlockState();
        Direction facing = blockState.getValue(TrophyBaseBlock.FACING);

        poseStack.pushPose();
        try {
            // 移动到方块中心
            poseStack.translate(0.5, 0.5, 0.5);

            // 应用方块朝向旋转
            poseStack.mulPose(Axis.YP.rotationDegrees(180 - facing.toYRot()));

            // 渲染鱼模型
            ItemStack fishStack = blockEntity.getFishStack();
            if (fishStack.getItem() instanceof FishModelProvider fishModelProvider) {
                renderFishModel(fishModelProvider, fishStack, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
            } else {
                // 备用渲染 - 显示物品图标
                itemRenderer.renderStatic(
                        fishStack,
                        ItemDisplayContext.FIXED,
                        packedLight,
                        packedOverlay,
                        poseStack,
                        bufferSource,
                        blockEntity.getLevel(),
                        0
                );
            }
        } finally {
            poseStack.popPose();
        }
    }

    private void renderFishModel(FishModelProvider fishModelProvider, ItemStack fishStack, float partialTick,
                                 PoseStack poseStack, MultiBufferSource bufferSource,
                                 int packedLight, int packedOverlay) {
        String fishType = ForgeRegistries.ITEMS.getKey(fishStack.getItem()).toString();

        // 检查是否使用GeckoLib模型
        if (fishModelProvider.useGeckoModel() && fishModelProvider.getEntityType() != null) {
            renderGeckoLibModel(fishModelProvider, fishStack, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }
        // 原有的Java模型渲染代码保持不变
        EntityModel<?> model = fishModels.get(fishType);
        ResourceLocation texture = modelTextures.get(fishType);

        if (model == null) {
            ModelLayerLocation layer = fishModelProvider.getModelLayer();
            if (layer != null) {
                ModelPart modelPart = modelSet.bakeLayer(layer);
                if (modelPart != null) {
                    model = fishModelProvider.createModel(modelPart);
                    texture = fishModelProvider.getTextureLocation();

                    if (model != null) {
                        fishModels.put(fishType, model);
                        modelTextures.put(fishType, texture);
                    }
                }
            }
        }

        if (model == null || texture == null) {
            BigFishMod.LOGGER.warn("Falling back to item render for: {}", fishType);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }

        // 获取鱼的等级
        int level = getLevelFromFishStack(fishStack);

        // 获取缩放比例数组
        float[] stageScales = fishModelProvider.getStageScales();
        int maxStages = fishModelProvider.getMaxStages();

        if (stageScales == null || stageScales.length == 0) {
            BigFishMod.LOGGER.error("Stage scales array is null or empty for: {}", fishType);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }

        // 计算当前阶段
        int stage = Math.min(level / 5, Math.min(maxStages, stageScales.length) - 1);
        stage = Math.max(stage, 0);

        float scale = stageScales[stage];

        poseStack.pushPose();
        try {
            // 应用位置调整
            FishDisplayAdjuster.applyTypeSpecificAdjustment(poseStack, fishType, level);

            // 应用缩放
            poseStack.scale(scale, scale, scale);

            // 应用基础旋转
            poseStack.mulPose(Axis.YP.rotationDegrees(270));
            poseStack.mulPose(Axis.ZP.rotationDegrees(180));

            // 渲染模型
            VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutout(texture));
            model.renderToBuffer(
                    poseStack,
                    vertexConsumer,
                    packedLight,
                    packedOverlay,
                    1.0F, 1.0F, 1.0F, 1.0F
            );
        } finally {
            poseStack.popPose();
        }
    }

    private void renderGeckoLibModel(FishModelProvider fishModelProvider, ItemStack fishStack, float partialTick,
                                     PoseStack poseStack, MultiBufferSource bufferSource,
                                     int packedLight, int packedOverlay) {
        String fishType = ForgeRegistries.ITEMS.getKey(fishStack.getItem()).toString();

        // 获取实体类型
        EntityType<?> entityType = fishModelProvider.getEntityType();
        if (entityType == null) {
            BigFishMod.LOGGER.error("EntityType is null for: {}", fishType);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }

        // 获取或创建静态实体
        Entity staticEntity = staticEntityCache.computeIfAbsent(fishType, k -> {
            Entity entity = entityType.create(Minecraft.getInstance().level);
            if (entity != null) {
                // 设置实体为静态状态
                entity.setNoGravity(true);
                entity.setInvulnerable(true);
                entity.setSilent(true);

                // 如果是LivingEntity，设置为不移动状态
                if (entity instanceof LivingEntity livingEntity) {
                    livingEntity.setNoActionTime(1000);
                    livingEntity.yBodyRot = 0;
                    livingEntity.yHeadRot = 0;
                }
            }
            return entity;
        });

        if (staticEntity == null) {
            BigFishMod.LOGGER.error("Failed to create static entity for: {}", fishType);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }

        // 获取鱼的等级
        int level = getLevelFromFishStack(fishStack);

        // 获取缩放比例数组
        float[] stageScales = fishModelProvider.getStageScales();
        int maxStages = fishModelProvider.getMaxStages();

        if (stageScales == null || stageScales.length == 0) {
            BigFishMod.LOGGER.error("Stage scales array is null or empty for: {}", fishType);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
            return;
        }

        // 计算当前阶段
        int stage = Math.min(level / 5, Math.min(maxStages, stageScales.length) - 1);
        stage = Math.max(stage, 0);

        float scale = stageScales[stage];

        poseStack.pushPose();
        try {
            // 应用位置调整
            FishDisplayAdjuster.applyTypeSpecificAdjustment(poseStack, fishType, level);

            // 应用缩放
            poseStack.scale(scale, scale, scale);

            // 应用基础旋转
            poseStack.mulPose(Axis.YP.rotationDegrees(270));
            poseStack.mulPose(Axis.ZP.rotationDegrees(180));
            poseStack.mulPose(Axis.XP.rotationDegrees(180));
            // 使用实体渲染器渲染静态实体
            renderStaticEntity(staticEntity, partialTick, poseStack, bufferSource, packedLight);
        } catch (Exception e) {
            BigFishMod.LOGGER.error("Error rendering GeckoLib model: {}", e.getMessage(), e);
            renderFallbackItem(fishStack, poseStack, bufferSource, packedLight, packedOverlay);
        } finally {
            poseStack.popPose();
        }
    }

    /**
     * 渲染静态实体
     */
    private void renderStaticEntity(Entity entity, float partialTick,
                                    PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        try {
            // 设置实体的位置和旋转
            entity.setPos(0, 0, 0);
            entity.setYRot(0);
            entity.setXRot(0);

            // 获取实体渲染器
            EntityRenderer<?> entityRenderer = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(entity);

            // 调用实体渲染器的render方法
            // 使用反射调用以避免类型检查问题
            Method renderMethod = entityRenderer.getClass().getMethod("render",
                    Entity.class, float.class, float.class, PoseStack.class, MultiBufferSource.class, int.class);

            renderMethod.invoke(entityRenderer, entity, 0.0F, partialTick, poseStack, bufferSource, packedLight);
        } catch (Exception e) {
            BigFishMod.LOGGER.error("Error rendering static entity: {}", e.getMessage(), e);
        }
    }
    // 其他辅助方法保持不变...
    private void renderFallbackItem(ItemStack fishStack, PoseStack poseStack,
                                    MultiBufferSource bufferSource,
                                    int packedLight, int packedOverlay) {
        itemRenderer.renderStatic(
                fishStack,
                ItemDisplayContext.FIXED,
                packedLight,
                packedOverlay,
                poseStack,
                bufferSource,
                null,
                0
        );
    }
    private int getLevelFromFishStack(ItemStack fishStack) {
        if (fishStack.hasTag()) {
            CompoundTag tag = fishStack.getTag();
            if (tag.contains("FishLevel")) {
                return tag.getInt("FishLevel");
            }
        }
        return 1;
    }


}