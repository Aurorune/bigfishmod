package net.aurorune.bigfishmod.datagen.provider;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.data.ExistingFileHelper;

import java.util.concurrent.CompletableFuture;

public class ModItemTagsGen extends ItemTagsProvider {
    public ModItemTagsGen(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider,
                          CompletableFuture<TagLookup<Block>> blockTags, ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, blockTags, BigFishMod.MOD_ID, existingFileHelper);
    }

    @Override
    protected void addTags(HolderLookup.Provider provider) {
        // 素食标签
        this.tag(ModTags.Items.VEGETARIAN_FOOD)
                .add(Items.WHEAT)// 小麦
                .add(Items.CARROT)// 胡萝卜
                .add(Items.POTATO)// 土豆
                .add(Items.BEETROOT)// 甜菜根
                .add(Items.SWEET_BERRIES)// 甜浆果
                .add(Items.KELP)// 海带
                .add(Items.BROWN_MUSHROOM)// 褐蘑菇
                .add(Items.RED_MUSHROOM)// 红蘑菇
                .add(Items.APPLE)
                .add(Items.MELON_SLICE)// 西瓜片
                .add(Items.PUMPKIN)// 南瓜
                .add(ModItems.CORN.get());

        // 肉食标签
        this.tag(ModTags.Items.MEAT_FOOD)
                .add(Items.BEEF)// 牛肉
                .add(Items.PORKCHOP)// 猪肉
                .add(Items.CHICKEN)// 鸡肉
                .add(Items.MUTTON)// 羊肉
                .add(Items.RABBIT)// 兔肉
                .add(Items.COD)// 鳕鱼
                .add(Items.SALMON)// 三文鱼
                .add(ModItems.BELUGA_STURGEON_MEAT.get())
                .add(ModItems.PERCH_FILLET.get())
                .add(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get())
                .add(ModItems.BULK_FISH_MEAT.get())
                .add(ModItems.PRIME_TUNA_MEAT.get())
                .add(ModItems.SAILFISH_STEAK.get());
    }
}
