package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.ArcherFish;
import net.aurorune.bigfishmod.entity.custom.GrassCarp;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ArcherFishGeoModel extends GeoModel<ArcherFish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/archer_fish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/archer_fish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/archer_fish.animation.json");

    @Override
    public ResourceLocation getModelResource( ArcherFish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( ArcherFish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( ArcherFish object) {
        return ANIMATION;
    }

}
