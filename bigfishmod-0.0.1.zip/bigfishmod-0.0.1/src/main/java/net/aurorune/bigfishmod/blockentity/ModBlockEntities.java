package net.aurorune.bigfishmod.blockentity;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.aurorune.bigfishmod.blockentity.custom.TrophyBaseBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, "bigfishmod");
    // 使用延迟获取方块
    public static final RegistryObject<BlockEntityType<FishBoxBlockEntity>> FISH_BOX =
            BLOCK_ENTITIES.register("fish_box",
                    () -> BlockEntityType.Builder.of(FishBoxBlockEntity::new, ModBlocks.FISH_BOX.get()  // 延迟获取
                    ).build(null));
    public static final RegistryObject<BlockEntityType<TrophyBaseBlockEntity>> TROPHY_BASE =
            BLOCK_ENTITIES.register("trophy_base", () ->
                    BlockEntityType.Builder.of(
                            (pos, state) -> new TrophyBaseBlockEntity(pos, state), // 使用构造函数
                            ModBlocks.TROPHY_BASE.get() // 关联方块
                    ).build(null));
    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
        BigFishMod.LOGGER.info("Registered BlockEntities");
    }

}
