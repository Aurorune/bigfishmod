package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.world.entity.LivingEntity;

public class PredatorConfig {
    private final Class<? extends LivingEntity> preyClass;
    private final int minLevelDifference; // 捕食者需要比猎物高的最小等级差
    private final int maxLevelDifference; // 捕食者可以比猎物高的最大等级差

    public PredatorConfig(Class<? extends LivingEntity> preyClass, int minLevelDifference,
                          int maxLevelDifference) {
        this.preyClass = preyClass;
        this.minLevelDifference = minLevelDifference;
        this.maxLevelDifference = maxLevelDifference;
    }

    public Class<? extends LivingEntity> getPreyClass() {
        return preyClass;
    }

    public int getMinLevelDifference() {
        return minLevelDifference;
    }

    public int getMaxLevelDifference() {
        return maxLevelDifference;
    }

    /**
     * 检查捕食者是否符合捕食此猎物的条件
     */
    public boolean canPredate(AbstractCustomFish predator, LivingEntity prey) {
        // 检查猎物类型
        if (!preyClass.isInstance(prey)) {
            return false;
        }

        // 如果猎物也是自定义鱼类，检查等级条件
        if (prey instanceof AbstractCustomFish) {
            AbstractCustomFish preyFish = (AbstractCustomFish) prey;
            int levelDifference = predator.getLevel() - preyFish.getLevel();

            // 检查等级差异是否符合要求
            return levelDifference >= minLevelDifference &&
                    levelDifference <= maxLevelDifference;
        }

        // 对于非自定义鱼类，默认可以捕食（或根据需要调整）
        return true;
    }
}