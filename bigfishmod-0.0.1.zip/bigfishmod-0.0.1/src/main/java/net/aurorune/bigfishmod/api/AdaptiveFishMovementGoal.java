
package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;
import java.util.EnumSet;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
/*** 自适应鱼类移动目标类，用于控制自定义鱼类的不同移动行为模式。* 包括底栖匍匐、中层水域游动、水面游动和跃出水面等行为。*/
public class AdaptiveFishMovementGoal extends Goal {
    private int goalCheckTimer = 0; // 累计tick数，用于控制每5秒的判定
    private static final int GOAL_CHECK_INTERVAL = 100;
    /*** 鱼的移动模式枚举*/
    public enum MovementMode {
        BOTTOM_CRAWLING,  // 底栖匍匐：鱼在水底附近缓慢移动
        MID_WATER,        // 中层水域游动：鱼在水域中层自由游动
        SURFACE,          // 水面游动：鱼在水面附近游动
        BREACHING         // 跃出水面：鱼从水中跃出
    }

    /*** 鱼的状态枚举*/
    public enum FishState {
        IDLE,           // 空闲状态
        MOVING,         // 移动中
        BREACHING,      // 跃出水面
        COOLDOWN        // 冷却状态
    }

    // 基础配置
    protected final AbstractCustomFish fish;
    protected final double baseSpeed;
    protected final int recalcInterval;
    protected final float distanceFromBottom;

    // 模式权重
    protected final float bottomModeWeight;
    protected final float midWaterModeWeight;
    protected final float surfaceModeWeight;

    // 状态管理
    protected MovementMode currentMode;
    protected MovementMode preferredMode;
    protected FishState currentState = FishState.IDLE;

    // 计时器
    protected int timeToRecalcPath;
    protected int stateCooldown = 0;
    protected static final int STATE_CHANGE_COOLDOWN = 20;

    // 移动控制
    protected Vec3 targetPosition;
    protected boolean isActive;
    protected int level;

    // 跃出设置
    protected final float breachProbability;
    protected int breachCooldown;
    protected int breachTime;
    protected boolean isBreaching;

    /*** 简化构造函数*/
    public AdaptiveFishMovementGoal(AbstractCustomFish fish, double baseSpeed, int recalcInterval,
                                    MovementMode preferredMode,
                                    float distanceFromBottom, float bottomModeWeight,
                                    float midWaterModeWeight, float surfaceModeWeight,
                                    float breachProbability) {
        this.fish = fish;
        this.baseSpeed = baseSpeed;
        this.recalcInterval = recalcInterval;
        this.preferredMode = preferredMode;
        this.distanceFromBottom = distanceFromBottom;
        this.bottomModeWeight = bottomModeWeight;
        this.midWaterModeWeight = midWaterModeWeight;
        this.surfaceModeWeight = surfaceModeWeight;
        this.breachProbability = breachProbability;

        this.setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP));
        this.currentMode = this.preferredMode;
    }

    @Override
    public boolean canUse() {
        // 每5秒检查一次是否可以启动
        if (++this.goalCheckTimer < GOAL_CHECK_INTERVAL) {
            return false;
        }
        this.goalCheckTimer = 0;

        if (!this.fish.isInWater()) {
            if (this.isBreaching && this.breachTime < 10) {
                return true;
            }
            return false;
        }

        updateAttributes();
        selectMovementMode();

        if (this.currentMode == MovementMode.BREACHING) {
            changeState(FishState.BREACHING);
        } else {
            changeState(FishState.MOVING);
        }

        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (this.isBreaching) {
            return true;
        }

        // 只要鱼还在水中，就继续使用这个目标
        if (!this.fish.isInWater()) {
            // 如果不在水中，除非是正在跃出，否则停止
            return false;
        }

        // 如果导航到目标位置，重新计算路径
        if (this.fish.getNavigation().isDone()) {
            // 返回 false，让 canUse() 重新运行，选择新模式和目标
            return false;
        }

        return true;
    }

    @Override
    public void start() {
        this.timeToRecalcPath = 0;
        this.isBreaching = false;
        this.breachTime = 0;
        this.isActive = true;

        if (this.currentState == FishState.MOVING) {
            this.updateNavigation();
        }
    }

    @Override
    public void stop() {
        this.fish.getNavigation().stop();
        this.isActive = false;
    }

    @Override
    public void tick() {
        if (!this.isActive) return;

        // 更新状态冷却
        if (stateCooldown > 0) {
            stateCooldown--;
        }

        // 根据当前状态执行相应行为
        switch (this.currentState) {
            case MOVING:
                tickMovingState();
                break;
            case BREACHING:
                tickBreachingState();
                break;
            case COOLDOWN:
                tickCooldownState();
                break;
            default:
                tickMovingState();
                break;
        }
    }

    /**
     * 移动状态的处理
     */
    protected void tickMovingState() {
        // 检查碰撞，如果发生碰撞则重新计算路径
        if (this.fish.isHorizontalCollision() || this.fish.isVerticalCollision()) {
            this.updateNavigation(); // 立即重新计算导航路径
            this.timeToRecalcPath = this.adjustedTickDelay(this.recalcInterval);
        }

        // 处理移动模式
        if (--this.timeToRecalcPath <= 0) {
            this.timeToRecalcPath = this.adjustedTickDelay(this.recalcInterval);
            this.updateNavigation();
        }

        // 确保鱼保持在适当的水层
        maintainWaterLayer();

        // 检查是否可以跃出
        if (canBreach() && this.fish.getRandom().nextFloat() < this.breachProbability) {
            if (changeState(FishState.BREACHING)) {
                return;
            }}
    }

    /**
     * 跃出状态的处理
     */
    protected void tickBreachingState() {
        // 检查碰撞，如果发生碰撞则结束跃出
        if (this.fish.isHorizontalCollision() || this.fish.isVerticalCollision()) {
            endBreaching();
            return;
        }
        handleBreaching();
        // 最长跃出时间保护
        if (this.breachTime > 15) {
            endBreaching();
        }
    }

    /**
     * 冷却状态的处理
     */
    protected void tickCooldownState() {
        // 冷却时间减少
        if (this.breachCooldown > 0) {
            this.breachCooldown--;
        }
        // 冷却结束后恢复到移动状态
        if (this.breachCooldown <= 0) {
            changeState(FishState.MOVING);
        }
    }

    /*** 更新鱼的属性缓存*/
    protected void updateAttributes() {
        this.level = this.fish.getLevel();
    }

    /*** 选择移动模式*/
    protected void selectMovementMode() {
        // 如果正在跃出水面，保持状态
        if (this.isBreaching) {
            return;
        }
        // 根据权重随机选择模式
        float totalWeight = this.bottomModeWeight + this.midWaterModeWeight + this.surfaceModeWeight;
        float randomValue = this.fish.getRandom().nextFloat() * totalWeight;

        if (randomValue < this.bottomModeWeight) {
            this.currentMode = MovementMode.BOTTOM_CRAWLING;
        } else if (randomValue < this.bottomModeWeight + this.midWaterModeWeight) {
            this.currentMode = MovementMode.MID_WATER;
        } else {
            this.currentMode = MovementMode.SURFACE;
        }
        // 确保模式适合当前环境
        validateSelectedMode();
    }

    /*** 验证所选移动模式是否适合当前环境*/
    protected void validateSelectedMode() {
        // 如果选择底栖模式但不在水底附近，可能调整为中层模式
        if (this.currentMode == MovementMode.BOTTOM_CRAWLING &&
                this.fish.getY() > getWaterBottomY() + this.distanceFromBottom + 2.0) {
            this.currentMode = MovementMode.MID_WATER;
        }

        // 如果选择水面模式但不在水面附近，可能调整为中层模式
        if (this.currentMode == MovementMode.SURFACE &&
                this.fish.getY() < fish.getCachedWaterSurfaceY() - 2.0) {
            this.currentMode = MovementMode.MID_WATER;
        }
    }

    /*** 检查鱼是否可以跃出水面*/
    protected boolean canBreach() {
        if (this.breachCooldown > 0) {
            return false;
        }

        // 小鱼（等级 ≤ 15）不能跃出
        if (this.level <= 15) {
            return false;
        }

        // 确保鱼在水中
        if (!this.fish.isInWater()) {
            return false;
        }

        // 确保上方没有障碍物
        BlockState aboveState = this.fish.level().getBlockState(this.fish.blockPosition().above());
        if (aboveState.isSolid()) {
            return false;
        }

        // 确保靠近水面
        if (this.fish.getY() < fish.getCachedWaterSurfaceY() - 1.0) {
            return false;
        }

        return true;
    }

    /*** 处理跃出水面行为*/
    protected void handleBreaching() {
        if (!this.isBreaching) {
            // 开始跃出
            this.isBreaching = true;
            this.breachTime = 0;

            // 设置跃出状态
            this.fish.setBreaching(true);

            // 向上加速（基于等级）
            Vec3 motion = this.fish.getDeltaMovement();
            double levelFactor = Math.min(this.level, 50) / 100.0;
            double randomFactor = this.fish.getRandom().nextDouble() * 0.2;
            double breachPower = 0.4 + levelFactor + randomFactor;
            breachPower = Math.min(breachPower, 0.8);
            this.fish.setDeltaMovement(motion.x, breachPower, motion.z);
            // 停止导航
            this.fish.getNavigation().stop();
            return;
        }
        this.breachTime++;
        // 在空中时保持向前移动
        if (!this.fish.isInWater()) {
            // 检查是否应该结束跃出（例如碰到地面）
            if (this.fish.onGround() || this.fish.isVerticalCollision()) {
                endBreaching();
                return;
            }

            Vec3 look = this.fish.getLookAngle();
            double forwardPower = 0.1 + (this.level / 200.0);
            Vec3 currentMotion = this.fish.getDeltaMovement();
            this.fish.setDeltaMovement(new Vec3(
                    look.x * forwardPower,
                    currentMotion.y - 0.04, // 重力
                    look.z * forwardPower));
        } else {
            // 如果回到水中，结束跃出
            if (this.fish.getDeltaMovement().y < 0 && this.breachTime > 5) {
                endBreaching();
            }
        }

        // 最长跃出时间保护
        if (this.breachTime > 15) {
            endBreaching();
        }
    }

    /*** 结束跃出水面行为*/
    protected void endBreaching() {
        this.isBreaching = false;
        this.fish.setBreaching(false);

        // 转换到冷却状态
        changeState(FishState.COOLDOWN);
    }

    /*** 确保鱼保持在适当的水层*/
    protected void maintainWaterLayer() {
        switch (this.currentMode) {
            case BOTTOM_CRAWLING:
                // 确保鱼接近水底
                double bottomY = getWaterBottomY() + this.distanceFromBottom;
                if (this.fish.getY() > bottomY + 0.5) {
                    Vec3 motion = this.fish.getDeltaMovement();
                    this.fish.setDeltaMovement(new Vec3(motion.x, -0.05, motion.z));
                }
                break;

            case SURFACE:
                // 确保鱼接近水面
                double surfaceY = fish.getCachedWaterSurfaceY() - 0.2;
                if (this.fish.getY() < surfaceY - 0.5) {
                    Vec3 motion = this.fish.getDeltaMovement();
                    this.fish.setDeltaMovement(new Vec3(motion.x, 0.05, motion.z));
                }
                break;
        }
    }

    /*** 更新导航路径*/
    protected void updateNavigation() {
        this.targetPosition = calculateTargetPosition();
        if (this.targetPosition != null) {
            double speed = calculateAdjustedSpeed();
            this.fish.getNavigation().moveTo(
                    this.targetPosition.x,
                    this.targetPosition.y,
                    this.targetPosition.z,
                    speed);
        }
    }

    /*** 计算目标位置*/
    protected Vec3 calculateTargetPosition() {
        switch (this.currentMode) {
            case BOTTOM_CRAWLING:
                return calculateBottomPosition();
            case MID_WATER:
                return calculateMidWaterPosition();
            case SURFACE:
                return calculateSurfacePosition();
            case BREACHING:
                return null; // 跃出时不使用导航
            default:
                return calculateMidWaterPosition();
        }
    }

    /*** 计算底栖模式的目标位置*/
    protected Vec3 calculateBottomPosition() {
        BlockPos bottomPos = findWaterBottom();
        if (bottomPos == null) return calculateMidWaterPosition();

        // 获取鱼的当前朝向向量
        Vec3 currentLook = this.fish.getLookAngle();

        // 增加一个小的随机扰动
        double randomX = (this.fish.getRandom().nextDouble() - 0.5) * 0.4;
        double randomZ = (this.fish.getRandom().nextDouble() - 0.5) * 0.4;

        // 创建一个新的方向向量，并归一化
        Vec3 newDirection = new Vec3(currentLook.x + randomX, 0, currentLook.z + randomZ).normalize();

        // 根据新方向计算目标点
        int range = 6 + (this.level / 20);
        Vec3 target = this.fish.position().add(newDirection.scale(range * (0.5 + this.fish.getRandom().nextDouble() * 0.5)));

        double y = bottomPos.getY() + this.distanceFromBottom + this.fish.getRandom().nextDouble() * 0.2;

        // 确保目标点在水底附近
        target = new Vec3(target.x, y, target.z);

        return target;
    }

    /*** 计算中层水域模式的目标位置*/
    protected Vec3 calculateMidWaterPosition() {
        double waterSurfaceY = fish.getCachedWaterSurfaceY();
        double waterBottomY = getWaterBottomY();
        double midY = waterBottomY + (waterSurfaceY - waterBottomY) * (0.5 + this.fish.getRandom().nextDouble() * 0.2);

        // 获取鱼的当前朝向向量
        Vec3 currentLook = this.fish.getLookAngle();

        // 增加一个小的随机扰动，而不是完全随机
        double randomX = (this.fish.getRandom().nextDouble() - 0.5) * 0.6; // 增加扰动范围
        double randomZ = (this.fish.getRandom().nextDouble() - 0.5) * 0.6;

        // 创建一个新的方向向量，并归一化
        Vec3 newDirection = new Vec3(currentLook.x + randomX, 0, currentLook.z + randomZ).normalize();

        // 根据新方向计算目标点
        int range = 8 + (this.level / 20);
        Vec3 target = this.fish.position().add(newDirection.scale(range * (0.5 + this.fish.getRandom().nextDouble() * 0.5)));

        // 调整 Y 坐标，使其在水层中
        target = new Vec3(target.x, Mth.clamp(target.y, waterBottomY + 0.5, waterSurfaceY - 0.5), target.z);

        return target;
    }

    /*** 计算水面模式的目标位置*/
    protected Vec3 calculateSurfacePosition() {
        double surfaceY = fish.getCachedWaterSurfaceY() - 0.2;

        // 获取鱼的当前朝向向量
        Vec3 currentLook = this.fish.getLookAngle();

        // 增加一个小的随机扰动
        double randomX = (this.fish.getRandom().nextDouble() - 0.5) * 0.8;
        double randomZ = (this.fish.getRandom().nextDouble() - 0.5) * 0.8;

        // 创建一个新的方向向量，并归一化
        Vec3 newDirection = new Vec3(currentLook.x + randomX, 0, currentLook.z + randomZ).normalize();

        // 根据新方向计算目标点
        int range = 10 + (this.level / 20);
        Vec3 target = this.fish.position().add(newDirection.scale(range * (0.5 + this.fish.getRandom().nextDouble() * 0.5)));

        // 将 Y 坐标锁定在水面
        target = new Vec3(target.x, surfaceY, target.z);

        return target;
    }

    /*** 计算调整后的移动速度*/
    protected double calculateAdjustedSpeed() {
        double levelFactor = 0.8 + (this.level / 100.0);
        double modeFactor = 1.0;

        switch (this.currentMode) {
            case BOTTOM_CRAWLING:
                modeFactor = 0.8;
                break;
            case SURFACE:
                modeFactor = 1.1;
                break;
            case BREACHING:
                modeFactor = 1.5;
                break;
        }

        return this.baseSpeed * levelFactor * modeFactor;
    }

    /*** 寻找水底位置*/
    protected BlockPos findWaterBottom() {
        BlockPos currentPos = this.fish.blockPosition();
        BlockPos bottomPos = currentPos;

        // 向下寻找非水方块
        while (bottomPos.getY() > this.fish.level().getMinBuildHeight() &&
                this.fish.level().getFluidState(bottomPos).is(FluidTags.WATER)) {
            bottomPos = bottomPos.below();
        }

        // 如果找到了底部，返回其上方的位置
        if (bottomPos.getY() > this.fish.level().getMinBuildHeight()) {
            return bottomPos.above();
        }

        return null;
    }


    /*** 获取水底高度*/
    protected double getWaterBottomY() {
        BlockPos bottom = findWaterBottom();
        return bottom != null ? bottom.getY() + 1.0 : this.fish.getY();
    }

    /**
     * 转换到新状态
     */
    protected boolean changeState(FishState newState) {
        if (stateCooldown > 0) {
            return false;
        }

        // 检查是否可以转换到新状态
        if (canChangeToState(newState)) {
            this.currentState = newState;
            this.stateCooldown = STATE_CHANGE_COOLDOWN + this.fish.getRandom().nextInt(10);

            // 状态进入处理
            onStateEnter(newState);
            return true;
        }

        return false;
    }

    /**
     * 检查是否可以转换到指定状态
     */
    protected boolean canChangeToState(FishState newState) {
        // 状态转换规则
        switch (newState) {
            case BREACHING:
                return canBreach() && this.currentState != FishState.COOLDOWN;
            case COOLDOWN:
                return this.currentState == FishState.BREACHING;
            default:
                return true;
        }
    }

    /**
     * 状态进入处理
     */
    protected void onStateEnter(FishState state) {
        switch (state) {
            case MOVING:
                this.timeToRecalcPath = 0;
                this.updateNavigation();
                break;
            case BREACHING:
                this.isBreaching = true;
                this.breachTime = 0;
                this.fish.setBreaching(true);
                break;
            case COOLDOWN:
                this.breachCooldown = 100 + this.fish.getRandom().nextInt(100);
                break;
        }
    }

    // 配置方法
    public void setPreferredMode(MovementMode mode) {
        this.preferredMode = mode;
    }

    public MovementMode getCurrentMode() {
        return this.currentMode;
    }

    public boolean isBreaching() {
        return this.isBreaching;
    }

    public Vec3 getTargetPosition() {
        return this.targetPosition;
    }

    public FishState getCurrentState() {
        return this.currentState;
    }
}