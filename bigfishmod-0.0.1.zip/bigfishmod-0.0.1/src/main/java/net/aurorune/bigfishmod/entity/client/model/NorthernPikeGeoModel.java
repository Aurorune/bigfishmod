package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Haddock;
import net.aurorune.bigfishmod.entity.custom.NorthernPike;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class NorthernPikeGeoModel extends GeoModel<NorthernPike> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/northern_pike.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/northern_pike.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/northern_pike.animation.json");

    @Override
    public ResourceLocation getModelResource( NorthernPike object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( NorthernPike object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( NorthernPike object) {
        return ANIMATION;
    }

}
