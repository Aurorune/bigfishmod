package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.MekongGiantCatfish;
import net.aurorune.bigfishmod.entity.custom.NilePerch;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class MekongGiantCatfishGeoModel extends GeoModel<MekongGiantCatfish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/mekong_giant_catfish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/mekong_giant_catfish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/mekong_giant_catfish.animation.json");

    @Override
    public ResourceLocation getModelResource(MekongGiantCatfish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(MekongGiantCatfish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(MekongGiantCatfish object) {
        return ANIMATION;
    }

}
