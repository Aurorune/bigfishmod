package net.aurorune.bigfishmod.datagen.provider;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.BlockTags;
import net.minecraftforge.common.data.BlockTagsProvider;
import net.minecraftforge.common.data.ExistingFileHelper;

import javax.annotation.Nullable;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagsProvider extends BlockTagsProvider {
    public ModBlockTagsProvider(PackOutput output,
                                CompletableFuture<HolderLookup.Provider> lookupProvider,
                                   @Nullable ExistingFileHelper existingFileHelper){
        super(output,lookupProvider, BigFishMod.MOD_ID,existingFileHelper);}

    @Override
    protected void addTags(HolderLookup.Provider pProvider) {
        tag(BlockTags.MINEABLE_WITH_PICKAXE)
                .add(ModBlocks.GRAPHITE_BLOCK.get())
                .add(ModBlocks.GRAPHITE_ORE.get())
                .add(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get())
                .add(ModBlocks.FISH_STAND.get());
        tag(BlockTags.NEEDS_STONE_TOOL)
                .add(ModBlocks.GRAPHITE_ORE.get())
                .add(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get());
        tag(BlockTags.MINEABLE_WITH_AXE)
                .add(ModBlocks.FISH_BOX.get());
    }
}
