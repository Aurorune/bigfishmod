package net.aurorune.bigfishmod.block.custom;

import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

//作物
public class CronCropBlock extends CropBlock {
    public static final IntegerProperty AGE = IntegerProperty.create("age",0,6);
    public static final BooleanProperty TOP = BooleanProperty.create("top");
    public static final int MAX_AGE = 6;
    public static final int TOP_START_AGE=4;
    public CronCropBlock(Properties properties){
        super(properties);this.registerDefaultState(
            this.stateDefinition.any()
                    .setValue(AGE,0)
                    .setValue(TOP,false));}

    //种子ID定义
    protected ItemLike getBaseSeedID(){return ModItems.CORN_SEED.get();}
    public IntegerProperty getAgeProperty(){return AGE;
    }
    public int getMaxAAge(){return MAX_AGE;}
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder){
        builder.add(AGE,TOP);}
    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean isClient) {
        // 只有底部方块才能使用骨粉，并且未成熟
        return !state.getValue(TOP) && state.getValue(AGE) < MAX_AGE;
    }
    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true; // 骨粉总是成功
    }
    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        int currentAge = state.getValue(AGE);
        int newAge = Math.min(currentAge + getBonemealAgeIncrease(level), MAX_AGE);

        // 更新底部方块年龄
        level.setBlock(pos, state.setValue(AGE, newAge), Block.UPDATE_CLIENTS);

        // 处理顶部方块
        if (newAge >= TOP_START_AGE) {
            BlockPos topPos = pos.above();
            BlockState topState = level.getBlockState(topPos);

            if (topState.is(this)) {
                // 如果顶部方块已存在，更新其年龄
                level.setBlock(topPos, topState.setValue(AGE, newAge), Block.UPDATE_CLIENTS);
            } else if (level.isEmptyBlock(topPos)) {
                // 如果顶部方块不存在且位置为空，创建顶部方块
                level.setBlock(topPos, this.defaultBlockState()
                        .setValue(AGE, newAge)
                        .setValue(TOP, true), Block.UPDATE_ALL);
            }
        }
    }

    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // 只允许底部方块生长
        if (!state.getValue(TOP) && this.canGrow(state, level, pos)) {
            // 标准生长概率
            if (level.getRawBrightness(pos, 0) >= 9) {
                int currentAge = this.getAge(state);
                if (currentAge < this.getMaxAge()) {
                    float growthSpeed = getGrowthSpeed(this, level, pos);
                    if (random.nextInt((int)(25.0F / growthSpeed) + 1) == 0) {
                        // 生长到下一阶段
                        level.setBlock(pos, state.setValue(AGE, currentAge + 1), 2);

                        // 当达到顶部起始阶段时，在顶部位置创建顶部方块
                        if (currentAge + 1 == TOP_START_AGE) {
                            BlockPos topPos = pos.above();
                            if (level.isEmptyBlock(topPos)) {
                                level.setBlock(topPos, this.defaultBlockState()
                                        .setValue(AGE, TOP_START_AGE)
                                        .setValue(TOP, true), 3);
                            }
                        }
                    }
                }
            }
        }
        // 新增：顶部方块年龄同步（确保顶部始终与底部年龄一致）
        else if (state.getValue(TOP)) {
            BlockPos bottomPos = pos.below();
            BlockState bottomState = level.getBlockState(bottomPos);

            if (bottomState.is(this) && !bottomState.getValue(TOP)) {
                int bottomAge = bottomState.getValue(AGE);
                if (state.getValue(AGE) != bottomAge) {
                    level.setBlock(pos, state.setValue(AGE, bottomAge), Block.UPDATE_CLIENTS);
                }
            }
        }
    }


    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        // 顶部方块需要底部有玉米支撑
        if (state.getValue(TOP)) {
            BlockState belowState = level.getBlockState(pos.below());
            return belowState.is(this) && !belowState.getValue(TOP);
        }
        // 底部方块需要下方有耕地
        return super.canSurvive(state, level, pos);
    }


    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        // 处理收获逻辑
        if (state.getValue(TOP)) {
            // 收获顶部时，保留底部为成熟状态
            BlockPos bottomPos = pos.below();
            BlockState bottomState = level.getBlockState(bottomPos);
            if (!state.getValue(TOP) && state.getValue(AGE) == MAX_AGE) {
                // 如果是成熟的底部方块，跳过顶部破坏逻辑
                super.playerWillDestroy(level, pos, state, player);
                return;
            }

            if (bottomState.is(this) && !bottomState.getValue(TOP)) {
                // 设置底部为最大年龄（成熟但不再生长）
                level.setBlock(bottomPos, bottomState.setValue(AGE, MAX_AGE), Block.UPDATE_ALL);

                // 防止底部方块继续生长
                if (!level.isClientSide) {
                    level.scheduleTick(bottomPos, this, 1);
                }
            }
        } else {
            // 收获底部时，同时破坏顶部
            BlockPos topPos = pos.above();
            BlockState topState = level.getBlockState(topPos);

            if (topState.is(this) && topState.getValue(TOP)) {
                // 破坏顶部方块
                level.destroyBlock(topPos, true, player);
            }
        }

        super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // 如果收获后保留的底部方块是成熟状态，则不再生长
        if (!state.getValue(TOP) && state.getValue(AGE) == MAX_AGE) {
            return;
        }
        super.tick(state, level, pos, random);
    }

    // 辅助方法：检查方块是否可以生长
    private boolean canGrow(BlockState state, ServerLevel level, BlockPos pos) {
        return !state.getValue(TOP) && state.getValue(AGE) < MAX_AGE;
    }

}
