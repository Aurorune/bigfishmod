package net.aurorune.bigfishmod.datagen.provider;

import net.aurorune.bigfishmod.entity.ModEntities;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraftforge.common.data.DatapackBuiltinEntriesProvider;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.ForgeBiomeModifiers;
import net.minecraftforge.registries.ForgeRegistries;
import net.aurorune.bigfishmod.BigFishMod;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public class ModBiomeModifiersProvider extends DatapackBuiltinEntriesProvider {
    // 创建注册表构建器
    private static final RegistrySetBuilder BUILDER = new RegistrySetBuilder()
            .add(ForgeRegistries.Keys.BIOME_MODIFIERS, ModBiomeModifiersProvider::registerBiomeModifiers);

    public ModBiomeModifiersProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> registries, ExistingFileHelper helper) {
        // 使用正确的构造函数参数
        super(output, registries, BUILDER, Set.of(BigFishMod.MOD_ID));
    }

    // 注册生物群系修改器
    private static void registerBiomeModifiers(BootstapContext<BiomeModifier> context) {
        // 获取生物群系注册表
        HolderGetter<Biome> biomeGetter = context.lookup(Registries.BIOME);

        // 在海洋生物群系生成TestFish
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "testfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.TESTFISH.get(),
                                10, // 生成权重
                                1,  // 最小数量
                                3   // 最大数量
                        ))
                ));

        // Tilapia - 热带淡水鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "tilapia_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.TILAPIA.get(),
                                15, // 生成权重
                                1,  // 最小数量
                                3   // 最大数量
                        ))
                ));
        // SiameseFightingFish - 热带观赏鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "siamesefightingfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.SIAMESE_FIGHTING_FISH.get(),
                                8,  // 生成权重
                                1,  // 最小数量
                                2   // 最大数量（独居性）
                        ))
                ));
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "sardine_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.SARDINE.get(),
                                25, // 生成权重（数量庞大）
                                3,  // 最小数量
                                8  // 最大数量
                        ))
                ));
        // Sailfish - 热带海洋快速鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "sailfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.SAILFISH.get(),
                                3,  // 生成权重（稀有）
                                1,  // 最小数量
                                1   // 最大数量（独居）
                        ))
                ));
        // Plecostomus - 热带淡水底栖鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "plecostomus_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.PLECOSTOMUS.get(),
                                12, // 生成权重
                                1,  // 最小数量
                                3   // 最大数量
                        ))
                ));
        // Piranha - 热带攻击性鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "piranha_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.PIRANHA.get(),
                                10, // 生成权重
                                2,  // 最小数量
                                6   // 最大数量（群居）
                        ))
                ));
        // NorthernPike - 温带淡水掠食者
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "northernpike_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.NORTHERN_PIKE.get(),
                                6,  // 生成权重
                                1,  // 最小数量
                                1   // 最大数量（独居）
                        ))
                ));
        // NilePerch - 热带大型淡水鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "nileperch_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.NILE_PERCH.get(),
                                4,  // 生成权重（稀有）
                                1,  // 最小数量
                                1   // 最大数量（独居）
                        ))
                ));

        // Minnow - 广泛分布的小型饵料鱼
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "minnow_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.MINNOW.get(),
                                20, // 生成权重（数量多）
                                4,  // 最小数量
                                8   // 最大数量
                        ))
                ));

        // MekongGiantCatfish - 稀有巨型淡水鱼
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "mekonggiantcatfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.MEKONG_GIANT_CATFISH.get(),
                                1,  // 生成权重（非常稀有）
                                1,  // 最小数量
                                1   // 最大数量
                        ))
                ));

        // Loach - 温带底栖鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "loach_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.LOACH.get(),
                                8,  // 生成权重
                                1,  // 最小数量
                                3   // 最大数量
                        ))
                ));

        // Lanternfish - 深海发光鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "lanternfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_DEEP_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.LANTERNFISH.get(),
                                18, // 生成权重（深海常见）
                                3,  // 最小数量
                                7   // 最大数量
                        ))
                ));

        // Haddock - 冷水海洋鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "haddock_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.HADDOCK.get(),
                                12, // 生成权重
                                2,  // 最小数量
                                4   // 最大数量
                        ))
                ));

        // Guppy - 热带观赏鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "guppy_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.GUPPY.get(),
                                14, // 生成权重
                                2,  // 最小数量
                                5   // 最大数量
                        ))
                ));

        // GrassCarp - 温带淡水草食性鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "grasscarp_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.GRASS_CARP.get(),
                                9,  // 生成权重
                                1,  // 最小数量
                                3   // 最大数量
                        ))
                ));

        // BelugaSturgeon - 稀有巨型鲟鱼
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "belugasturgeon_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_RIVER),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.BELUGA_STURGEON.get(),
                                1,  // 生成权重（极度稀有）
                                1,  // 最小数量
                                1   // 最大数量
                        ))
                ));

        // AtlanticBluefinTuna - 海洋顶级掠食者
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "atlanticbluefintuna_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_OCEAN),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.ATLANTIC_BLUEFIN_TUNA.get(),
                                2,  // 生成权重（稀有）
                                1,  // 最小数量
                                1   // 最大数量
                        ))
                ));

        // ArcherFish - 热带特殊捕食鱼类
        context.register(
                ResourceKey.create(ForgeRegistries.Keys.BIOME_MODIFIERS,
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "archerfish_spawns")),
                new ForgeBiomeModifiers.AddSpawnsBiomeModifier(
                        biomeGetter.getOrThrow(BiomeTags.IS_JUNGLE),
                        List.of(new MobSpawnSettings.SpawnerData(
                                ModEntities.ARCHER_FISH.get(),
                                7,  // 生成权重
                                1,  // 最小数量
                                2   // 最大数量
                        ))
                ));

    }
    @Override
    public String getName() {
        return "BigFishMod Biome Modifiers"; // 添加唯一名称
    }
}