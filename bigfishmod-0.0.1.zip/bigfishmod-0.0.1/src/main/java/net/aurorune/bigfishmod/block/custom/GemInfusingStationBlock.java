package net.aurorune.bigfishmod.block.custom;

import net.aurorune.bigfishmod.config.FishDecomposingConfig;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

//自定义模型
public class GemInfusingStationBlock extends HorizontalDirectionalBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public GemInfusingStationBlock(Properties pProperties) {
        super(pProperties);
    }
    private static final VoxelShape SHAPE=
            Block.box(0,0,0,16,15,16);

    public BlockState getStateForPlacement(BlockPlaceContext pContext) {
        Direction playerFacing = pContext.getHorizontalDirection();

        // 确保方向是有效的水平方向
        if (playerFacing.getAxis().isVertical()) {
            playerFacing = Direction.NORTH; // 默认值
        }
        return this.defaultBlockState().setValue(FACING, playerFacing.getOpposite());}

    public BlockState rotate(BlockState pState, Rotation pRotation){
        return pState.setValue(FACING,pRotation.rotate(pState.getValue(FACING)));
    }
    public BlockState mirror(BlockState pState, Mirror pMirror){
        return pState.rotate(pMirror.getRotation(pState.getValue(FACING)));
    }

    public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
        return SHAPE;}

    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return context.isAbove(Shapes.block(), pos, true) ? Shapes.empty() : SHAPE;
    }
    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        // 检测脚下位置（Y-1）是否有支撑方块
        BlockPos belowPos = pos.below();
        BlockState belowState = level.getBlockState(belowPos);
        if (!belowState.isFaceSturdy(level, belowPos, Direction.UP)) {
            return false; // 脚下无支撑方块时禁止放置
        }
        // 检测当前位置是否被实体占用（如玩家）
        VoxelShape shape = state.getCollisionShape(level, pos);
        if (!shape.isEmpty() && level.isUnobstructed(null, shape.move(pos.getX(), pos.getY(), pos.getZ()))) {
            return false; // 与实体碰撞箱重叠时禁止放置
        }
        return true;
    }
    @Override
    public VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
}
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide()) {
            ItemStack handItem = player.getItemInHand(hand);
            if (FishDecomposingConfig.canDecompose(handItem)) {
                List<ItemStack> decomposeResults;
                int fishLevel = 1;
                int quantity = handItem.getCount(); // 获取物品数量
                if (handItem.getItem() instanceof CustomFishTrophyItem) {
                    // 自定义鱼类 - 仍然一个一个处理，因为每个可能有不同属性
                    CustomFishTrophyItem fishItem = (CustomFishTrophyItem) handItem.getItem();
                    String fishType = fishItem.getCustomFishType();

                    CompoundTag fishData = CustomFishTrophyItem.getFishData(handItem);
                    if (fishData != null && fishData.contains("FishLevel")) {
                        fishLevel = fishData.getInt("FishLevel");
                    }
                    decomposeResults = FishDecomposingConfig.getDecomposeResults(fishType, fishLevel, level.random);
                    // 自定义鱼类的经验基于单个鱼的等级
                    generateExperienceOrbs(level, pos, fishLevel, level.random);
                } else {
                    // 原版鱼类 - 批量处理
                    decomposeResults = FishDecomposingConfig.getDecomposeResults(handItem.getItem(), quantity, level.random);
                    // 原版鱼类的经验基于数量
                    generateExperienceOrbsForVanillaFish(level, pos, quantity, level.random);
                }
                // 掉落物品结果
                for (ItemStack result : decomposeResults) {
                    if (!result.isEmpty()) {
                        popResource(level, pos, result);
                    }
                }
                // 消耗手中的物品
                handItem.setCount(0); // 直接清空，因为已经处理了所有数量
                return InteractionResult.SUCCESS;
            }
        }

        return InteractionResult.PASS;
    }
    private void generateExperienceOrbsForVanillaFish(Level level, BlockPos pos, int fishQuantity, RandomSource random) {
        if (level.isClientSide()) return;

        // 对于原版鱼类，基于数量给予经验
        int baseChance = Math.min(fishQuantity, 10); // 最多10个鱼的概率加成
        float expChance = 0.2f + (baseChance * 0.05f); // 基础20%，每个鱼增加5%

        if (random.nextFloat() < expChance) {
            // 经验值基于鱼的数量
            int expValue = 2 + random.nextInt(Math.max(1, fishQuantity / 3));

            double x = pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 0.5;
            double y = pos.getY() + 1.0;
            double z = pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 0.5;

            ExperienceOrb expOrb = new ExperienceOrb(level, x, y, z, expValue);
            level.addFreshEntity(expOrb);
        }
    }
    private void generateExperienceOrbs(Level level, BlockPos pos, int fishLevel, RandomSource random) {
        if (level.isClientSide()) return;
        // 基础经验值：等级越高给予的经验越多
        int baseExperience = Math.max(1, fishLevel / 5); // 每2级给1点基础经验
        // 30%概率获得经验球
        if (random.nextFloat() < 0.7f) {
            // 经验值范围：baseExperience 到 baseExperience + fishLevel
            int experienceAmount = baseExperience + random.nextInt(Math.max(1, fishLevel));

            // 在方块上方生成经验球，添加一些随机偏移
            double x = pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 0.5;
            double y = pos.getY() + 1.0;
            double z = pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 0.5;

            ExperienceOrb expOrb = new ExperienceOrb(level, x, y, z, experienceAmount);
            level.addFreshEntity(expOrb);
        }}
    private List<ItemStack> decomposeFish(ItemStack fishStack, RandomSource random) {
        if (fishStack.getItem() instanceof CustomFishTrophyItem) {
            CustomFishTrophyItem fishItem = (CustomFishTrophyItem) fishStack.getItem();
            String fishType = fishItem.getCustomFishType();

            // 获取鱼类等级
            int fishLevel = 1;
            CompoundTag fishData = CustomFishTrophyItem.getFishData(fishStack);
            if (fishData != null) {
                fishLevel = fishData.getInt("Level");
            }

            return FishDecomposingConfig.getDecomposeResults(fishType, fishLevel, random);
        } else {
            return FishDecomposingConfig.getDecomposeResults(fishStack.getItem(), random);
        }
    }
}
