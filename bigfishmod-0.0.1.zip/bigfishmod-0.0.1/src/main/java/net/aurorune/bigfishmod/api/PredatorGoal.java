package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

public class PredatorGoal extends Goal {
    private final AbstractCustomFish predator;
    private final double speedModifier;
    private final float attackDamage;
    private final int attackInterval;
    private final double detectionRange;
    private final double followRange;
    private final double attackRange; // 新增：攻击范围
    private final PredatorConfig[] preyConfigs;
    private final float huntProbability; // 新增：捕食概率
    private final int huntCooldown; // 新增：捕食冷却时间
    private static final int TICKS_PER_SECOND = 20;
    private static final int START_CHECK_INTERVAL_SECONDS = 5;
    private static final int START_CHECK_INTERVAL_TICKS = TICKS_PER_SECOND * START_CHECK_INTERVAL_SECONDS;
    private LivingEntity target;
    private int attackCooldown;
    private int seeTime;
    private int globalCooldown; // 新增：全局冷却计时器
    private boolean isInHuntState; // 新增：是否处于捕食状态
    private int startCheckTimerTicks = 0;
    // 配置常量
    private static final int MAX_SEE_TIME = 60;

    public PredatorGoal(AbstractCustomFish predator, double speedModifier, float attackDamage,
                        int attackInterval, double detectionRange, double followRange,
                        double attackRange, float huntProbability, int huntCooldown,
                        PredatorConfig[] preyConfigs) {
        this.predator = predator;
        this.speedModifier = speedModifier;
        this.attackDamage = attackDamage;
        this.attackInterval = attackInterval;
        this.detectionRange = detectionRange;
        this.followRange = followRange;
        this.attackRange = attackRange;
        this.huntProbability = huntProbability;
        this.huntCooldown = huntCooldown;
        this.preyConfigs = preyConfigs;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    // 为了方便，保留原有的构造函数
    @SafeVarargs
    public PredatorGoal(AbstractCustomFish predator, double speedModifier, float attackDamage,
                        int attackInterval, double detectionRange, double followRange,
                        Class<? extends LivingEntity>... preys) {
        this(predator, speedModifier, attackDamage, attackInterval, detectionRange, followRange,
                1.5, 0.3f, 200, // 默认值：攻击范围1.5，捕食概率30%，冷却200ticks
                convertToDefaultConfigs(preys));
    }

    // 将类数组转换为默认配置
    private static PredatorConfig[] convertToDefaultConfigs(Class<? extends LivingEntity>[] preys) {
        PredatorConfig[] configs = new PredatorConfig[preys.length];
        for (int i = 0; i < preys.length; i++) {
            configs[i] = new PredatorConfig(preys[i], 5, 30);
        }
        return configs;
    }

    @Override
    public boolean canUse() {
        // 每 tick 被调用，但我们只在计时器到期时做完整判定
        if (startCheckTimerTicks > 0) {
            startCheckTimerTicks--;
            return false;
        }
        // 计时器到期，下一次完整判断前先重置为间隔值（确保下次间隔）
        startCheckTimerTicks = START_CHECK_INTERVAL_TICKS;
        // 检查全局冷却
        if (globalCooldown > 0) {
            globalCooldown--;
            return false;
        }

        // 检查攻击冷却
        if (attackCooldown > 0) {
            attackCooldown--;
            return false;
        }

        // 如果不是在水中，不捕食
        if (!predator.isInWater()) {
            return false;
        }

        // 根据概率决定是否尝试捕食
        if (predator.getRandom().nextFloat() > huntProbability) {
            return false;
        }

        // 寻找附近的猎物
        this.target = findNearestPrey();
        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {
        // 如果不在捕食状态，直接返回false
        if (!isInHuntState) {
            return false;
        }

        if (target == null || !target.isAlive()) {
            endHunt();
            return false;
        }

        // 如果距离太远，停止追逐
        if (predator.distanceToSqr(target) > followRange * followRange) {
            endHunt();
            return false;
        }

        // 如果猎物不在水中，停止追逐
        if (!target.isInWater()) {
            endHunt();
            return false;
        }

        // 重新检查等级条件，确保仍然符合捕食条件
        if (!isValidPrey(target)) {
            endHunt();
            return false;
        }

        return true;
    }

    @Override
    public void start() {
        isInHuntState = true;
        predator.getNavigation().moveTo(target, speedModifier);
        seeTime = 0;
    }

    @Override
    public void stop() {
        endHunt();
    }

    /**
     * 结束捕食状态并设置冷却
     */
    private void endHunt() {
        isInHuntState = false;
        target = null;
        predator.getNavigation().stop();

        // 设置全局冷却时间
        globalCooldown = huntCooldown + predator.getRandom().nextInt(huntCooldown / 2);
    }

    @Override
    public void tick() {
        if (!isInHuntState) return;

        // 更新视线时间
        if (predator.getSensing().hasLineOfSight(target)) {
            seeTime = Math.min(seeTime + 1, MAX_SEE_TIME * 2);
        } else {
            seeTime = Math.max(seeTime - 1, 0);
        }

        // 看向目标
        predator.getLookControl().setLookAt(target, 30.0F, 30.0F);

        // 计算距离
        double distanceToTarget = predator.distanceToSqr(target);
        double actualAttackRange = getActualAttackRange();

        // 根据距离决定移动行为
        if (distanceToTarget > actualAttackRange * actualAttackRange * 4) {
            // 远距离 - 快速移动
            predator.getNavigation().moveTo(target, speedModifier * 1.2);
        } else if (distanceToTarget > actualAttackRange * actualAttackRange) {
            // 中等距离 - 正常速度
            predator.getNavigation().moveTo(target, speedModifier);
        } else {
            // 近距离 - 缓慢移动，准备攻击
            predator.getNavigation().moveTo(target, speedModifier * 0.7);
        }

        // 执行攻击
        if (--attackCooldown <= 0 && seeTime >= MAX_SEE_TIME &&
                distanceToTarget < actualAttackRange * actualAttackRange) {
            performAttack();
            attackCooldown = adjustedTickDelay(attackInterval);
        }

        // 如果追逐时间过长，有一定概率放弃
        if (seeTime > 300 && predator.getRandom().nextFloat() < 0.01F) {
            endHunt();
        }
    }

    /**
     * 计算实际攻击范围（基于配置和等级）
     */
    private double getActualAttackRange() {
        double levelBonus = predator.getLevel() * 0.01; // 每级增加0.05格范围
        return attackRange + levelBonus;
    }

    /**
     * 寻找最近的猎物
     */
    private LivingEntity findNearestPrey() {
        // 如果没有指定猎物配置，返回null
        if (preyConfigs == null || preyConfigs.length == 0) {
            return null;
        }

        // 获取附近的所有实体
        AABB searchArea = predator.getBoundingBox().inflate(detectionRange);
        List<LivingEntity> potentialTargets = predator.level().getEntitiesOfClass(
                LivingEntity.class, searchArea, this::isValidPrey
        );

        // 如果没有找到目标，返回null
        if (potentialTargets.isEmpty()) {
            return null;
        }

        // 按距离排序并选择最近的
        potentialTargets.sort(Comparator.comparingDouble(predator::distanceToSqr));
        return potentialTargets.get(0);
    }

    /**
     * 检查实体是否为有效猎物
     */
    private boolean isValidPrey(LivingEntity entity) {
        // 不攻击自己
        if (entity == predator) {
            return false;
        }

        // 不攻击已死亡的实体
        if (!entity.isAlive()) {
            return false;
        }

        // 只攻击在水中的生物
        if (!entity.isInWater()) {
            return false;
        }

        // 检查距离是否在检测范围内
        double distanceSq = predator.distanceToSqr(entity);
        if (distanceSq > detectionRange * detectionRange) {
            return false;
        }

        // 检查实体是否符合任何捕食配置
        for (PredatorConfig config : preyConfigs) {
            if (config.canPredate(predator, entity)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 执行攻击
     */
    private void performAttack() {
        // 计算精确的攻击距离
        double actualAttackRange = getActualAttackRange();
        double actualDistance = predator.distanceTo(target);

        // 确保在有效攻击范围内
        if (actualDistance > actualAttackRange + 0.5) {
            return; // 距离太远，不攻击
        }

        // 造成伤害
        boolean didDamage = target.hurt(
                predator.damageSources().mobAttack(predator),
                calculateDamage()
        );

        if (didDamage) {
            // 播放攻击声音
            predator.playSound(
                    SoundEvents.PLAYER_ATTACK_STRONG,
                    1.0F,
                    1.0F + (predator.getRandom().nextFloat() - predator.getRandom().nextFloat()) * 0.2F
            );

            // 击退效果
            double knockbackPower = 0.4D * (1.0 - actualDistance / (actualAttackRange + 1.0));
            Vec3 direction = predator.position().subtract(target.position()).normalize();

            target.setDeltaMovement(
                    target.getDeltaMovement().x + direction.x * knockbackPower,
                    target.getDeltaMovement().y + 0.1D,
                    target.getDeltaMovement().z + direction.z * knockbackPower
            );
            grantHuntingExperience();
            // 攻击成功后结束捕食状态并设置冷却
            endHunt();
        }
    }
    /**
     * 根据成功捕食给予经验奖励
     */
    private void grantHuntingExperience() {
        if (predator.level().isClientSide || target == null) {
            return;
        }
        // 基础经验值
        float baseExperience = 400f;
        // 根据目标类型调整经验值
        float experienceMultiplier = 1.0f;
        // 如果目标也是AbstractCustomFish，根据等级差异调整经验
        if (target instanceof AbstractCustomFish customFishTarget) {
            int levelDifference = customFishTarget.getLevel() ;
            // 捕食更高等级的鱼获得更多经验
            if (levelDifference > 20) {
                experienceMultiplier = 1.0f + (levelDifference * 0.1f);
            }
            // 根据目标大小调整经验（更大的鱼给更多经验）
            float targetScale = customFishTarget.getScale();
            experienceMultiplier *= (0.5f + targetScale * 0.5f);
        } else {
            // 对于其他生物，根据最大生命值调整经验
            float targetMaxHealth = target.getMaxHealth();
            experienceMultiplier = Math.max(0.5f, Math.min(2.0f, targetMaxHealth / 10.0f));
        }

        // 根据捕食者等级调整经验获取效率
        experienceMultiplier *= calculateExperienceMultiplierByLevel(predator.getLevel());

        // 计算最终经验值
        float finalExperience = baseExperience * experienceMultiplier;
        // 给予经验
        predator.addExperience(finalExperience);

        // 可选：在服务器端生成经验粒子效果
        spawnExperienceParticles(finalExperience);
    }

    /**
     * 根据等级计算经验获取效率
     */
    private float calculateExperienceMultiplierByLevel(int level) {
        if (level < 15) {
            return 1.5f; // 低等级鱼捕食经验效率高
        } else if (level < 30) {
            return 1.0f; // 中等级鱼正常经验效率
        } else {
            return 0.8f; // 高等级鱼经验效率较低
        }
    }

    /**
     * 生成经验获得的粒子效果
     */
    private void spawnExperienceParticles(float experience) {
        // 确保只在服务器端执行逻辑
        if (predator.level().isClientSide) {
            return;
        }

        Level level = predator.level();
        double x = predator.getX();
        // 调整Y坐标，让粒子集中在鱼的身体中部
        double y = predator.getY() + predator.getBbHeight() * 0.5;
        double z = predator.getZ();

        // 根据经验值计算粒子数量，最多不超过5个
        // Math.ceil(experience / 5.0) 确保即使经验值很小也会生成至少一个粒子
        int particleCount = (int) Math.min(5, Math.ceil(experience / 5.0));

        // 使用 BUBBLE 粒子，更符合水生生物的主题
        for (int i = 0; i < particleCount; i++) {
            // 缩小随机偏移量（例如从 2.0 缩小到 0.5），保证粒子在鱼的身上或周围
            double offsetX = (predator.getRandom().nextDouble() - 0.5) * 0.3;
            double offsetY = (predator.getRandom().nextDouble() - 0.5) * 0.3;
            double offsetZ = (predator.getRandom().nextDouble() - 0.5) * 0.3;

            ((ServerLevel) level).sendParticles(
                    ParticleTypes.COMPOSTER,
                    x + offsetX, y + offsetY, z + offsetZ,
                    1, // 粒子数量，这里是每次调用生成一个
                    0, 0, 0, // 粒子在三个轴上的速度，保持为 0
                    0.01 // 粒子速度的随机因子，设置得很小，让它们原地出现
            );
        }
    }
    /**
     * 计算攻击伤害
     */
    private float calculateDamage() {
        // 基础伤害 + 基于等级的加成
        float levelBonus = predator.getLevel() * 0.1f;
        return attackDamage + levelBonus + predator.getRandom().nextFloat() * 0.5f;
    }
}