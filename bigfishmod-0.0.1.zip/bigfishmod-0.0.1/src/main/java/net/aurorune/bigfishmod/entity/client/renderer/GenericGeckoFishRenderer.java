package net.aurorune.bigfishmod.entity.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;


@OnlyIn(Dist.CLIENT)
public class GenericGeckoFishRenderer<T extends AbstractCustomFish & GeoAnimatable> extends GeoEntityRenderer<T> {
    public GenericGeckoFishRenderer(EntityRendererProvider.Context renderManager, GeoModel<T> model) {
        super(renderManager, model);
        this.shadowRadius = 0.3f;
    }

    @Override
    public void render(T entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        float scale = 1.0f;
        if (entity instanceof AbstractCustomFish) {
            scale = ((AbstractCustomFish) entity).getScale();
        }
        poseStack.pushPose();
        poseStack.scale(scale, scale, scale);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }

    @Override
    protected float getDeathMaxRotation(T entity) {
        // 返回死亡时的最大旋转角度
        // 这个值会影响死亡时实体的旋转
        return 90.0F; // 使鱼能够侧倒
    }
}