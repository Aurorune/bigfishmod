package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public class ModModelLayers {
//    public static final ModelLayerLocation TESTFISH_LAYER = new ModelLayerLocation(
//            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "testfish_layer"), "main");
    public static final ModelLayerLocation LOACH_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "loach_layer"), "main");
}
