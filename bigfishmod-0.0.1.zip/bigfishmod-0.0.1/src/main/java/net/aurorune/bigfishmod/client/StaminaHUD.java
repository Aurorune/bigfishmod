package net.aurorune.bigfishmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.aurorune.bigfishmod.BigFishMod;
import net.minecraft.resources.ResourceLocation;
import net.aurorune.bigfishmod.capabilities.PlayerStaminaProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class StaminaHUD {

    // 常量定义
    private static final int MAX_DISPLAY_TIME = 2000; // 3秒后自动隐藏
    private static final float ANIMATION_SPEED = 0.1f; // 动画速度

    // HUD状态变量
    private static boolean staminaDisplayActive = false;
    private static long lastDisplayTime = 0;
    private static float currentDisplayOpacity = 0f; // 当前透明度 (0.0-1.0)
    private static float previousStaminaRatio = 1f; // 用于动画的先前耐力值

    // 气泡效果数据
    private static final List<Bubble> bubbles = new ArrayList<>();
    private static final Random random = new Random();
    private static long lastBubbleSpawnTime = 0;

    // ===== 新增边框纹理常量 =====
    private static final ResourceLocation STAMINA_BORDER = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/gui/stamina_border.png");
    private static final int BORDER_WIDTH = 85;  // 边框纹理宽度
    private static final int BORDER_HEIGHT = 11; // 边框纹理高度

    // 布局参数
    private static final int BAR_WIDTH = 81;
    private static final int BAR_HEIGHT = 7;

    // 气泡类
    private static class Bubble {
        float x, y;
        float size;
        float speed;
        float life;

        public Bubble(float x, float y) {
            this.x = x;
            this.y = y;
            this.size = 1 + random.nextFloat() * 1.5f;
            this.speed = 0.1f + random.nextFloat() * 0.15f;
            this.life = 1.0f;
        }

        public void update() {
            y -= speed; // 向上浮动
            life -= 0.01f;
        }

        public boolean isAlive() {
            return life > 0;
        }
    }

    public static boolean isDisplayActive() {
        return staminaDisplayActive;
    }

    // 修复后的HUD渲染实现
    public static final IGuiOverlay STAMINA_HUD = (gui, guiGraphics, partialTick, screenWidth, screenHeight) -> {
        if (currentDisplayOpacity <= 0.01f) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) return;

        // ===== 修复1：正确计算位置 =====
        int barX = screenWidth/2+BAR_WIDTH/5-5; // 水平居中
        int barY = screenHeight - 55; // 经验条上方位置

        // 获取耐力值
        player.getCapability(PlayerStaminaProvider.PLAYER_STAMINA).ifPresent(stamina -> {
            // 计算当前耐力比例 (0.0-1.0)
            float staminaRatio = (float) stamina.getStamina() / stamina.getMaxStamina();

            // 平滑动画效果
            float animatedRatio = Mth.lerp(ANIMATION_SPEED, previousStaminaRatio, staminaRatio);
            previousStaminaRatio = animatedRatio;

            // 设置透明度
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            // ===== 1. 绘制耐力条背景 =====
            int bgColor = applyAlpha(0x404040, currentDisplayOpacity);
            guiGraphics.fill(barX, barY, barX + BAR_WIDTH, barY + BAR_HEIGHT, bgColor);

            // ===== 2. 绘制耐力条填充 =====
            int fillWidth = (int)(BAR_WIDTH * animatedRatio);

            // 颜色渐变逻辑
            int color;
            if (animatedRatio > 0.7) {
                color = 0xFF00FF00; // 绿色 - 高耐力
            } else if (animatedRatio > 0.3) {
                color = 0xFFFFFF00; // 黄色 - 中等耐力
            } else {
                color = 0xFFFF0000; // 红色 - 低耐力
            }

            // 应用透明度
            color = applyAlpha(color, currentDisplayOpacity);

            // 绘制填充条
            guiGraphics.fill(barX, barY, barX + fillWidth, barY + BAR_HEIGHT, color);

            // ===== 3. 绘制气泡 =====（在耐力条上方）
            long currentTime = System.currentTimeMillis();

            // 生成新气泡
            if (currentTime - lastBubbleSpawnTime > 200) {
                lastBubbleSpawnTime = currentTime;
                // 气泡在耐力条内部生成（Y位置在耐力条范围内）
                bubbles.add(new Bubble(
                        barX + 5 + random.nextInt(BAR_WIDTH - 10),
                        barY + BAR_HEIGHT - random.nextInt(BAR_HEIGHT) - 1
                ));

                // 限制气泡数量
                if (bubbles.size() > 6) {
                    bubbles.remove(0);
                }
            }

            // 更新并绘制气泡
            for (int i = bubbles.size() - 1; i >= 0; i--) {
                Bubble bubble = bubbles.get(i);
                bubble.update();

                if (!bubble.isAlive()) {
                    bubbles.remove(i);
                    continue;
                }

                drawBubble(guiGraphics, bubble.x, bubble.y, bubble.size, bubble.life, currentDisplayOpacity);
            }

            // ===== 修复2：正确绘制边框纹理 =====
            RenderSystem.setShaderColor(1f, 1f, 1f, currentDisplayOpacity);
            RenderSystem.setShaderTexture(0, STAMINA_BORDER);

            // 计算边框位置（居中于耐力条）
            int borderX = screenWidth/2-BAR_WIDTH/5+22;
            int borderY = screenHeight - 65;

            // 绘制边框纹理
            guiGraphics.blit(
                    STAMINA_BORDER,
                    borderX,
                    borderY,
                    0,
                    0,
                    95,
                    25,
                    95,
                    25
            );

            // ===== 4. 绘制文本信息 =====（在最上层）
            // 标题文本
            String title = "耐力";
            int titleX = barX;
            int titleY = barY - 12; // 在边框上方
            int titleColor = applyAlpha(0xFFFFFF, currentDisplayOpacity);
            guiGraphics.drawString(
                    mc.font,
                    title,
                    titleX,
                    titleY,
                    titleColor,
                    false
            );

            // 耐力值文本
            String staminaText = String.format("%d/%d", stamina.getStamina(), stamina.getMaxStamina());
            int valueX = barX + BAR_WIDTH - mc.font.width(staminaText);
            int valueY = barY - 12; // 在边框上方
            guiGraphics.drawString(
                    mc.font,
                    staminaText,
                    valueX,
                    valueY,
                    titleColor,
                    false
            );

            // 重置渲染状态
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        });
    };

    // ===== 修复3：移除旧的玻璃边框绘制方法 =====
    // 删除以下方法：
    // private static void drawGlassBorderBackground(...)
    // private static void drawGlassBorderForeground(...)

    // 绘制气泡（在耐力条上方）
    private static void drawBubble(GuiGraphics guiGraphics, float x, float y, float size, float life, float alpha) {
        int bubbleAlpha = (int)(life * alpha * 200);
        int bubbleColor = (bubbleAlpha << 24) | 0xFFFFFF; // 白色气泡

        // 绘制气泡主体
        drawCircle(guiGraphics, x, y, size, bubbleColor);

        // 绘制气泡高光
        int highlightAlpha = (int)(life * alpha * 255);
        int highlightColor = (highlightAlpha << 24) | 0xFFFFFF;
        drawCircle(guiGraphics, x - size/3, y - size/3, size/3, highlightColor);
    }

    // 绘制圆形
    private static void drawCircle(GuiGraphics guiGraphics, float centerX, float centerY, float radius, int color) {
        int radiusInt = (int)radius;
        int centerXInt = (int)centerX;
        int centerYInt = (int)centerY;

        for (int dx = -radiusInt; dx <= radiusInt; dx++) {
            for (int dy = -radiusInt; dy <= radiusInt; dy++) {
                if (dx*dx + dy*dy <= radiusInt*radiusInt) {
                    guiGraphics.fill(centerXInt + dx, centerYInt + dy,
                            centerXInt + dx + 1, centerYInt + dy + 1,
                            color);
                }
            }
        }
    }

    // 应用透明度到颜色
    private static int applyAlpha(int color, float alpha) {
        int alphaValue = (int)(alpha * 255);
        return (alphaValue << 24) | (color & 0x00FFFFFF);
    }

    // 注册HUD
    public static void registerOverlay(RegisterGuiOverlaysEvent event) {
        // 在玩家生命值上方注册HUD
        event.registerAbove(VanillaGuiOverlay.PLAYER_HEALTH.id(), "stamina_hud", STAMINA_HUD);
    }

    // 更新显示状态
    public static void setDisplayActive(boolean active) {
        staminaDisplayActive = active;
        lastDisplayTime = System.currentTimeMillis();

        // 激活时清空气泡
        if (active) {
            bubbles.clear();
        }
    }

    // 更新透明度
    public static void updateAnimation() {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        boolean isFishing = player != null &&
                (player.getMainHandItem().getItem() instanceof FishingRodItem ||
                        player.getOffhandItem().getItem() instanceof FishingRodItem);

        // 自动显示/隐藏逻辑
        if (isFishing) {
            // 在钓鱼时持续显示
            staminaDisplayActive = true;
            lastDisplayTime = System.currentTimeMillis();
        } else if (staminaDisplayActive &&
                System.currentTimeMillis() - lastDisplayTime > MAX_DISPLAY_TIME) {
            staminaDisplayActive = false;
        }

        // 透明度动画
        if (staminaDisplayActive) {
            currentDisplayOpacity = Mth.lerp(ANIMATION_SPEED, currentDisplayOpacity, 1f);
        } else {
            currentDisplayOpacity = Mth.lerp(ANIMATION_SPEED, currentDisplayOpacity, 0f);
            // 隐藏时清空气泡
            if (currentDisplayOpacity < 0.01f) {
                bubbles.clear();
            }
        }
    }
}