package net.aurorune.bigfishmod.entity.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public class TestFishModel<T extends Entity> extends EntityModel<T> {
    // 使用与第一个模型相同的字段名称
    private final ModelPart root;
    private final ModelPart fishhead; // 对应 fishhead
    private final ModelPart bone; // 新增的 bone 部分
    private final ModelPart fishtail; // 对应 fishtail
    private final ModelPart fishbelly; // 对应 fishbelly
    private final ModelPart bone2 ;// 对应 bone2 或其他部分

    public TestFishModel(ModelPart root) {
        this.root = root.getChild("root");
        this.fishhead = this.root.getChild("fishhead");
        this.bone = this.root.getChild("bone"); // 初始化 bone
        this.fishtail = this.bone.getChild("fishtail");
        this.fishbelly = this.bone.getChild("fishbelly");
        this.bone2 = this.fishtail.getChild("bone2");
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition root = partdefinition.addOrReplaceChild("root", CubeListBuilder.create(),
                PartPose.offsetAndRotation(-0.025F, 23.0F, -0.675F, 0.0F, -1.5708F, 0.0F));

        // 鱼头 (body)
        PartDefinition fishhead = root.addOrReplaceChild("fishhead",
                CubeListBuilder.create().texOffs(0, 0).addBox(-2.1667F, -1.7357F, -0.5012F, 3.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
                PartPose.offset(-1.0777F, -0.0421F, -0.0108F));

        // 添加背鳍和腹鳍
        fishhead.addOrReplaceChild("dorsal_fin",
                CubeListBuilder.create().texOffs(8, 6).addBox(-1.5F, -0.5F, 0.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
                PartPose.offsetAndRotation(1.3333F, -0.1321F, 0.8631F, 1.3963F, 0.0F, 0.0F));

        fishhead.addOrReplaceChild("ventral_fin",
                CubeListBuilder.create().texOffs(8, 5).addBox(-1.5F, -0.5F, 0.0F, 1.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
                PartPose.offsetAndRotation(1.3583F, -0.0572F, -0.8869F, -1.3963F, 0.0F, 0.0F));

        // 鱼尾 (tail)
        PartDefinition bone = root.addOrReplaceChild("bone", CubeListBuilder.create(),
                PartPose.offset(-0.2694F, -1.5278F, -0.012F));

        PartDefinition fishtail = bone.addOrReplaceChild("fishtail",
                CubeListBuilder.create().texOffs(0, 3).addBox(-0.1437F, -1.125F, -0.55F, 3.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
                PartPose.offset(3.1687F, 0.875F, 0.05F));

        // 尾鳍 (leftFin)
        fishtail.addOrReplaceChild("bone2",
                CubeListBuilder.create().texOffs(8, 0).addBox(0.0039F, -2.0F, -0.1305F, 1.975F, 4.0F, 0.0F, new CubeDeformation(0.0F)),
                PartPose.offset(2.962F, 0.125F, 0.1462F));

        // 鱼腹 (rightFin)
        bone.addOrReplaceChild("fishbelly",
                CubeListBuilder.create()
                        .texOffs(0, 6).addBox(0.025F, -0.25F, -0.5F, 3.0F, 2.0F, 1.0F, new CubeDeformation(0.0F))
                        .texOffs(8, 4).addBox(0.025F, -1.25F, 0.0F, 3.0F, 1.0F, 0.0F, new CubeDeformation(0.0F)),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        return LayerDefinition.create(meshdefinition, 16, 16);
    }
    public void resetPose() {
        // 重置所有旋转
        this.bone.yRot = 0;
        this. fishtail.yRot = 0;
        this.bone2.yRot = 0;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity == null) {
            // 使用基于时间的动画
            float speed = 0.3f;
            float amplitude = 0.2f;
            float time = ageInTicks * speed;
            resetPose();
            return;
        }
        // 更平滑的游泳动画实现
        float speed = 0.3f; // 摆动速度
        float amplitude = 0.2f; // 摆动幅度
        // 使用正弦函数创建波浪式摆动效果
        float time = ageInTicks * speed;
        // 头部和身体轻微摆动
        this.bone.yRot = Mth.sin(time + 0.3f) * amplitude * 0.7f;
        // 尾部更大幅度的摆动
        this. fishtail.yRot = Mth.sin(time + 0.6f) * amplitude * 1.2f;
        // 尾鳍摆动
        this.bone2.yRot = Mth.sin(time + 0.9f) * amplitude * 1.5f;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer,
                               int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay);
    }
}
