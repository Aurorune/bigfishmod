package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.aurorune.bigfishmod.item.ModCreativeModeTab;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.util.KeyBindings;
import net.aurorune.bigfishmod.villager.ModVillagers;
import net.minecraft.data.PackOutput;

import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraftforge.common.data.LanguageProvider;
import net.minecraftforge.registries.ForgeRegistries;

//翻译
public class ModLangGen extends LanguageProvider {
    private final String locale;
    public ModLangGen (PackOutput output,String locale){
        super(output, BigFishMod.MOD_ID,locale);
        this.locale = locale; // 初始化语言代码
    }
    @Override
    protected void addTranslations() {
        if ("en_us".equals(locale)) {
            addEnUsTranslations();
        } else if ("zh_cn".equals(locale)) {
            addZhCnTranslations();
        }
        
    }

    private void addEnUsTranslations() {
        add(ModCreativeModeTab.BIGFISH_TAB_STRING, "Big Fish Tab");

        // Basic materials
        add(ModItems.COLORFUL_SCALES.get(), "Colorful Scales");
        add(ModItems.GOLDEN_SCALES.get(), "Golden Scales");
        add(ModItems.SILVER_SCALES.get(), "Silver Scales");
        add(ModItems.GRAPHITE.get(), "Graphite");
        add(ModItems.DUNKLEOSTEUS_CRUSHED_BONE.get(), "Dunkleosteus Crushed Bone");
        add(ModItems.CARBON_FIBRE.get(), "Carbon Fiber");
        add(ModItems.WOODEN_BUCKET.get(), "Wooden Bucket");
        // Fish products
        // 英文语言文件翻译
        add(ModItems.BELUGA_STURGEON_MEAT.get(), "White Fish Meat");
        add(ModItems.PERCH_FILLET.get(), "Firm Fish Meat");
        add(ModItems.BULK_FISH_MEAT.get(), "Thick Fish Chunk");
        add(ModItems.PRIME_TUNA_MEAT.get(), "Fatty Fish Meat");
        add(ModItems.SAILFISH_STEAK.get(), "Prime Fish Steak");
        add(ModItems.FISH_FILLET_A.get(), "Fish Meat");
        add(ModItems.FISH_FILLET_B.get(), "Thick Fish Steak");

// 对应的熟制版本
        add(ModItems.COOKED_STURGEON_MEAT.get(), "Cooked White Fish Meat");
        add(ModItems.COOKED_PERCH_FILLET.get(), "Cooked Firm Fish Meat");
        add(ModItems.COOKED_BULK_FISH_MEAT.get(), "Cooked Thick Fish Chunk");
        add(ModItems.COOKED_PREMIUM_TUNA_MEAT.get(), "Cooked Fatty Fish Meat");
        add(ModItems.COOKED_SAILFISH_STEAK.get(), "Cooked Prime Fish Steak");
        add(ModItems.COOKED_FISH_FILLET_A.get(), "Cooked Fish Meat");
        add(ModItems.COOKED_FISH_FILLET_B.get(), "Cooked Thick Fish Steak");




        add(ModItems.BLACK_CAVIAR.get(), "Black Caviar");
        add(ModItems.LUCKY_STAR.get(), "Lucky Star");
        add(ModItems.PUTRID_GLAND.get(), "Putrid Gland");
        add(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), "Active Swim Bladder Gland");
        add(ModItems.ANCIENT_GASTROLITH.get(), "Ancient Gastrolith");
        add(ModItems.CONCEBTRATED_PHEROMONER.get(), "Concentrated Pheromones");
        add(ModItems.ACERATED_SEAWEED.get(), "Acerated Seaweed");
        add(ModItems.FISH_OIL.get(), "Fish Oil");
        add(ModItems.FISHBOOK.get(), "Book");
        add(ModItems.MEAT_FEED.get(), "Meat Feed");
        add(ModItems.OCEAN_GEM.get(), "Ocean Gem");
        add(ModItems.ROE.get(), "Roe");
        add(ModItems.SEA_BREEZE_ESSENCE.get(), "Sea Breeze Essence");
        add(ModItems.SHARP_FISH_TOOTH.get(), "Sharp Fish Tooth");
        add(ModItems.SWORDFISH_BILL.get(), "Swordfish Bill");
        add(ModItems.VEGETARIAN_FEED.get(), "Vegetarian Feed");
        add(ModItems.WATER_DROPLET.get(), "Water Droplet");

        // Crops
        add(ModItems.CORN_SEED.get(), "Corn Seed");
        add(ModItems.CORN.get(), "Corn");
        add(ModItems.TROPHY_BASE.get(), "Fish Display Box");
        addVillager(ModVillagers.FISH_MONGER.get(), "Fishmonger");

        // Fishing rods
        add(ModItems.IRON_FISHING_ROD.get(), "Iron Fishing Rod");
        add(ModItems.GOLD_FISHING_ROD.get(), "Gold Fishing Rod");
        add(ModItems.DIAMOND_FISHING_ROD.get(), "Diamond Fishing Rod");
        add(ModItems.CARBON_FIBER_FISHING_ROD.get(), "Carbon Fiber Fishing Rod");
        add(ModItems.ROD.get(), "Rod");

        // Test Fish
        add(ModItems.TESTFISH.get(), "Test Fish");
        add(ModItems.TESTFISH_ITEM.get(), "Test Fish");
        add(ModItems.TESTFISH_BUCKET.get(), "Bucket of Test Fish");
        add(ModItems.TEXTFISH_WOODEN.get(), "Wooden Bucket of Test Fish");
        add("entity.bigfishmod.testfish", "Test Fish");

        // Loach
        add(ModItems.LOACH.get(), "Loach");
        add(ModItems.LOACH_ITEM.get(), "Loach");
        add(ModItems.LOACH_BUCKET.get(), "Bucket of Loach");
        add(ModItems.LOACH_WOODEN.get(), "Wooden Bucket of Loach");

        // Minnow
        add(ModItems.MINNOW.get(), "Minnow");
        add(ModItems.MINNOW_ITEM.get(), "Minnow");
        add(ModItems.MINNOW_BUCKET.get(), "Bucket of Minnow");
        add(ModItems.MINNOW_WOODEN.get(), "Wooden Bucket of Minnow");

        // Piranha
        add(ModItems.PIRANHA.get(), "Piranha");
        add(ModItems.PIRANHA_ITEM.get(), "Piranha");
        add(ModItems.PIRANHA_BUCKET.get(), "Bucket of Piranha");
        add(ModItems.PIRANHA_WOODEN.get(), "Wooden Bucket of Piranha");

        // Sardine
        add(ModItems.SARDINE.get(), "Sardine");
        add(ModItems.SARDINE_ITEM.get(), "Sardine");
        add(ModItems.SARDINE_BUCKET.get(), "Bucket of Sardine");
        add(ModItems.SARDINE_WOODEN.get(), "Wooden Bucket of Sardine");

        // Plecostomus
        add(ModItems.PLECOSTOMUS.get(), "Plecostomus");
        add(ModItems.PLECOSTOMUS_ITEM.get(), "Plecostomus");
        add(ModItems.PLECOSTOMUS_BUCKET.get(), "Bucket of Plecostomus");
        add(ModItems.PLECOSTOMUS_WOODEN.get(), "Wooden Bucket of Plecostomus");

        // Beluga Sturgeon
        add(ModItems.BELUGA_STURGEON.get(), "Beluga Sturgeon");
        add(ModItems.BELUGA_STURGEON_ITEM.get(), "Beluga Sturgeon");
        add(ModItems.BELUGA_STURGEON_BUCKET.get(), "Bucket of Beluga Sturgeon");
        add(ModItems.BELUGA_STURGEON_WOODEN.get(), "Wooden Bucket of Beluga Sturgeon");

        // Nile Perch
        add(ModItems.NILE_PERCH.get(), "Nile Perch");
        add(ModItems.NILE_PERCH_ITEM.get(), "Nile Perch");
        add(ModItems.NILE_PERCH_BUCKET.get(), "Bucket of Nile Perch");
        add(ModItems.NILE_PERCH_WOODEN.get(), "Wooden Bucket of Nile Perch");

        // Mekong Giant Catfish
        add(ModItems.MEKONG_GIANT_CATFISH.get(), "Mekong Giant Catfish");
        add(ModItems.MEKONG_GIANT_CATFISH_ITEM.get(), "Mekong Giant Catfish");
        add(ModItems.MEKONG_GIANT_CATFISH_BUCKET.get(), "Bucket of Mekong Giant Catfish");
        add(ModItems.MEKONG_GIANT_CATFISH_WOODEN.get(), "Wooden Bucket of Mekong Giant Catfish");

        // Tilapia
        add(ModItems.TILAPIA.get(), "Tilapia");
        add(ModItems.TILAPIA_ITEM.get(), "Tilapia");
        add(ModItems.TILAPIA_BUCKET.get(), "Bucket of Tilapia");
        add(ModItems.TILAPIA_WOODEN.get(), "Wooden Bucket of Tilapia");

        // Guppy
        add(ModItems.GUPPY.get(), "Guppy");
        add(ModItems.GUPPY_ITEM.get(), "Guppy");
        add(ModItems.GUPPY_BUCKET.get(), "Bucket of Guppy");
        add(ModItems.GUPPY_WOODEN.get(), "Wooden Bucket of Guppy");

        // Sailfish
        add(ModItems.SAILFISH.get(), "Sailfish");
        add(ModItems.SAILFISH_ITEM.get(), "Sailfish");
        add(ModItems.SAILFISH_BUCKET.get(), "Bucket of Sailfish");
        add(ModItems.SAILFISH_WOODEN.get(), "Wooden Bucket of Sailfish");

        // Haddock
        add(ModItems.HADDOCK.get(), "Haddock");
        add(ModItems.HADDOCK_ITEM.get(), "Haddock");
        add(ModItems.HADDOCK_BUCKET.get(), "Bucket of Haddock");
        add(ModItems.HADDOCK_WOODEN.get(), "Wooden Bucket of Haddock");

        // Northern Pike
        add(ModItems.NORTHERN_PIKE.get(), "Northern Pike");
        add(ModItems.NORTHERN_PIKE_ITEM.get(), "Northern Pike");
        add(ModItems.NORTHERN_PIKE_BUCKET.get(), "Bucket of Northern Pike");
        add(ModItems.NORTHERN_PIKE_WOODEN.get(), "Wooden Bucket of Northern Pike");

        // Siamese Fighting Fish
        add(ModItems.SIAMESE_FIGHTING_FISH.get(), "Siamese Fighting Fish");
        add(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get(), "Siamese Fighting Fish");
        add(ModItems.SIAMESE_FIGHTING_FISH_BUCKET.get(), "Bucket of Siamese Fighting Fish");
        add(ModItems.SIAMESE_FIGHTING_FISH_WOODEN.get(), "Wooden Bucket of Siamese Fighting Fish");

        // Lanternfish
        add(ModItems.LANTERNFISH.get(), "Lanternfish");
        add(ModItems.LANTERNFISH_ITEM.get(), "Lanternfish");
        add(ModItems.LANTERNFISH_BUCKET.get(), "Bucket of Lanternfish");
        add(ModItems.LANTERNFISH_WOODEN.get(), "Wooden Bucket of Lanternfish");

        // Atlantic Bluefin Tuna
        add(ModItems.ATLANTIC_BLUEFIN_TUNA.get(), "Atlantic Bluefin Tuna");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get(), "Atlantic Bluefin Tuna");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_BUCKET.get(), "Bucket of Atlantic Bluefin Tuna");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_WOODEN.get(), "Wooden Bucket of Atlantic Bluefin Tuna");

        // Grass Carp
        add(ModItems.GRASS_CARP.get(), "Grass Carp");
        add(ModItems.GRASS_CARP_ITEM.get(), "Grass Carp");
        add(ModItems.GRASS_CARP_BUCKET.get(), "Bucket of Grass Carp");
        add(ModItems.GRASS_CARP_WOODEN.get(), "Wooden Bucket of Grass Carp");

        // Archer Fish
        add(ModItems.ARCHER_FISH.get(), "Archer Fish");
        add(ModItems.ARCHER_FISH_ITEM.get(), "Archer Fish");
        add(ModItems.ARCHER_FISH_BUCKET.get(), "Bucket of Archer Fish");
        add(ModItems.ARCHER_FISH_WOODEN.get(), "Wooden Bucket of Archer Fish");

        // Blocks
        add(ModBlocks.FISH_STAND.get(), "Fish Stand");
        add(ModBlocks.FISH_BOX.get(), "Fish Box");
        add("container.bigfishmod.fish_box", "Fish Box");
        add(ModBlocks.GRAPHITE_BLOCK.get(), "Graphite Block");
        add(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get(), "Deepslate Graphite Ore");
        add(ModBlocks.GRAPHITE_ORE.get(), "Graphite Ore");

        // Attributes
        add("attribute.name.bigfishmod.strength", "Strength");
        add("attribute.name.bigfishmod.stamina", "Stamina");
        add("attribute.name.bigfishmod.perception", "Perception");
        add("attribute.name.bigfishmod.luck", "Luck");
        add("attribute.name.bigfishmod.weight", "Weight");

        // Size stages
        add("stage.bigfishmod.baby", "Baby");
        add("stage.bigfishmod.seedling", "Seedling");
        add("stage.bigfishmod.juvenile", "Juvenile");
        add("stage.bigfishmod.young", "Young");
        add("stage.bigfishmod.adult", "Adult");
        add("stage.bigfishmod.prime", "Prime");
        add("stage.bigfishmod.mature", "Mature");
        add("stage.bigfishmod.rare", "Rare");
        add("stage.bigfishmod.epic", "Epic");
        add("stage.bigfishmod.legend", "Legend");
        add("tooltip.bigfishmod.lucky_star_info", "A shimmering star that grants a random boon... or a curse.");
        // Tooltips
        add("tooltip.bigfishmod.fishbook", "Not made");
        add("tooltip.bigfishmod.display", "Display");
        add("tooltip.bigfishmod.level", "Level: %s/%s");
        add("tooltip.bigfishmod.size_stage", "Size Stage: %s");
        add("tooltip.bigfishmod.strength", "Strength: %.1f");
        add("tooltip.bigfishmod.stamina", "Stamina: %.1f");
        add("tooltip.bigfishmod.perception", "Perception: %.1f");
        add("tooltip.bigfishmod.luck", "Luck: %.1f");
        add("tooltip.bigfishmod.growth", "Growth: %s");
        add("tooltip.bigfishmod.weight", "Weight: %s kg");
        add(KeyBindings.KEY_CATEGORY_BIGFISH, "Big Fish Mod")
        ;
        add("item.bigfishmod.uses.remaining", "uses remaining：%d");
        add("item.bigfishmod.ocean_gem.tooltip", "A shimmering gem from the depths of the ocean, a radiant relic that whispers the secrets of the deep.");
        add("item.bigfishmod.sea_breeze_essence.tooltip", "A breeze captured from the ocean's heart, a fleeting essence that carries the whispers of the wind.");
        // Lucky Star messages
        add("message.bigfishmod.lucky_star.positive_minor1", "A glimmer of fortune!");
        add("message.bigfishmod.lucky_star.positive_minor2", "The stars align for you.");
        add("message.bigfishmod.lucky_star.positive_minor3", "You feel a light blessing.");
        add("message.bigfishmod.lucky_star.positive_minor4", "Destiny smiles upon you.");
        add("message.bigfishmod.lucky_star.positive_minor5", "A gentle celestial breeze.");
        add("message.bigfishmod.lucky_star.positive_minor6", "The stars whisper good omens.");

        add("message.bigfishmod.lucky_star.positive_major1", "An epic blessing!");
        add("message.bigfishmod.lucky_star.positive_major2", "The cosmos favor you greatly.");
        add("message.bigfishmod.lucky_star.positive_major3", "Stellar energy courses through you!");
        add("message.bigfishmod.lucky_star.positive_major4", "Divine blessings descend!");
        add("message.bigfishmod.lucky_star.positive_major5", "Stellar fortune shines brightly!");

        add("message.bigfishmod.lucky_star.mixed1", "The star's light is twisted...");
        add("message.bigfishmod.lucky_star.mixed2", "A mixed bag of fate.");
        add("message.bigfishmod.lucky_star.mixed3", "Chaos and order dance together.");
        add("message.bigfishmod.lucky_star.mixed4", "The starlight trembles...");
        add("message.bigfishmod.lucky_star.mixed5", "he scales of fate are wavering...");

        add("message.bigfishmod.lucky_star.jackpot1", "A cosmic miracle!");
        add("message.bigfishmod.lucky_star.jackpot2", "Extraordinary luck embraces you!");
        add("message.bigfishmod.lucky_star.jackpot3", "The universe itself blesses you!");
        add("message.bigfishmod.lucky_star.jackpot4", "Stellar harmony resonates within!");
        add("message.bigfishmod.lucky_star.jackpot5", "The stars crown you!");

        add("message.bigfishmod.lucky_star.curse1", "The star has cursed you!");
        add("message.bigfishmod.lucky_star.curse2", "Dark energies corrupt the starlight!");
        add("message.bigfishmod.lucky_star.curse3", "A malevolent fate unfolds...");
        add("message.bigfishmod.lucky_star.curse4", "The stars weep black tears!");
        add("message.bigfishmod.lucky_star.curse5", "Cosmic misfortune befalls you!");
    }

    private void addZhCnTranslations() {
        add(ModCreativeModeTab.BIGFISH_TAB_STRING, "巨物传说物品栏");

        // 基础材料
        add(ModItems.COLORFUL_SCALES.get(), "彩鳞");
        add(ModItems.GOLDEN_SCALES.get(), "金鳞");
        add(ModItems.SILVER_SCALES.get(), "银鳞");
        add(ModItems.GRAPHITE.get(), "石墨");
        add(ModItems.DUNKLEOSTEUS_CRUSHED_BONE.get(), "邓氏鱼骨片");
        add(ModItems.CARBON_FIBRE.get(), "碳纤维");
        add(ModItems.WOODEN_BUCKET.get(), "木桶");
        // 鱼类制品
        add(ModItems.BELUGA_STURGEON_MEAT.get(), "白鱼肉");
        add(ModItems.PERCH_FILLET.get(), "劲道鱼肉");
        add(ModItems.BULK_FISH_MEAT.get(), "大块鱼肉");
        add(ModItems.PRIME_TUNA_MEAT.get(), "肥美鱼肉");
        add(ModItems.SAILFISH_STEAK.get(), "优质鱼排");
        add(ModItems.FISH_FILLET_A.get(), "鱼肉");
        add(ModItems.FISH_FILLET_B.get(), " 厚切鱼排");
        add(ModItems.COOKED_STURGEON_MEAT.get(), "熟白鱼肉");
        add(ModItems.COOKED_PERCH_FILLET.get(), "熟劲道鱼肉");
        add(ModItems.COOKED_BULK_FISH_MEAT.get(), "熟大块鱼肉");
        add(ModItems.COOKED_PREMIUM_TUNA_MEAT.get(), "熟肥美鱼肉");
        add(ModItems.COOKED_SAILFISH_STEAK.get(), "熟优质鱼排");
        add(ModItems.COOKED_FISH_FILLET_A.get(), "熟鱼肉");
        add(ModItems.COOKED_FISH_FILLET_B.get(), "熟厚切鱼排");

        add(ModItems.BLACK_CAVIAR.get(), "黑鱼子酱");
        add(ModItems.LUCKY_STAR.get(), "幸运星");
        add(ModItems.PUTRID_GLAND.get(), "腥臭腺体");
        add(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), "活性水肺腺体");
        add(ModItems.ANCIENT_GASTROLITH.get(), "远古胃石");
        add(ModItems.CONCEBTRATED_PHEROMONER.get(), "浓缩信息素");
        add(ModItems.ACERATED_SEAWEED.get(), "草叶残渣");
        add(ModItems.FISH_OIL.get(), "鱼油");
        add(ModItems.FISHBOOK.get(), "书");
        add(ModItems.MEAT_FEED.get(), "肉类饲料");
        add(ModItems.OCEAN_GEM.get(), "海洋宝石");
        add(ModItems.ROE.get(), "鱼卵");
        add(ModItems.SEA_BREEZE_ESSENCE.get(), "海风精华");
        add(ModItems.SHARP_FISH_TOOTH.get(), "锋利鱼牙");
        add(ModItems.SWORDFISH_BILL.get(), "剑鱼头骨");
        add(ModItems.VEGETARIAN_FEED.get(), "素食饲料");
        add(ModItems.WATER_DROPLET.get(), "水滴");

        // 作物
        add(ModItems.CORN_SEED.get(), "玉米种子");
        add(ModItems.CORN.get(), "玉米");
        add(ModItems.TROPHY_BASE.get(), "鱼类展示框");
        addVillager(ModVillagers.FISH_MONGER.get(), "鱼贩");

        // 钓鱼竿
        add(ModItems.IRON_FISHING_ROD.get(), "铁鱼竿");
        add(ModItems.GOLD_FISHING_ROD.get(), "金鱼竿");
        add(ModItems.DIAMOND_FISHING_ROD.get(), "钻石鱼竿");
        add(ModItems.CARBON_FIBER_FISHING_ROD.get(), "碳纤维鱼竿");
        add(ModItems.ROD.get(), "竿");

        // 测试鱼
        add(ModItems.TESTFISH.get(), "测试鱼");
        add(ModItems.TESTFISH_ITEM.get(), "测试鱼");
        add(ModItems.TESTFISH_BUCKET.get(), "测试鱼桶");
        add(ModItems.TEXTFISH_WOODEN.get(), "测试鱼木桶");
        add("entity.bigfishmod.testfish", "测试鱼");

        // 泥鳅
        add(ModItems.LOACH.get(), "泥鳅");
        add(ModItems.LOACH_ITEM.get(), "泥鳅");
        add(ModItems.LOACH_BUCKET.get(), "泥鳅桶");
        add(ModItems.LOACH_WOODEN.get(), "泥鳅木桶");

        // 鲦鱼
        add(ModItems.MINNOW.get(), "鲦鱼");
        add(ModItems.MINNOW_ITEM.get(), "鲦鱼");
        add(ModItems.MINNOW_BUCKET.get(), "鲦鱼桶");
        add(ModItems.MINNOW_WOODEN.get(), "鲦鱼木桶");

        // 食人鱼
        add(ModItems.PIRANHA.get(), "食人鱼");
        add(ModItems.PIRANHA_ITEM.get(), "食人鱼");
        add(ModItems.PIRANHA_BUCKET.get(), "食人鱼桶");
        add(ModItems.PIRANHA_WOODEN.get(), "食人鱼木桶");

        // 沙丁鱼
        add(ModItems.SARDINE.get(), "沙丁鱼");
        add(ModItems.SARDINE_ITEM.get(), "沙丁鱼");
        add(ModItems.SARDINE_BUCKET.get(), "沙丁鱼桶");
        add(ModItems.SARDINE_WOODEN.get(), "沙丁鱼木桶");

        // 清道夫鱼
        add(ModItems.PLECOSTOMUS.get(), "清道夫鱼");
        add(ModItems.PLECOSTOMUS_ITEM.get(), "清道夫鱼");
        add(ModItems.PLECOSTOMUS_BUCKET.get(), "清道夫鱼桶");
        add(ModItems.PLECOSTOMUS_WOODEN.get(), "清道夫鱼木桶");

        // 白鲸鲟
        add(ModItems.BELUGA_STURGEON.get(), "欧鲟");
        add(ModItems.BELUGA_STURGEON_ITEM.get(), "欧鲟");
        add(ModItems.BELUGA_STURGEON_BUCKET.get(), "欧鲟");
        add(ModItems.BELUGA_STURGEON_WOODEN.get(), "欧鲟木桶");

        // 尼罗河鲈鱼
        add(ModItems.NILE_PERCH.get(), "尼罗河鲈鱼");
        add(ModItems.NILE_PERCH_ITEM.get(), "尼罗河鲈鱼");
        add(ModItems.NILE_PERCH_BUCKET.get(), "尼罗河鲈鱼桶");
        add(ModItems.NILE_PERCH_WOODEN.get(), "尼罗河鲈鱼木桶");

        // 湄公河巨鲶
        add(ModItems.MEKONG_GIANT_CATFISH.get(), "湄公河巨鲶");
        add(ModItems.MEKONG_GIANT_CATFISH_ITEM.get(), "湄公河巨鲶");
        add(ModItems.MEKONG_GIANT_CATFISH_BUCKET.get(), "湄公河巨鲶桶");
        add(ModItems.MEKONG_GIANT_CATFISH_WOODEN.get(), "湄公河巨鲶木桶");

        // 罗非鱼
        add(ModItems.TILAPIA.get(), "罗非鱼");
        add(ModItems.TILAPIA_ITEM.get(), "罗非鱼");
        add(ModItems.TILAPIA_BUCKET.get(), "罗非鱼桶");
        add(ModItems.TILAPIA_WOODEN.get(), "罗非鱼木桶");

        // 孔雀鱼
        add(ModItems.GUPPY.get(), "孔雀鱼");
        add(ModItems.GUPPY_ITEM.get(), "孔雀鱼");
        add(ModItems.GUPPY_BUCKET.get(), "孔雀鱼桶");
        add(ModItems.GUPPY_WOODEN.get(), "孔雀鱼木桶");

        // 旗鱼
        add(ModItems.SAILFISH.get(), "旗鱼");
        add(ModItems.SAILFISH_ITEM.get(), "旗鱼");
        add(ModItems.SAILFISH_BUCKET.get(), "旗鱼桶");
        add(ModItems.SAILFISH_WOODEN.get(), "旗鱼木桶");

        // 黑线鳕
        add(ModItems.HADDOCK.get(), "黑线鳕");
        add(ModItems.HADDOCK_ITEM.get(), "黑线鳕");
        add(ModItems.HADDOCK_BUCKET.get(), "黑线鳕桶");
        add(ModItems.HADDOCK_WOODEN.get(), "黑线鳕木桶");

        // 北方狗鱼
        add(ModItems.NORTHERN_PIKE.get(), "狗鱼");
        add(ModItems.NORTHERN_PIKE_ITEM.get(), "狗鱼");
        add(ModItems.NORTHERN_PIKE_BUCKET.get(), "狗鱼桶");
        add(ModItems.NORTHERN_PIKE_WOODEN.get(), "狗鱼木桶");

        // 暹罗斗鱼
        add(ModItems.SIAMESE_FIGHTING_FISH.get(), "暹罗斗鱼");
        add(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get(), "暹罗斗鱼");
        add(ModItems.SIAMESE_FIGHTING_FISH_BUCKET.get(), "暹罗斗鱼桶");
        add(ModItems.SIAMESE_FIGHTING_FISH_WOODEN.get(), "暹罗斗鱼木桶");

        // 灯笼鱼
        add(ModItems.LANTERNFISH.get(), "灯笼鱼");
        add(ModItems.LANTERNFISH_ITEM.get(), "灯笼鱼");
        add(ModItems.LANTERNFISH_BUCKET.get(), "灯笼鱼桶");
        add(ModItems.LANTERNFISH_WOODEN.get(), "灯笼鱼木桶");

        // 大西洋蓝鳍金枪鱼
        add(ModItems.ATLANTIC_BLUEFIN_TUNA.get(), "大西洋蓝鳍金枪鱼");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get(), "大西洋蓝鳍金枪鱼");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_BUCKET.get(), "大西洋蓝鳍金枪鱼桶");
        add(ModItems.ATLANTIC_BLUEFIN_TUNA_WOODEN.get(), "大西洋蓝鳍金枪鱼木桶");

        // 草鱼
        add(ModItems.GRASS_CARP.get(), "草鱼");
        add(ModItems.GRASS_CARP_ITEM.get(), "草鱼");
        add(ModItems.GRASS_CARP_BUCKET.get(), "草鱼桶");
        add(ModItems.GRASS_CARP_WOODEN.get(), "草鱼木桶");

        // 射水鱼
        add(ModItems.ARCHER_FISH.get(), "射水鱼");
        add(ModItems.ARCHER_FISH_ITEM.get(), "射水鱼");
        add(ModItems.ARCHER_FISH_BUCKET.get(), "射水鱼桶");
        add(ModItems.ARCHER_FISH_WOODEN.get(), "射水鱼木桶");

        // 方块
        add(ModBlocks.FISH_STAND.get(), "鱼摊");
        add(ModBlocks.FISH_BOX.get(), "鱼箱");
        add("container.bigfishmod.fish_box", "鱼箱");
        add(ModBlocks.GRAPHITE_BLOCK.get(), "石墨块");
        add(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get(), "深板岩石墨矿");
        add(ModBlocks.GRAPHITE_ORE.get(), "石墨矿");

        // 属性
        add("attribute.name.bigfishmod.strength", "力量");
        add("attribute.name.bigfishmod.stamina", "耐力");
        add("attribute.name.bigfishmod.perception", "感知");
        add("attribute.name.bigfishmod.luck", "运气");
        add("attribute.name.bigfishmod.weight", "重量");
        add("tooltip.bigfishmod.lucky_star_info", "一颗闪烁的星星，能带来随机的恩赐...");
        // 体型阶段
        add("stage.bigfishmod.baby", "鱼苗");
        add("stage.bigfishmod.seedling", "幼鱼");
        add("stage.bigfishmod.juvenile", "稚鱼");
        add("stage.bigfishmod.young", "青少年鱼");
        add("stage.bigfishmod.adult", "成年鱼");
        add("stage.bigfishmod.prime", "壮年鱼");
        add("stage.bigfishmod.mature", "成熟鱼");
        add("stage.bigfishmod.rare", "稀有");
        add("stage.bigfishmod.epic", "史诗");
        add("stage.bigfishmod.legend", "传奇");

        // 工具提示
        add("tooltip.bigfishmod.fishbook", "未制作（目前过渡状态）");
        add("tooltip.bigfishmod.display", "展示用");
        add("tooltip.bigfishmod.level", "等级: %s/%s");
        add("tooltip.bigfishmod.size_stage", "体型: %s");
        add("tooltip.bigfishmod.strength", "力量: %.1f");
        add("tooltip.bigfishmod.stamina", "耐力: %.1f");
        add("tooltip.bigfishmod.perception", "感知: %.1f");
        add("tooltip.bigfishmod.luck", "运气: %.1f");
        add("tooltip.bigfishmod.growth", "成长: %s");
        add("tooltip.bigfishmod.weight", "重量: %s 千克");
        add(KeyBindings.KEY_CATEGORY_BIGFISH, "巨物传说");

        add("item.bigfishmod.uses.remaining", "剩余次数：%d");
        add("item.bigfishmod.ocean_gem.tooltip", "来自深海的闪烁宝石，散发着水域的光辉，低语着海底的秘密。");
        add("item.bigfishmod.sea_breeze_essence.tooltip", "来自海洋心脏的风息，一缕瞬间的精华，承载着风的低语。");
        add("message.bigfishmod.lucky_star.positive_minor1", "一丝幸运的光芒！");
        add("message.bigfishmod.lucky_star.positive_minor2", "星辰为你排列。");
        add("message.bigfishmod.lucky_star.positive_minor3", "你感受到了一个轻微的祝福。");
        add("message.bigfishmod.lucky_star.positive_minor4", "命运对你微笑。");
        add("message.bigfishmod.lucky_star.positive_minor5", "温柔的宇宙之息。");
        add("message.bigfishmod.lucky_star.positive_minor6", "星空低语着佳音。");

        add("message.bigfishmod.lucky_star.positive_major1", "史诗级的恩赐！");
        add("message.bigfishmod.lucky_star.positive_major2", "一股星辰之力涌向你！");
        add("message.bigfishmod.lucky_star.positive_major3", "星辰之力在你体内涌动！");
        add("message.bigfishmod.lucky_star.positive_major4", "天界降下祝福！");
        add("message.bigfishmod.lucky_star.positive_major5", "星运璀璨闪耀！");

        add("message.bigfishmod.lucky_star.mixed1", "星光变得扭曲了...");
        add("message.bigfishmod.lucky_star.mixed2", "一个祸福参半的命运之袋...");
        add("message.bigfishmod.lucky_star.mixed3", "混沌与秩序共舞...");
        add("message.bigfishmod.lucky_star.mixed4", "星辰之光在颤抖...");
        add("message.bigfishmod.lucky_star.mixed5", "命运的天平在摇摆...");

        add("message.bigfishmod.lucky_star.jackpot1", "宇宙奇迹！");
        add("message.bigfishmod.lucky_star.jackpot2", "超凡之运加身！");
        add("message.bigfishmod.lucky_star.jackpot3", "命运的齿轮为你转动!");
        add("message.bigfishmod.lucky_star.jackpot4", "星界和谐在体内共鸣！");
        add("message.bigfishmod.lucky_star.jackpot5", "众星为你加冕！");

        add("message.bigfishmod.lucky_star.curse1", "星辰诅咒了你！");
        add("message.bigfishmod.lucky_star.curse2", "黑暗能量腐蚀了星光！");
        add("message.bigfishmod.lucky_star.curse3", "恶意的命运正在展开...");
        add("message.bigfishmod.lucky_star.curse4", "星辰流下黑色的眼泪！");
        add("message.bigfishmod.lucky_star.curse5", "宇宙的不幸降临于你！");

    }
    private void addVillager(VillagerProfession villagerProfession, String name) {
        add("entity.minecraft.villager."+ ForgeRegistries.VILLAGER_PROFESSIONS.getKey(villagerProfession).toLanguageKey(),name);
    }
}
