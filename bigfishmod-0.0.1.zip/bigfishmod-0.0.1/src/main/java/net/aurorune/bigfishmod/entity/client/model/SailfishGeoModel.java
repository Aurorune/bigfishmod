package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Guppy;
import net.aurorune.bigfishmod.entity.custom.Sailfish;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SailfishGeoModel extends GeoModel<Sailfish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/sailfish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/sailfish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/sailfish.animation.json");

    @Override
    public ResourceLocation getModelResource(Sailfish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Sailfish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Sailfish object) {
        return ANIMATION;
    }

}
