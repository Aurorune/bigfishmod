package net.aurorune.bigfishmod.entity.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GenericFishModel<T extends Entity> extends EntityModel<T> {
    private final ModelPart root;

    public GenericFishModel(ModelPart root) {
        this.root = root;
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        // 基本鱼模型定义（可根据需要扩展）
        partdefinition.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-1.0F, -1.5F, -3.0F, 2.0F, 3.0F, 6.0F),
                PartPose.offset(0.0F, 22.0F, 0.0F));

        partdefinition.addOrReplaceChild("tail",
                CubeListBuilder.create()
                        .texOffs(22, 0)
                        .addBox(0.0F, -1.5F, 0.0F, 0.0F, 3.0F, 4.0F),
                PartPose.offset(0.0F, 22.0F, 3.0F));

        return LayerDefinition.create(meshdefinition, 32, 32);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // 游泳动画
        if (entity instanceof AbstractFish fish && fish.isInWater()) {
            float swingFactor = 0.3F * limbSwingAmount;
            ModelPart tail = root.getChild("tail");
            if (tail != null) {
                tail.yRot = -swingFactor * Mth.sin(0.6F * ageInTicks);
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer,
                               int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay);
    }
}