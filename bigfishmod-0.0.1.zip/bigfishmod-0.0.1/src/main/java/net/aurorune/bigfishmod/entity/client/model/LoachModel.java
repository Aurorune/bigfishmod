package net.aurorune.bigfishmod.entity.client.model;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.animation.AnimationChannel;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoachModel<T extends Entity> extends EntityModel<T> {
    private final ModelPart root;
    private final ModelPart fishhead;
    private final ModelPart bone2;
    private final ModelPart bone6;
    private final ModelPart bone7;
    private final ModelPart bone8;
    private final ModelPart bone9;
    private final ModelPart bone5;
    private final ModelPart bone10;
    private final ModelPart bone11;
    private final ModelPart bone12;
    private final ModelPart bone21;
    private final ModelPart bone22;
    private final ModelPart bone23;
    private final ModelPart bone18;
    private final ModelPart bone19;
    private final ModelPart bone20;
    private final ModelPart fishbelly;
    private final ModelPart bone24;
    private final ModelPart bone;
    private final ModelPart bone3;
    private final ModelPart fishtail;
    private final ModelPart bone4;
    private final Map<String, ModelPart> partsByName = new HashMap<>();
    private final AnimationDefinition swimAnimation = loachAnimation.swim;
    public LoachModel(ModelPart root) {
        this.root = root.getChild("fish");
        this.fishhead = this.root.getChild("fishhead");
        this.bone2 = this.fishhead.getChild("bone2");
        this.bone6 = this.bone2.getChild("bone6");
        this.bone7 = this.bone6.getChild("bone7");
        this.bone8 = this.bone7.getChild("bone8");
        this.bone9 = this.bone8.getChild("bone9");
        this.bone5 = this.bone2.getChild("bone5");
        this.bone10 = this.bone5.getChild("bone10");
        this.bone11 = this.bone10.getChild("bone11");
        this.bone12 = this.bone11.getChild("bone12");
        this.bone21 = this.bone2.getChild("bone21");
        this.bone22 = this.bone21.getChild("bone22");
        this.bone23 = this.bone22.getChild("bone23");
        this.bone18 = this.bone2.getChild("bone18");
        this.bone19 = this.bone18.getChild("bone19");
        this.bone20 = this.bone19.getChild("bone20");
        this.fishbelly = this.root.getChild("fishbelly");
        this.bone24 = this.fishbelly.getChild("bone24");
        this.bone = this.bone24.getChild("bone");
        this.bone3 = this.bone.getChild("bone3");
        this.fishtail = this.bone3.getChild("fishtail");
        this.bone4 = this.fishtail.getChild("bone4");

        // 初始化动画部件映射
        this.partsByName.put("fishhead", fishhead);
        this.partsByName.put("bone6", bone6);
        this.partsByName.put("bone5", bone5);
        this.partsByName.put("bone21", bone21);
        this.partsByName.put("bone18", bone18);
        this.partsByName.put("fishbelly", fishbelly);
        this.partsByName.put("bone24", bone24);
        this.partsByName.put("bone", bone);
        this.partsByName.put("bone3", bone3);
        this.partsByName.put("fishtail", fishtail);
        this.partsByName.put("bone4", bone4);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();
        PartDefinition fish = partdefinition.addOrReplaceChild("fish", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0F, 24.0F, 0.0F, 0.0F, 1.5708F, 0.0F));
        PartDefinition fishhead = fish.addOrReplaceChild("fishhead", CubeListBuilder.create().texOffs(22, 9).addBox(0.0F, -2.5F, -2.0F, 7.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(16.0F, -2.5F, 1.0F));
        PartDefinition bone2 = fishhead.addOrReplaceChild("bone2", CubeListBuilder.create(), PartPose.offset(-19.0F, 2.65F, -8.0F));
        PartDefinition bone6 = bone2.addOrReplaceChild("bone6", CubeListBuilder.create().texOffs(0, 40).addBox(6.275F, -1.125F, -9.8F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(19.2888F, -0.365F, 18.6281F));
        PartDefinition bone7 = bone6.addOrReplaceChild("bone7", CubeListBuilder.create(), PartPose.offset(8.1286F, -0.625F, -9.2393F));
        PartDefinition cube_r1 = bone7.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(12, 37).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.5F, 0.0F, 0.5F, 0.0F, -0.7854F, 0.0F));
        PartDefinition bone8 = bone7.addOrReplaceChild("bone8", CubeListBuilder.create(), PartPose.offset(-8.1117F, 0.65F, 8.5897F));
        PartDefinition cube_r2 = bone8.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(40, 18).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(9.0063F, -0.65F, -6.8382F, 0.0F, -1.7453F, 0.0F));
        PartDefinition bone9 = bone8.addOrReplaceChild("bone9", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition cube_r3 = bone9.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(18, 37).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(8.2809F, -0.65F, -5.3671F, 0.0F, -2.3126F, 0.0F));
        PartDefinition bone5 = bone2.addOrReplaceChild("bone5", CubeListBuilder.create().texOffs(14, 27).addBox(7.175F, -1.125F, 19.725F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(18.2888F, -0.365F, -13.3719F));
        PartDefinition bone10 = bone5.addOrReplaceChild("bone10", CubeListBuilder.create(), PartPose.offset(9.0286F, -0.625F, 19.9143F));
        PartDefinition cube_r4 = bone10.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(38, 26).addBox(-1.5F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.8536F, 0.0F, -0.6036F, 0.0F, 0.7854F, 0.0F));
        PartDefinition bone11 = bone10.addOrReplaceChild("bone11", CubeListBuilder.create(), PartPose.offset(-9.0286F, 0.625F, -19.9143F));
        PartDefinition cube_r5 = bone11.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(38, 24).addBox(-4.8832F, -1.95F, -0.1255F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(9.9649F, 0.825F, 22.1284F, 0.0F, -1.7453F, 0.0F));
        PartDefinition bone12 = bone11.addOrReplaceChild("bone12", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition cube_r6 = bone12.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(38, 28).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(9.9775F, -0.625F, 16.7664F, 0.0F, -1.0036F, 0.0F));
        PartDefinition bone21 = bone2.addOrReplaceChild("bone21", CubeListBuilder.create(), PartPose.offsetAndRotation(17.8388F, -0.365F, 22.0031F, 3.1416F, 0.0F, 0.0F));
        PartDefinition cube_r7 = bone21.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(24, 39).addBox(-2.6452F, -1.925F, 1.7376F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(9.4F, 2.1F, 13.0F, 0.0F, -1.5708F, 0.0F));
        PartDefinition bone22 = bone21.addOrReplaceChild("bone22", CubeListBuilder.create(), PartPose.offsetAndRotation(6.7294F, 0.675F, 10.4887F, 0.0F, -1.309F, 0.0F));
        PartDefinition cube_r8 = bone22.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(30, 39).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.7244F, 0.0F, -0.1941F, 0.0F, 0.2618F, 0.0F));
        PartDefinition bone23 = bone22.addOrReplaceChild("bone23", CubeListBuilder.create(), PartPose.offset(-10.9071F, -0.675F, 4.0442F));
        PartDefinition cube_r9 = bone23.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(36, 39).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(8.5126F, 0.675F, -3.5035F, 0.0F, 0.5672F, 0.0F));
        PartDefinition bone18 = bone2.addOrReplaceChild("bone18", CubeListBuilder.create(), PartPose.offset(17.8388F, -0.365F, -0.2219F));
        PartDefinition cube_r10 = bone18.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(6, 40).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(7.1821F, -0.625F, 5.3374F, 0.0F, 1.5708F, 0.0F));
        PartDefinition bone19 = bone18.addOrReplaceChild("bone19", CubeListBuilder.create(), PartPose.offsetAndRotation(6.999F, -0.625F, 4.2214F, 0.0F, -1.309F, 0.0F));
        PartDefinition cube_r11 = bone19.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(12, 39).addBox(-4.1361F, -2.0788F, -3.0472F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.12F, 1.5788F, 1.7543F, 0.0F, 0.2618F, 0.0F));
        PartDefinition bone20 = bone19.addOrReplaceChild("bone20", CubeListBuilder.create(), PartPose.offset(-4.9439F, 0.625F, 5.9203F));
        PartDefinition cube_r12 = bone20.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(18, 39).addBox(-3.3025F, -2.0343F, -1.2668F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(5.0593F, 0.9093F, -5.6703F, 0.0F, 0.5672F, 0.0F));
        PartDefinition fishbelly = fish.addOrReplaceChild("fishbelly", CubeListBuilder.create().texOffs(22, 0).addBox(-7.0F, -2.3F, -1.6F, 7.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(16.0F, -2.7F, 0.6F));
        PartDefinition cube_r13 = fishbelly.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(0, 34).addBox(-3.7125F, 0.0F, -0.375F, 4.0F, 0.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.2875F, 2.6F, 2.525F, -0.1745F, 0.0F, 0.0F));

        PartDefinition cube_r14 = fishbelly.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(14, 34).addBox(-2.7125F, 0.0F, -0.375F, 4.0F, 0.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.2875F, 2.6F, -3.7F, 0.1745F, 0.0F, 0.0F));

        PartDefinition bone24 = fishbelly.addOrReplaceChild("bone24", CubeListBuilder.create().texOffs(0, 0).addBox(-7.1F, -2.5F, -2.1F, 7.0F, 5.0F, 4.0F, new CubeDeformation(0.0F))
                .texOffs(28, 36).addBox(-9.2F, 1.45F, 0.275F, 6.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(-6.8F, 0.2F, 0.5F));

        PartDefinition bone = bone24.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(0, 18).addBox(-6.875F, -2.5F, -1.5F, 7.0F, 5.0F, 4.0F, new CubeDeformation(0.0F))
                .texOffs(0, 37).addBox(-8.9F, -4.15F, 0.625F, 6.0F, 3.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(-7.2F, 0.0F, -0.6F));

        PartDefinition bone3 = bone.addOrReplaceChild("bone3", CubeListBuilder.create().texOffs(0, 9).addBox(-7.9579F, -2.5F, -2.347F, 7.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-5.9041F, 0.0F, 0.8153F));

        PartDefinition fishtail = bone3.addOrReplaceChild("fishtail", CubeListBuilder.create().texOffs(0, 27).addBox(-3.875F, -1.8F, -1.5F, 4.0F, 4.0F, 3.0F, new CubeDeformation(0.0F))
                .texOffs(30, 30).addBox(-6.875F, -1.8F, -1.5F, 3.0F, 3.0F, 3.0F, new CubeDeformation(0.0F))
                .texOffs(22, 24).addBox(-6.775F, -2.375F, 0.0F, 8.0F, 6.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(-8.0829F, -0.3F, -0.347F));

        PartDefinition bone4 = fishtail.addOrReplaceChild("bone4", CubeListBuilder.create().texOffs(22, 18).addBox(-8.975F, -2.4F, 0.0F, 9.0F, 6.0F, 0.0F, new CubeDeformation(0.0F))
                .texOffs(14, 30).addBox(-6.15F, -1.7F, -0.975F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-6.7F, 0.0F, 0.0F));

        return LayerDefinition.create(meshdefinition, 64, 64);
    }

    public void resetPose() {
         root.resetPose();
        fishhead.resetPose();
        bone2.resetPose();
        bone6.resetPose();
        bone7.resetPose();
        bone8.resetPose();
        bone9.resetPose();
        bone5.resetPose();
        bone10.resetPose();
        bone11.resetPose();
        bone12.resetPose();
        bone21.resetPose();
        bone22.resetPose();
        bone23.resetPose();
        bone18.resetPose();
        bone19.resetPose();
        bone20.resetPose();
        fishbelly.resetPose();
        bone24.resetPose();
        bone.resetPose();
        bone3.resetPose();
        fishtail.resetPose();
        bone4.resetPose();
    }
    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        resetPose();
        float time = ageInTicks * 0.3f;// 头部摆动 (-2.5°到2.5°)
        fishhead.yRot = Mth.sin(time) * 0.0436f; // 2.5° in radians
        // 身体摆动 (-5°到5°)
        fishbelly.yRot = Mth.sin(time + 0.3f) * 0.0873f; // 5° in radians
        bone24.yRot = Mth.sin(time + 0.4f) * 0.0873f;
        bone.yRot = Mth.sin(time + 0.5f) * 0.0873f;
        // 尾部摆动 (-10°到10°)
        bone3.yRot = Mth.sin(time + 0.6f) * 0.1745f; // 10° in radians
        fishtail.yRot = Mth.sin(time + 0.7f) * 0.1745f;
        bone4.yRot = Mth.sin(time + 0.8f) * 0.1745f;
    }
    private void applyAnimation(AnimationDefinition animation, float time, float speed) {
        float elapsedTime = time * speed;

        // 遍历所有骨骼动画
        animation.boneAnimations().forEach((boneName, channels) -> {
            ModelPart part = partsByName.get(boneName);
            if (part != null) {
                // 应用骨骼的所有通道
                for (AnimationChannel channel : channels) {
                    applyChannelAnimation(part, channel, elapsedTime);
                }
            }
        });
    }

    private void applyChannelAnimation(ModelPart part, AnimationChannel channel, float time) {
        // 仅处理旋转动画
        if (channel.target() == AnimationChannel.Targets.ROTATION) {
            Vector3f rotation = calculateRotation(channel, time);
            part.xRot = rotation.x() * Mth.DEG_TO_RAD;
            part.yRot = rotation.y() * Mth.DEG_TO_RAD;
            part.zRot = rotation.z() * Mth.DEG_TO_RAD;
        }
        // 可添加位置和缩放支持
    }

    private Vector3f calculateRotation(AnimationChannel channel, float time) {
        Keyframe[] keyframes = channel.keyframes();
        float progress = time % 1.0f; // 确保在0-1范围内

        // 查找当前帧和下一帧
        int frameIndex = 0;
        while (frameIndex < keyframes.length - 1 && progress > keyframes[frameIndex + 1].timestamp()) {
            frameIndex++;
        }

        if (frameIndex >= keyframes.length - 1) {
            return keyframes[keyframes.length - 1].target();
        }

        Keyframe currentFrame = keyframes[frameIndex];
        Keyframe nextFrame = keyframes[frameIndex + 1];

        // 计算插值比例
        float frameDelta = nextFrame.timestamp() - currentFrame.timestamp();
        float lerpProgress = (progress - currentFrame.timestamp()) / frameDelta;

        // 线性插值计算旋转
        Vector3f start = currentFrame.target();
        Vector3f end = nextFrame.target();
        return new Vector3f(
                Mth.lerp(lerpProgress, start.x(), end.x()),
                Mth.lerp(lerpProgress, start.y(), end.y()),
                Mth.lerp(lerpProgress, start.z(), end.z())
        );
    }
    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer,
                               int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay);
    }
    public class loachAnimation {
        public static final AnimationDefinition swim = AnimationDefinition.Builder.withLength(1.0F).looping()
                .addAnimation("fishhead", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -5.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, 5.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, -5.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone6", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone5", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone21", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone18", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("fishbelly", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone24", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, 7.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, -2.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone3", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, -20.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("fishtail", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .addAnimation("bone4", new AnimationChannel(AnimationChannel.Targets.ROTATION,
                        new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.25F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.5F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(0.75F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
                        new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)
                ))
                .build();
    }
}