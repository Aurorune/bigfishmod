package net.aurorune.bigfishmod.block.custom;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.api.LogUtil;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.aurorune.bigfishmod.blockentity.custom.TrophyBaseBlockEntity;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.concurrent.atomic.AtomicInteger;

public class TrophyBaseBlock extends Block implements EntityBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty HAS_FISH = BooleanProperty.create("has_fish");

    public TrophyBaseBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(HAS_FISH, false));
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        // 使用注册的 BlockEntityType
        return ModBlockEntities.TROPHY_BASE.get().create(pos, state);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, HAS_FISH);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState()
                .setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        // 改为MODEL让Minecraft自动渲染底座
        return RenderShape.MODEL;
    }
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        Direction facing = state.getValue(FACING);
        return switch (facing) {
            case NORTH -> Shapes.box(0.0, 0.0, 0.875, 1.0, 1.0, 1.0); // Z轴 14/16-16/16
            case SOUTH -> Shapes.box(0.0, 0.0, 0.0, 1.0, 1.0, 0.125); // Z轴 0-2/16
            case WEST -> Shapes.box(0.875, 0.0, 0.0, 1.0, 1.0, 1.0);  // X轴 14/16-16/16
            case EAST -> Shapes.box(0.0, 0.0, 0.0, 0.125, 1.0, 1.0);   // X轴 0-2/16
            default -> Shapes.block();
        };
    }
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        // 添加详细日志
        BigFishMod.LOGGER.debug("TrophyBase interaction at {} by {} with {} in {} hand",
                pos, player.getName().getString(), player.getItemInHand(hand).getItem(), hand);

        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity == null) {
            BigFishMod.LOGGER.error("No BlockEntity found at {}", pos);
            return InteractionResult.FAIL;
        }

        if (!(blockEntity instanceof TrophyBaseBlockEntity)) {
            BigFishMod.LOGGER.error("Expected TrophyBaseBlockEntity at {}, found {}", pos, blockEntity.getClass());
            return InteractionResult.FAIL;
        }

        TrophyBaseBlockEntity trophyBase = (TrophyBaseBlockEntity) blockEntity;
        ItemStack handItem = player.getItemInHand(hand);

        // 1. 优先处理Shift+右键移除鱼
        if (trophyBase.hasFish() && player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                BigFishMod.LOGGER.info("Player {} removed fish from trophy at {}",
                        player.getName().getString(), pos);
                ItemStack fishStack = trophyBase.removeFish();
                player.addItem(fishStack);
                level.setBlock(pos, state.setValue(HAS_FISH, false), 3);
                level.playSound(null, pos, SoundEvents.ITEM_FRAME_REMOVE_ITEM, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        // 2. 添加鱼展示品
        else if (!handItem.isEmpty() && handItem.getItem() instanceof CustomFishTrophyItem && trophyBase.isEmpty()) {
            if (!level.isClientSide) {
                trophyBase.setFishStack(handItem.copy());
                trophyBase.setRotation(0);

                if (!player.isCreative()) {
                    handItem.shrink(1);
                }

                level.setBlock(pos, state.setValue(HAS_FISH, true), 3);
                level.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        // 4. 其他情况阻止交互（防止放置方块）
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
