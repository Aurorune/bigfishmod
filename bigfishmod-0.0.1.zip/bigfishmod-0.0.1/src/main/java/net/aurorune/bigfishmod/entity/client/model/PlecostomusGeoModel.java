package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Plecostomus;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class PlecostomusGeoModel extends GeoModel<Plecostomus> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/plecostomu.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/plecostomus.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/plecostomu.animation.json");

    @Override
    public ResourceLocation getModelResource(Plecostomus object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Plecostomus object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Plecostomus object) {
        return ANIMATION;
    }

}
