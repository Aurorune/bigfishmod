package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Piranha;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class PiranhaGeoModel extends GeoModel<Piranha> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/piranha.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/piranha.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/piranha.animation.json");

    @Override
    public ResourceLocation getModelResource(Piranha object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Piranha object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Piranha object) {
        return ANIMATION;
    }

}
