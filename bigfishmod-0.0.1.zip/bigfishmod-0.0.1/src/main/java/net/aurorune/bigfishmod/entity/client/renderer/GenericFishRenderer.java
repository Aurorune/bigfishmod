package net.aurorune.bigfishmod.entity.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class GenericFishRenderer<T extends Mob> extends MobRenderer<T, EntityModel<T>> {
    private final ResourceLocation texture;

    public GenericFishRenderer(EntityRendererProvider.Context context,
                               EntityModel<T> model,
                               ResourceLocation texture) {
        super(context, model, 0.3F);
        this.texture = texture;
    }
    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
    @Override
    public void render(T entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float scale = entity.getScale();
        poseStack.scale(scale, scale, scale);
        if (!entity.isInWater()) {
            if (entity.isAlive()) {
                // 更自然的侧躺姿势
                poseStack.translate(0.15D, 0.1D, 0.0D);
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
                poseStack.mulPose(Axis.ZP.rotationDegrees(0.0F)); // 轻微倾斜
            } else {
                // 死亡状态 - 平躺并轻微下沉
                poseStack.translate(0.0D, 0.1D, 0.0D);
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
                poseStack.mulPose(Axis.ZP.rotationDegrees(15.0F)); // 使用固定死亡旋转角度
            }
        }

        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}