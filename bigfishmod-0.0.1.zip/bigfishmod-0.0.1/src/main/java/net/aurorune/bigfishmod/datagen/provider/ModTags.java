package net.aurorune.bigfishmod.datagen.provider;

import net.aurorune.bigfishmod.BigFishMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class ModTags {
    public static class Items {
        public static final TagKey<Item> VEGETARIAN_FOOD = TagKey.create(Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "vegetarian_food"));

        public static final TagKey<Item> MEAT_FOOD = TagKey.create(Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "meat_food"));
    }
}
