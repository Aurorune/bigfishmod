package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.NilePerch;
import net.aurorune.bigfishmod.entity.custom.Piranha;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class NilePerchGeoModel extends GeoModel<NilePerch> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/nile_perch.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/nile_perch.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/nile_perch.animation.json");

    @Override
    public ResourceLocation getModelResource(NilePerch object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(NilePerch object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(NilePerch object) {
        return ANIMATION;
    }

}
