/*
 * bigfishmod
 *
 * Copyright 2025 Aurorune
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Note: This file is licensed under Apache 2.0, but associated texture
 * resources are excluded and remain all rights reserved.
 */
package net.aurorune.bigfishmod;

import com.mojang.logging.LogUtils;
import net.aurorune.bigfishmod.api.LogCommand;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.aurorune.bigfishmod.client.Handler.NetworkHandler;
import net.aurorune.bigfishmod.commands.GiveCustomFishCommand;
import net.aurorune.bigfishmod.config.RoeConfig;
import net.aurorune.bigfishmod.entity.ModEntities;
import net.aurorune.bigfishmod.client.StaminaHUD;
import net.aurorune.bigfishmod.client.gui.ModMenuTypes;
import net.aurorune.bigfishmod.commands.AnimationTestCommand;
import net.aurorune.bigfishmod.event.ModEvents;
import net.aurorune.bigfishmod.item.ModCreativeModeTab;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.ModBrewingRecipes;
import net.aurorune.bigfishmod.item.custom.SetFishNbtFunction;
import net.aurorune.bigfishmod.painting.ModPaintings;
import net.aurorune.bigfishmod.villager.ModVillagers;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.storage.loot.functions.LootItemFunctionType;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;
import software.bernie.geckolib.GeckoLib;


@Mod(BigFishMod.MOD_ID)
public class BigFishMod
{
    public static final String MOD_ID = "bigfishmod";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<LootItemFunctionType> LOOT_FUNCTIONS =
            DeferredRegister.create(Registries.LOOT_FUNCTION_TYPE, MOD_ID);

    public static final RegistryObject<LootItemFunctionType> SET_FISH_NBT =
            LOOT_FUNCTIONS.register("set_fish_nbt",
                    () -> SetFishNbtFunction.TYPE);
    @SuppressWarnings("removal")
    public BigFishMod()
    {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        GeckoLib.initialize();
        RoeConfig.registerFishTypes();
        ModBlocks.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModItems.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModMenuTypes.MENUS.register(modEventBus);
        ModCreativeModeTab.register(modEventBus);
        ModPaintings.register(modEventBus);
        ModVillagers.register(modEventBus);
        MinecraftForge.EVENT_BUS.register(ModEvents.class);
        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(ModBrewingRecipes::register);
        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);
        LOOT_FUNCTIONS.register(modEventBus);
        // 注册客户端事件处理器
        modEventBus.addListener(EventPriority.NORMAL, false, RegisterGuiOverlaysEvent.class, this::registerOverlays);
        // 注册客户端tick事件（用于HUD动画）
        MinecraftForge.EVENT_BUS.addListener(this::onClientTick);
        MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
}
    public void registerCommands(RegisterCommandsEvent event) {
        AnimationTestCommand.register(event.getDispatcher());
        LogCommand.register(event.getDispatcher());
        GiveCustomFishCommand.register(event.getDispatcher());
    }
    private void commonSetup(final FMLCommonSetupEvent event)
    {event.enqueueWork(() -> {
        NetworkHandler.register();
    });

    }



    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event)
    {
    }

    private void registerOverlays(RegisterGuiOverlaysEvent event) {
        // 注册HUD
//        StaminaHUD.registerOverlay(event);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
//        if (event.phase == TickEvent.Phase.END) {
//            StaminaHUD.updateAnimation();
//        }
   }
    
}
