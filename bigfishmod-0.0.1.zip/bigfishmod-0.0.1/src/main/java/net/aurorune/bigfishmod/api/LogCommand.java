package net.aurorune.bigfishmod.api;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.aurorune.bigfishmod.BigFishMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.LoggerConfig;


public class LogCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("bflog")
                .requires(source -> source.hasPermission(2)) // 仅限OP使用
                .then(Commands.literal("level")
                        .then(Commands.argument("level", StringArgumentType.word())
                                .suggests((context, builder) ->
                                        SharedSuggestionProvider.suggest(new String[]{"error", "warn", "info", "debug", "trace"}, builder))
                                .executes(ctx -> setLevel(ctx, StringArgumentType.getString(ctx, "level")))
                                .then(Commands.literal("reset")
                                        .executes(ctx -> resetLevels(ctx))
                                ))));
    }

    private static int setLevel(CommandContext<CommandSourceStack> ctx, String levelStr) {
        try {
            // 使用 Log4j 的 Level 类
            Level level = Level.toLevel(levelStr.toUpperCase(), Level.INFO);

            // 获取当前日志上下文
            LoggerContext context = (LoggerContext) LogManager.getContext(false);

            // 获取或创建我们Mod的日志配置
            LoggerConfig loggerConfig = context.getConfiguration().getLoggerConfig(BigFishMod.MOD_ID);
            if (loggerConfig.getName().equals(BigFishMod.MOD_ID)) {
                loggerConfig.setLevel(level);
            } else {
                // 如果不存在则创建新的日志配置
                loggerConfig = new LoggerConfig(BigFishMod.MOD_ID, level, true);
                context.getConfiguration().addLogger(BigFishMod.MOD_ID, loggerConfig);
            }

            // 更新日志系统
            context.updateLoggers();

            // 发送成功消息
            ctx.getSource().sendSuccess(
                    () -> Component.literal("Set log level to " + level.name()),
                    false
            );
            return 1;
        } catch (Exception e) {
            ctx.getSource().sendFailure(Component.literal("Invalid log level: " + levelStr));
            return 0;
        }
    }

    private static int resetLevels(CommandContext<CommandSourceStack> ctx) {
        // 重置为默认 INFO 级别
        setLevel(ctx, "info");

        // 发送成功消息
        ctx.getSource().sendSuccess(
                () -> Component.literal("Reset all log levels to INFO"),
                false
        );
        return 1;
    }
}