package net.aurorune.bigfishmod.client.Handler;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.CustomFishBucket;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.aurorune.bigfishmod.item.custom.WoodenMobBucketItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BigFishMod.MOD_ID)
public class CraftingEventHandler {

    @SubscribeEvent
    public static void onCrafting(PlayerEvent.ItemCraftedEvent event) {
        ItemStack result = event.getCrafting();
        CraftingContainer craftingInventory = (CraftingContainer) event.getInventory();
        Player player = event.getEntity();

        // 合成鱼桶时复制NBT（支持铁桶和木桶）
        if (result.getItem() instanceof CustomFishBucket || result.getItem() instanceof WoodenMobBucketItem) {
            // 寻找合成网格中的鱼标本
            ItemStack trophyStack = ItemStack.EMPTY;
            for (int i = 0; i < craftingInventory.getContainerSize(); i++) {
                ItemStack stack = craftingInventory.getItem(i);
                if (stack.getItem() instanceof CustomFishTrophyItem) {
                    trophyStack = stack;
                    break;
                }
            }

            if (!trophyStack.isEmpty()) {
                CustomFishTrophyItem trophy = (CustomFishTrophyItem) trophyStack.getItem();

                // 确保是同一种鱼
                String fishType = trophy.getCustomFishType();
                String resultFishType = getFishTypeFromBucket(result.getItem());

                if (fishType.equals(resultFishType)) {
                    CompoundTag fishData = CustomFishTrophyItem.getFishData(trophyStack);
                    if (fishData != null) {
                        CompoundTag bucketTag = new CompoundTag();
                        bucketTag.putInt("FishLevel", fishData.getInt("Level"));
                        // 修复：确保保存最大等级
                        bucketTag.putInt("FishMaxLevel", fishData.getInt("MaxLevelCap"));
                        bucketTag.put("Attributes", fishData.getCompound("Attributes").copy());
                        result.setTag(bucketTag);
                    }
                }
            }


            // 防止水桶被消耗后留下空桶（铁桶版本）
            for (int i = 0; i < craftingInventory.getContainerSize(); i++) {
                ItemStack stack = craftingInventory.getItem(i);
                if (stack.getItem() == Items.WATER_BUCKET) {
                    // 移除水桶但不消耗它
                    craftingInventory.setItem(i, ItemStack.EMPTY);
                }
            }

            // 防止木桶被消耗后留下空桶（木桶版本）
            for (int i = 0; i < craftingInventory.getContainerSize(); i++) {
                ItemStack stack = craftingInventory.getItem(i);
                if (stack.getItem() == ModItems.WOODEN_BUCKET.get()) {
                    // 移除木桶但不消耗它
                    craftingInventory.setItem(i, ItemStack.EMPTY);
                }
            }
        }
    }

    private static String getFishTypeFromBucket(Item bucketItem) {
        if (bucketItem instanceof CustomFishBucket) {
            return ((CustomFishBucket) bucketItem).getCustomFishType();
        } else if (bucketItem instanceof WoodenMobBucketItem) {
            return ((WoodenMobBucketItem) bucketItem).getCustomFishType();
        }
        return "";
    }
}