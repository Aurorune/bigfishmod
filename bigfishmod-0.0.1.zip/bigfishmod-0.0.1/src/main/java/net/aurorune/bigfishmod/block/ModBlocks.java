/*
 * bigfishmod
 *
 * Copyright 2025 Aurorune
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Note: This file is licensed under Apache 2.0, but associated texture
 * resources are excluded and remain all rights reserved.
 */
package net.aurorune.bigfishmod.block;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.custom.CronCropBlock;

import net.aurorune.bigfishmod.block.custom.FishBoxBlock;
import net.aurorune.bigfishmod.block.custom.GemInfusingStationBlock;
import net.aurorune.bigfishmod.block.custom.TrophyBaseBlock;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

import static net.minecraft.world.item.Items.registerBlock;

//方块添加
public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS=
            DeferredRegister.create(ForgeRegistries.BLOCKS, BigFishMod.MOD_ID);

    public static final RegistryObject<Block> GRAPHITE_BLOCK = registerBlock("graphite_block",
            ()->new Block(BlockBehaviour.Properties.copy(Blocks.STONE)
                    .strength(4f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> GRAPHITE_ORE = registerBlock("graphite_ore",
            ()->new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.IRON_ORE)
                    .strength(3f).requiresCorrectToolForDrops(),
                    UniformInt.of(3,7)));
    public static final RegistryObject<Block> DEEPSLATE_GRAPHITE_ORE = registerBlock("deepslate_graphite_ore",
            ()->new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_IRON_ORE)
                    .strength(4f).requiresCorrectToolForDrops(),
                    UniformInt.of(3,7)));
    // 作物
    public static final RegistryObject<Block> CORN_CROP = BLOCKS.register("corn_crop",
            ()->new CronCropBlock(BlockBehaviour.Properties.copy(Blocks.WHEAT)));
    public static final RegistryObject<Block> FISH_STAND = registerBlock("fish_stand",
            () -> new GemInfusingStationBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)
                    .strength(4F).requiresCorrectToolForDrops()));
    public static final RegistryObject<Block> FISH_BOX = BLOCKS.register(
            "fish_box",    () -> new FishBoxBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(2.0f)
                    .requiresCorrectToolForDrops()
                    .noOcclusion()));
    public static final RegistryObject<Block> TROPHY_BASE = BLOCKS.register("trophy_base",
            () -> new TrophyBaseBlock(BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS)
                    .noOcclusion()
                    .strength(1.5f)
            ));
    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> block) {
        RegistryObject<T> toReturn = BLOCKS.register(name,block);
        registerBlockItem(name,toReturn);
        return toReturn;
    }
    private static <T extends Block> RegistryObject<Item> registerBlockItem (String name, RegistryObject<T>  block) {
           return ModItems.ITEMS.register(name,()->new BlockItem(block.get(),new Item.Properties()));
    }


    public  static void register(IEventBus eventBus){
        BLOCKS.register(eventBus);
    }

}
