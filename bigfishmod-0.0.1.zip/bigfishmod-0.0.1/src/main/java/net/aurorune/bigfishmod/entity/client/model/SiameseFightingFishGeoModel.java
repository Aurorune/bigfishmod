package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.aurorune.bigfishmod.entity.custom.NorthernPike;
import net.aurorune.bigfishmod.entity.custom.SiameseFightingFish;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SiameseFightingFishGeoModel extends GeoModel<SiameseFightingFish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/siamese_fighting_fish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/siamese_fighting_fish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/siamese_fighting_fish.animation.json");

    @Override
    public ResourceLocation getModelResource( SiameseFightingFish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( SiameseFightingFish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( SiameseFightingFish object) {
        return ANIMATION;
    }

}
