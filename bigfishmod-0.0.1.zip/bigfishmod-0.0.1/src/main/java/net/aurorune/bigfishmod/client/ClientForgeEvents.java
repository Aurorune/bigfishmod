package net.aurorune.bigfishmod.client;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.aurorune.bigfishmod.client.renderer.FishBoxRenderer;
import net.aurorune.bigfishmod.client.renderer.TrophyBaseRenderer;
import net.aurorune.bigfishmod.util.KeyBindings;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderItemInFrameEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.RenderItemInFrameEvent;

import java.lang.reflect.Field;

@Mod.EventBusSubscriber(modid = BigFishMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientForgeEvents {

//    @SubscribeEvent
//    public static void onKeyInput(InputEvent.Key event) {
//        Minecraft mc = Minecraft.getInstance();
//        if (mc.player == null || mc.level == null) return;
//
//        if (KeyBindings.SHOW_STAMINA_KEY.consumeClick()) {
//            // 切换HUD显示状态
//            StaminaHUD.setDisplayActive(!StaminaHUD.isDisplayActive());
//        }
//    }


}