package net.aurorune.bigfishmod.api;

import io.netty.util.IntSupplier;
import net.aurorune.bigfishmod.BigFishMod;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.util.thread.EffectiveSide;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class LogUtil {
    private static final Map<String, Long> lastLoggedTimes = new ConcurrentHashMap<>();
    private static final long MIN_LOG_INTERVAL = 5000; // 5秒间隔

    public static void debug(String key, Supplier<String> messageSupplier) {
        if (!BigFishMod.LOGGER.isDebugEnabled()) return;
        logInternal(key, messageSupplier, BigFishMod.LOGGER::debug);
    }

    public static void info(String key, Supplier<String> messageSupplier) {
        logInternal(key, messageSupplier, BigFishMod.LOGGER::info);
    }

    public static void warn(String key, Supplier<String> messageSupplier) {
        logInternal(key, messageSupplier, BigFishMod.LOGGER::warn);
    }

    private static void logInternal(String key, Supplier<String> messageSupplier, Consumer<String> logFunction) {
        long now = System.currentTimeMillis();
        Long lastTime = lastLoggedTimes.get(key);

        if (lastTime == null || (now - lastTime) > MIN_LOG_INTERVAL) {
            // 添加服务器/客户端标识
            String side = EffectiveSide.get() == LogicalSide.SERVER ? "[SERVER]" : "[CLIENT]";
            logFunction.accept(side + " " + messageSupplier.get());
            lastLoggedTimes.put(key, now);
        }
    }

    // 修复 IntSupplier 问题
    public static void rateLimitedDebug(String key, Supplier<Integer> countSupplier, Supplier<String> baseMessage) {
        if (!BigFishMod.LOGGER.isDebugEnabled()) return;

        long now = System.currentTimeMillis();
        Long lastTime = lastLoggedTimes.get(key);
        int count = countSupplier.get(); // 使用 Supplier<Integer> 替代 IntSupplier

        if (lastTime == null || (now - lastTime) > MIN_LOG_INTERVAL) {
            BigFishMod.LOGGER.debug(baseMessage.get() + " (x" + count + " in last " + MIN_LOG_INTERVAL + "ms)");
            lastLoggedTimes.put(key, now);
        }
    }
}
