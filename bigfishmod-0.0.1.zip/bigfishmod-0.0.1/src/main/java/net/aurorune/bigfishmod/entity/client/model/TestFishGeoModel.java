package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.TestFish;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class TestFishGeoModel extends GeoModel<TestFish> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/testfish.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/testfish.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/testfish.animation.json");

    @Override
    public ResourceLocation getModelResource(TestFish object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(TestFish object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(TestFish object) {
        return ANIMATION;
    }

}