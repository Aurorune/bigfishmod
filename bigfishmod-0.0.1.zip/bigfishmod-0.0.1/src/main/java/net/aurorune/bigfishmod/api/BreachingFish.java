
package net.aurorune.bigfishmod.api;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public interface BreachingFish {
    /**
     * 检查鱼是否正在跃出水面
     */
    boolean isBreaching();
    /**
     * 设置鱼的跃出状态
     */
    void setBreaching(boolean breaching);
    /**
     * 获取鱼的实体对象
     */
    Entity getEntity();

    /**
     * 获取鱼的等级
     */
    int getLevel();

    /**
     * 获取鱼的随机数生成器
     */
    RandomSource getRandom();

    /**
     * 获取鱼的导航系统
     */
    PathNavigation getNavigation();


    /**
     * 获取鱼的速度向量
     */
    Vec3 getDeltaMovement();

    /**
     * 设置鱼的速度向量 (Vec3版本)
     */
    void setDeltaMovement(Vec3 motion);

    /**
     * 设置鱼的速度向量 (三个double版本)
     */
    void setDeltaMovement(double x, double y, double z);

    /**
     * 获取鱼的方块位置
     */
    BlockPos blockPosition();

    /**
     * 获取鱼所在的世界
     */
    Level level();

    /**
     * 获取鱼的视线方向
     */
    Vec3 getLookAngle();

    /**
     * 检查鱼是否在地面上
     */
    boolean onGround();

    /**
     * 检查鱼是否发生水平碰撞
     */
    boolean isHorizontalCollision();

    /**
     * 检查鱼是否发生垂直碰撞
     */
    boolean isVerticalCollision();

    /**
     * 检查鱼是否在水中
     */
    boolean isInWater();

    /**
     * 获取鱼的Y坐标 (通过实体获取)
     */
    default double getY() {
        return getEntity().getY();
    }

    /**
     * 获取鱼的X坐标 (通过实体获取)
     */
    default double getX() {
        return getEntity().getX();
    }

    /**
     * 获取鱼的Z坐标 (通过实体获取)
     */
    default double getZ() {
        return getEntity().getZ();
    }

}