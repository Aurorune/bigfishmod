package net.aurorune.bigfishmod.api;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;


@OnlyIn(Dist.CLIENT)
public class FishDisplayAdjuster {

    // 根据鱼的种类进行位置调整
    public static void applyTypeSpecificAdjustment(PoseStack poseStack, String fishType,int level) {
        int stage = getStageFromLevel(level);
        switch (fishType) {
            case "bigfishmod:testfish":
                        switch (stage) {
                            case 0: //鱼苗
                                poseStack.translate(0.02, 0, 0.45);
                                break;
                            case 1: // 幼鱼
                                poseStack.translate(0.04, 0, 0.45);
                                break;
                            case 2: // 稚鱼
                                poseStack.translate(0.07, -0.05, 0.43);
                                break;
                            case 3: // 青少年鱼
                                poseStack.translate(0.08, -0.08, 0.42);
                                break;
                            case 4: // 成年鱼
                                poseStack.translate(0.1, -0.1, 0.43);
                                break;
                            case 5: // 壮年鱼
                                poseStack.translate(0.12, -0.1, 0.42);
                                break;
                            case 6: //  成熟鱼
                                poseStack.translate(0.1, -0.12, 0.45);
                                break;
                            case 7: // 稀有
                                poseStack.translate(0.1, -0.14, 0.45);
                                break;
                            case 8: // 史诗
                                poseStack.translate(0.1, -0.15, 0.45);
                                break;
                            case 9: // 传奇
                                poseStack.translate(0.2, -0.2, 0.45);
                                break;
                            default:
                                poseStack.translate(0, 3, 0); // 默认不调整
                                break;
                        }break;
            case "bigfishmod:loach":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, 0.1, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, 0.15, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, 0.23, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(-0.02, 0.3, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(-0.02, 0.35, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(-0.03, 0.44, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(-0.05, 0.55, 0.35);
                        break;
                    case 7: // 稀有
                        poseStack.translate(-0.05, 0.6, 0.35);
                        break;
                    case 8: // 史诗
                        poseStack.translate(-0.05, 0.65, 0.35);
                        break;
                    case 9: // 传奇
                        poseStack.translate(-0.05, 0.7, 0.35);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }break;
            case "bigfishmod:tilapia":
                switch (stage) {
                     case 0: //鱼苗
                        poseStack.translate(0, -0.1, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.12, 0.43);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.0, -0.15, 0.43);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.0, -0.18, 0.42);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0, -0.2, 0.43);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, -0.2, 0.42);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(-0.05, -0.28, 0.42);
                        break;
                    case 7: // 稀有
                        poseStack.translate(-0.05, -0.32, 0.43);
                        break;
                    case 8: // 史诗
                        poseStack.translate(-0.05, -0.35, 0.43);
                        break;
                    case 9: // 传奇
                        poseStack.translate(-0.05, -0.4, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:siamese_fighting_fish":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.07, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.0, -0.1, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.0, -0.1, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0., -0.12, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, -0.15, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0, -0.15, 0.45);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0, -0.17, 0.45);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.0, -0.2, 0.43);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.0, -0.2, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:sardine":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0.03, 0.0, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0.03, -0.01, 0.46);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.03, -0.03, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.03, -0.05, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.03, -0.05, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.03, -0.05, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.03, -0.08, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.03, -0.09, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.03, -0.10, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.03, -0.11, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:sailfish":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(-0.03, -0.17, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(-0.03, -0.2, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(-0.03, -0.24, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(-0.05, -0.29, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(-0.05, -0.35, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(-0.1, -0.43, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(-0.1, -0.45, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(-0.1, -0.48, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(-0.1, -0.5, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(-0.1, -0.54, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:plecostomus":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0., -0.05, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.05, -0.1, 0.35);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.05, -0.1, 0.35);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.05, -0.1, 0.35);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.05, -0.1, 0.35);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:piranha":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0., -0.05, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0, -0.1, 0.45);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0, -0.1, 0.45);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0, -0.1, 0.45);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0, -0.1, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:northern_pike":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0., -0.05, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.05, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.05, -0.05, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.05, -0.05, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.04, -0.1, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.05, -0.1, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.05, -0.1, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.05, -0.1, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:nile_perch":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0.05, -0.1, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0.05, -0.1, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.05, -0.1, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.05, -0.15, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.10, -0.15, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.10, -0.15, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.15, -0.3, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.15, -0.3, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.15, -0.35, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.15, -0.35, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:minnow":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.03, -0.030, 0.45);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.03, -0.030, 0.45);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.03, -0.030, 0.45);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.03, -0.03, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:mekong_giant_catfish":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, -0.15, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0.05, -0.15, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.1, -0.18, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.1, -0.2, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.1, -0.2, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.1, -0.25, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.1, -0.3, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.1, -0.3, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.1, -0.35, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.1, -0.4, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:lanternfish":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.02, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.03, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.02, -0.04, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.02, -0.05, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.02, -0.05, 0.45);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.02, -0.07, 0.45);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.02, -0.08, 0.45);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.05, -0.1, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:haddock":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.02, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.03, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.05, -0.04, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.05, -0.05, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.05, -0.05, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.05, -0.07, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.05, -0.08, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.1, -0.1, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:guppy":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.0, 0, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.0, 0, 0.45);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0., 0, 0.45);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.0, 0, 0.43);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.0, 0, 0.45);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:grass_carp":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, -0.03, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(-0.02, -0.05, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(-0.03, -0.050, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(-0.0300, -0.1, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(-0.03, -0.13, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(-0.030, -0.15, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(-0.030, -0.15, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(-0.030, -0.17, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(-0.03, -0.22, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(-0.03, -0.23, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:beluga_sturgeon":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0.1, -0.03, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0.1, -0.05, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.1, -0.050, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.1, -0.1, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.1, -0.11, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.1, -0.11, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.1, -0.15, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.1, -0.17, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.1, -0.20, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.1, -0.21, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:atlantic_bluefin_tuna":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0.03, -0.1, 0.4);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0.05, -0.15, 0.4);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0.1, -0.18, 0.4);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0.1, -0.2, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0.1, -0.21, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0.1, -0.24, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0.1, -0.3, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0.1, -0.33, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0.1, -0.34, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0.1, -0.38, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
            case "bigfishmod:archer_fish":
                switch (stage) {
                    case 0: //鱼苗
                        poseStack.translate(0, 0, 0.45);
                        break;
                    case 1: // 幼鱼
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 2: // 稚鱼
                        poseStack.translate(0, -0.01, 0.45);
                        break;
                    case 3: // 青少年鱼
                        poseStack.translate(0, -0.01, 0.4);
                        break;
                    case 4: // 成年鱼
                        poseStack.translate(0, -0.02, 0.4);
                        break;
                    case 5: // 壮年鱼
                        poseStack.translate(0, -0.02, 0.4);
                        break;
                    case 6: //  成熟鱼
                        poseStack.translate(0, -0.03, 0.4);
                        break;
                    case 7: // 稀有
                        poseStack.translate(0, -0.04, 0.4);
                        break;
                    case 8: // 史诗
                        poseStack.translate(0, -0.05, 0.4);
                        break;
                    case 9: // 传奇
                        poseStack.translate(0, -0.08, 0.4);
                        break;
                    default:
                        poseStack.translate(0, 3, 0); // 默认不调整
                        break;
                }
                break;
        }
                }

    // 根据等级获取体型阶段（0-9）
    public static int getStageFromLevel(int level) {
        return Math.min(level / 5, 9);
    }
}