package net.aurorune.bigfishmod.block.custom;

import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;
import javax.annotation.Nullable;

public class FishBoxBlock extends Block implements EntityBlock {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, OPEN); // 添加 OPEN 属性
    }
    public FishBoxBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(OPEN, false)); // 默认关闭状态
    }
    // 设置放置时的方向（根据玩家朝向）
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }
    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FishBoxBlockEntity(pos, state);
    }
    // 添加关闭动画支持
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof FishBoxBlockEntity be) {
                // 仅在方块被破坏或替换时触发关闭
                if (!newState.isAir()) {
                    be.setOpen(false);}}
            super.onRemove(state, level, pos, newState, isMoving);}
    }
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof FishBoxBlockEntity fishBox) {
                // 统一顺序：先调用setOpen，让它处理状态更新和动画触发
                fishBox.setOpen(true);
                fishBox.incrementPlayersUsing();
                NetworkHooks.openScreen(serverPlayer, fishBox, buf -> buf.writeBlockPos(pos));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof FishBoxBlockEntity fishBox) {
            if (fishBox.shouldCloseAfterDelay()) {
                // 统一顺序：先调用setOpen，让它处理状态更新和动画触发
                fishBox.setOpen(false);
            }
        }
    }


    @Override
    public void playerDestroy(Level level, Player player, BlockPos pos, BlockState state,
                              @Nullable BlockEntity blockEntity, ItemStack stack) {
        if (blockEntity instanceof FishBoxBlockEntity fishBox) {
            // 保存物品到掉落物
            fishBox.setOpenSilently(false);
            ItemStack fishBoxItem = new ItemStack(this);
            CompoundTag tag = fishBox.saveWithoutMetadata();
            fishBoxItem.addTagElement("BlockEntityTag", tag);
            // 移除原有掉落物
            level.getEntitiesOfClass(ItemEntity.class, new AABB(pos).inflate(1.0))
                    .forEach(Entity::discard);

            // 添加包含物品数据的掉落物
            ItemEntity itemEntity = new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, fishBoxItem);
            level.addFreshEntity(itemEntity);
        }
        super.playerDestroy(level, player, pos, state, blockEntity, stack);
    }
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state,
                            @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);

        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof FishBoxBlockEntity fishBox) {
            // 强制设置为关闭状态（不播放动画）
            fishBox.setOpenSilently(false);
            // 恢复物品栏数据（但不恢复打开状态）
            if (stack.hasTag() && stack.getTag().contains("BlockEntityTag")) {
                CompoundTag tag = stack.getTag().getCompound("BlockEntityTag");
                tag.remove("isOpen"); // 移除打开状态标记
                fishBox.load(tag);
            }
        }
    }
    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }
}
