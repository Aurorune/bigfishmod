package net.aurorune.bigfishmod.entity.custom;

import net.aurorune.bigfishmod.api.AdaptiveFishMovementGoal;
import net.aurorune.bigfishmod.api.SchoolingGoal;
import net.aurorune.bigfishmod.api.SimpleBreedGoal;
import net.aurorune.bigfishmod.entity.ModEntities;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class Lanternfish extends AbstractCustomFish implements GeoEntity {
    private static final double BASE_HEALTH = 2.0;
    public static final float[] LANTERNFISH_STAGE_SCALES = {
            0.16f, 0.19f, 0.22f, 0.25f, 0.28f,  // 幼鱼阶段 (0-24级)
            0.31f, 0.34f, 0.37f, 0.4f, 0.43f
    };
    private static final int LANTERNFISH_STAGES_COUNT =LANTERNFISH_STAGE_SCALES.length;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public Lanternfish (EntityType<? extends AbstractCustomFish> entityType, Level level) {
        super(entityType, level);
    }
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // 使用简单的控制器名称
        controllers.add(new AnimationController<>(this, "swim_lanternfish", 5, this::predicate));
    }
    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
        // 确保动画名称与JSON文件中的完全匹配
        event.getController().setAnimation(RawAnimation.begin().thenLoop("animation.lanternfish.swim"));
        return PlayState.CONTINUE;
    }
    @Override
    public void updateScaleFromLevel() {
        int stage = Math.min(getLevel() / 5, LANTERNFISH_STAGES_COUNT - 1);
        setScale(LANTERNFISH_STAGE_SCALES[stage]);
    }
    @Override
    protected float getCalculatedScaleFromLevel(int level) {
        int stage = Math.min(level / 5, LANTERNFISH_STAGES_COUNT - 1);
        return LANTERNFISH_STAGE_SCALES[stage];
    }
    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
    @Override
    public double getTick(Object object) {
        // 修复：返回当前tick计数，而不是固定值0
        return tickCount;
    }

    @Override
    protected void initAttributes() {
        RandomSource rand = this.random;
        // 自定义属性生成规则
        strengthBase = 8 + rand.nextInt(8); // 8-15
        strengthGrowth = 0.2f + rand.nextFloat() * 0.4f; // 0.2-0.6
        staminaBase = 6 + rand.nextInt(8); // 6-13
        staminaGrowth = 0.15f + rand.nextFloat() * 0.3f; // 0.15-0.45
        perceptionBase = 4 + rand.nextInt(10); // 4-13
        perceptionGrowth = 0.25f + rand.nextFloat() * 0.35f; // 0.25-0.6
        luckBase = 3 + rand.nextInt(12); // 3-14
        luckGrowth = 0.1f + rand.nextFloat() * 0.5f; // 0.1-0.6
        weightBase = 0.005f + rand.nextFloat() * 0.01f;    // 0.005-0.015kg
        weightGrowth = 0.0008f + rand.nextFloat() * 0.0012f; // 0.0008-0.002k

        // 设置初始等级（可根据需要调整）
        setRandomMaxLevel();
        int initialLevelRange = Math.min(50, getMaxLevelCap());
        int randomLevel = 1 + rand.nextInt(initialLevelRange);
        setLevel(randomLevel);
    }
    @Override
    public double getScaledHealth() {
        float scale = getScale();
        return BASE_HEALTH * (1.0 + (scale - 1.0) * 0.5);
    }
    public static AttributeSupplier.Builder createAttributes() {
        return AbstractFish.createAttributes()
                .add(Attributes.MAX_HEALTH, BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.3);
    }
    @Override
    public  ItemStack getBucketItem() {
        return new ItemStack(ModItems.LANTERNFISH_BUCKET.get());
    }
    @Override
    public ItemStack getBucketItemForWoodenBucket() {
        return new ItemStack(ModItems.LANTERNFISH_WOODEN.get());
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.COD_DEATH;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.COD_HURT;
    }
    @Override
    public void die(DamageSource source) {
        super.die(source);
        // 触发死亡动画
        this.triggerAnim("death_controller", "death");
    }
    @Override
    protected void dropAllDeathLoot(DamageSource source) {
        if (!this.level().isClientSide && getLevel() > 15) {
            ItemStack fishDrop = new ItemStack(ModItems.LANTERNFISH.get());
            int count = 1 ;
            fishDrop.setCount(count);
            // 准备属性标签
            CompoundTag attributes = new CompoundTag();
            attributes.putFloat("StrBase", strengthBase);
            attributes.putFloat("StrGrowth", strengthGrowth);
            attributes.putFloat("StamBase", staminaBase);
            attributes.putFloat("StamGrowth", staminaGrowth);
            attributes.putFloat("PerceptionBase", perceptionBase); // 统一使用PerceptionBase
            attributes.putFloat("PerceptionGrowth", perceptionGrowth); // 统一使用PerceptionGrowth
            attributes.putFloat("LuckBase", luckBase);
            attributes.putFloat("LuckGrowth", luckGrowth);
            attributes.putFloat("WeightBase", weightBase);
            attributes.putFloat("WeightGrowth", weightGrowth);
            // 使用统一的方法设置NBT
            CompoundTag fishData = new CompoundTag();
            fishData.putInt("FishLevel", getLevel());
            fishData.put("Attributes", attributes);
            CustomFishTrophyItem.setFishData(fishDrop, fishData);
            this.spawnAtLocation(fishDrop);
        }
    }

    @Override
    protected SoundEvent getFlopSound() {
        return SoundEvents.COD_FLOP;
    }
    @Override
    protected void registerGoals() {
        super.registerGoals();
        SimpleBreedGoal breedGoal = new SimpleBreedGoal(
                this,
                // 在这里指定繁殖食物
                stack -> stack.getItem() == Items.KELP
        );
        this.goalSelector.addGoal(1, breedGoal);
        // 将繁殖目标设置到实体中，以便交互时使用
        this.setBreedGoal(breedGoal);
        this.goalSelector.addGoal(3, new SchoolingGoal(
                this,
                1.0,           // 速度修饰符
                25,            // 检查间隔
                80,            // 最大鱼群规模（超大群）
                10.0,          // 跟随范围
                0.8,           // 凝聚因子（高）
                0.15,          // 分离因子（低）
                0.5,           // 对齐因子
                0.92,          // 加入概率（很高）
                0.002          // 离开概率（很低）
        ));
        this.goalSelector.addGoal(5, new AdaptiveFishMovementGoal(
                this,
                1.1,           // 速度修正
                30,            // 检查间隔
                AdaptiveFishMovementGoal.MovementMode.MID_WATER,
                0.3f,          // 最小深度（较深）
                0.2f,          // 底栖模式权重
                0.7f,          // 中层水域权重（最高）
                0.1f,          // 水面模式权重（很低）
                0.01f          // 跃出概率（几乎不跃出）
        ));

        this.goalSelector.addGoal(5, new PanicGoal(this, 1.25));
    }
    @Override
    public void onAddedToWorld() {
        super.onAddedToWorld();
        // 确保实体已经完全初始化后再启用鱼群功能
        enableSchooling(true);
    }
    @Override
    public Lanternfish getBreedOffspring(ServerLevel world, AbstractCustomFish partner) {
        return ModEntities.LANTERNFISH.get().create(world);
    }
}
