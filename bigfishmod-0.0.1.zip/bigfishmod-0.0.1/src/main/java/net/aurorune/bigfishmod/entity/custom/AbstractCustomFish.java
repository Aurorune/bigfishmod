package net.aurorune.bigfishmod.entity.custom;

import net.aurorune.bigfishmod.api.BreachingFish;
import net.aurorune.bigfishmod.api.SimpleBreedGoal;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraft.world.entity.animal.Bucketable;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;


public abstract class AbstractCustomFish extends AbstractFish implements Bucketable , BreachingFish {
    private static final EntityDataAccessor<Boolean> IN_SCHOOL =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> IS_SCHOOL_LEADER =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.BOOLEAN);
    private EntityDimensions baseDimensions;
    private static final int MAX_LEVEL = 50;
    public static final int STAGES_COUNT = 10;
    public static final float[] STAGE_SCALES = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f};
    private boolean initializing = false;
    private  List<AbstractCustomFish> schoolMembers = new ArrayList<>();
    private AbstractCustomFish schoolLeader;
    private boolean schoolingEnabled = false;
    private boolean attributesInitialized = true;
    // 粒子特效相关
    private int particleCooldown = 0;
    private static final int PARTICLE_INTERVAL = 10; // 每10tick生成一次粒子
    private static final boolean DEBUG_PARTICLES = false;
    private boolean fullyInitialized = false;
    public float strengthBase;
    public float strengthGrowth;
    public float staminaBase;
    public float staminaGrowth;
    public float perceptionBase;
    public float perceptionGrowth;
    public float luckBase;
    public float luckGrowth;
    public float weightBase;
    public float weightGrowth;
    public boolean wasInWater = true;
    private int breedingCooldown = 0;
    private SimpleBreedGoal breedGoal;
    private boolean isNewlyCreated = false;
    private int maxLevelCapBackup = -1;
    private boolean maxLevelCapSet = false;
    public boolean isVegetarian;
    private double cachedWaterSurfaceY;
    private int waterSurfaceUpdateTimer = 0;
    private static final int WATER_SURFACE_UPDATE_INTERVAL = 40;
    protected static final EntityDataAccessor<Integer> MAX_LEVEL_CAP =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> BREACHING =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> IS_MUTANT =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.BOOLEAN);

    protected static final EntityDataAccessor<Boolean> FROM_BUCKET =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.BOOLEAN);
    protected static final EntityDataAccessor<Float> SCALE =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.FLOAT);
    protected static final EntityDataAccessor<Integer> LEVEL =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.INT);
    protected static final EntityDataAccessor<Float> EXPERIENCE =
            SynchedEntityData.defineId(AbstractCustomFish.class, EntityDataSerializers.FLOAT);

    public AbstractCustomFish getBreedOffspring(ServerLevel world, AbstractCustomFish partner) {
        Entity offspring = this.getType().create(world);
        if (!(offspring instanceof AbstractCustomFish)) {
            throw new IllegalStateException("Offspring must be an instance of AbstractCustomFish");
        }
        AbstractCustomFish child = (AbstractCustomFish) offspring;
        return child;
    }

    public SimpleBreedGoal getBreedGoal() {
        return this.breedGoal;
    }

    public AbstractCustomFish(EntityType<? extends AbstractFish> entityType, Level level) {
        super(entityType, level);
        this.baseDimensions = entityType.getDimensions();
        this.isVegetarian = true;
        if (this.schoolMembers == null) {
            this.schoolMembers = new ArrayList<>();
        }
        if (!level.isClientSide) {
            this.isNewlyCreated = true;
            this.attributesInitialized = false;
        }

        boolean isInWaterNow = this.isInWater();
        if (isInWaterNow != wasInWater) {
            wasInWater = isInWaterNow;
            if (isInWaterNow) {
                onEnterWater();
            } else {
                onExitWater();
            }
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(BREACHING, false);
        this.entityData.define(FROM_BUCKET, false);
        this.entityData.define(SCALE, 1.0f);
        this.entityData.define(LEVEL, 1);
        this.entityData.define(IN_SCHOOL, false);
        this.entityData.define(IS_SCHOOL_LEADER, false);
        this.entityData.define(IS_MUTANT, false);
        this.entityData.define(EXPERIENCE, 0.0f);
        this.entityData.define(MAX_LEVEL_CAP, 50);
    }

    @Override
    public boolean isBreaching() {
        return this.entityData.get(BREACHING);
    }

    @Override
    public void setBreaching(boolean breaching) {
        this.entityData.set(BREACHING, breaching);
    }

    protected void onEnterWater() {
        this.setDeltaMovement(
                this.getDeltaMovement().x * 0.5,
                this.getDeltaMovement().y * 0.5,
                this.getDeltaMovement().z * 0.5
        );
    }

    protected void onExitWater() {
        if (this.getDeltaMovement().y > 0) {
            this.setDeltaMovement(
                    this.getDeltaMovement().x,
                    Math.min(this.getDeltaMovement().y, 0.3),
                    this.getDeltaMovement().z
            );
        }
    }

    public double getScaledHealth() {
        float scale = getScale();
        double baseHealth = 3.0;
        return baseHealth * (1.0 + (scale - 1.0) * 0.5);
    }

    public float getWeight() {
        return weightBase + weightGrowth * (getLevel() - 1);
    }

    @Override
    public void tick() {
        super.tick();
        if (++waterSurfaceUpdateTimer >= WATER_SURFACE_UPDATE_INTERVAL) {
            waterSurfaceUpdateTimer = 0;
            cachedWaterSurfaceY = computeWaterSurfaceY();
        }

        // 监控数据异常重置
        if (!this.level().isClientSide && attributesInitialized && maxLevelCapSet) {
            int currentEntityData = this.entityData.get(MAX_LEVEL_CAP);
            if (currentEntityData == 50 && maxLevelCapBackup != 50 && maxLevelCapBackup != -1) {
                this.entityData.set(MAX_LEVEL_CAP, maxLevelCapBackup);
            }
        }

        if (!fullyInitialized && this.tickCount > 0) {
            markAsFullyInitialized();
        }

        if (!this.level().isClientSide && this.tickCount == 1 && !attributesInitialized) {
            initAttributes();
            updateScaleFromLevel();
            attributesInitialized = true;
        }

        if (isSchoolLeader() && tickCount % 100 == 0) {
            schoolMembers.removeIf(fish -> !fish.isAlive() || fish.distanceToSqr(this) > getSchoolFollowRange() * getSchoolFollowRange() * 4);
        }

        spawnSchoolingParticles();

        if (breedingCooldown > 0) {
            breedingCooldown--;
        }

        if (!this.level().isClientSide) {
            if (this.tickCount % 600 == 0 && this.isInWater()) {
                addExperience(100f);
            }
        }
    }
    private double computeWaterSurfaceY() {
        BlockPos pos = this.blockPosition();
        int searchRange = 10;

        for (int i = 0; i < searchRange; i++) {
            FluidState fluidState = this.level().getFluidState(pos);
            if (!fluidState.is(FluidTags.WATER) || fluidState.getAmount() < 8) {
                if (i > 0 && this.level().getFluidState(pos.below()).is(FluidTags.WATER)) {
                    return pos.getY() - 0.1;
                } else {
                    break;
                }
            }
            pos = pos.above();
        }

        return this.getY() + 1.0;
    }
    // getter
    public double getCachedWaterSurfaceY() {
        return cachedWaterSurfaceY;
    }
    protected void spawnSchoolingParticles() {
        if (!this.level().isClientSide) return;
        if (!isInSchool() || !isSchoolingEnabled()) return;

        particleCooldown--;
        if (particleCooldown <= 0) {
            particleCooldown = PARTICLE_INTERVAL;

            Level level = this.level();
            double x = this.getX();
            double y = this.getY() + this.getBbHeight() * 0.5;
            double z = this.getZ();

            level.addParticle(ParticleTypes.BUBBLE,
                    x + (random.nextDouble() - 0.5) * 0.3,
                    y + (random.nextDouble() - 0.5) * 0.3,
                    z + (random.nextDouble() - 0.5) * 0.3,
                    0, 0.02, 0);

            if (isSchoolLeader()) {
                level.addParticle(ParticleTypes.GLOW,
                        x + (random.nextDouble() - 0.5) * 0.5,
                        y + (random.nextDouble() - 0.5) * 0.5,
                        z + (random.nextDouble() - 0.5) * 0.5,
                        0, 0.03, 0);
            }
        }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (SCALE.equals(key)) {
            this.refreshDimensions();
        }
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (baseDimensions == null) {
            baseDimensions = this.getType().getDimensions();
        }
        return baseDimensions.scale(getScale());
    }

    @Override
    public void onAddedToWorld() {
        super.onAddedToWorld();
        refreshDimensions();
    }

    protected void initAttributes() {
        RandomSource rand = this.random;
        if (rand == null) {
            rand = RandomSource.create();
        }

        strengthBase = 8 + rand.nextInt(8);
        strengthGrowth = 0.2f + rand.nextFloat() * 0.4f;
        staminaBase = 6 + rand.nextInt(8);
        staminaGrowth = 0.15f + rand.nextFloat() * 0.3f;
        perceptionBase = 4 + rand.nextInt(10);
        perceptionGrowth = 0.25f + rand.nextFloat() * 0.35f;
        luckBase = 3 + rand.nextInt(12);
        luckGrowth = 0.1f + rand.nextFloat() * 0.5f;
        weightBase = 0.5f + rand.nextFloat() * 2.0f;
        weightGrowth = 0.1f + rand.nextFloat() * 0.3f;

        setRandomMaxLevel();
        int initialLevelRange = Math.min(40, getMaxLevelCap());
        int randomLevel = 1 + rand.nextInt(initialLevelRange);
        setLevel(randomLevel);
    }

    public void updateScaleFromLevel() {
        int stage = Math.min(getLevel() / 5, STAGES_COUNT - 1);
        setScale(STAGE_SCALES[stage]);
    }

    public float getStrength() {
        return strengthBase + strengthGrowth * (getLevel() - 1);
    }

    public float getStamina() {
        return staminaBase + staminaGrowth * (getLevel() - 1);
    }

    public float getPerception() {
        return perceptionBase + perceptionGrowth * (getLevel() - 1);
    }

    public float getLuck() {
        return luckBase + luckGrowth * (getLevel() - 1);
    }

    public float getScale() {
        return this.entityData.get(SCALE);
    }

    public void setScale(float scale) {
        this.entityData.set(SCALE, scale);
    }

    public void setLevel(int level) {
        level = Mth.clamp(level, 1, getMaxLevelCap());
        this.entityData.set(LEVEL, level);
        if (!level().isClientSide) {
            updateScaleFromLevel();
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(getScaledHealth());
            this.setHealth(this.getMaxHealth());
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("FishMaxLevel", getMaxLevelCap());
        tag.putBoolean("MaxLevelCapSet", maxLevelCapSet);
        tag.putInt("MaxLevelCapBackup", maxLevelCapBackup);
        tag.putBoolean("fromBucket", this.fromBucket());
        tag.putBoolean("IsMutant", isMutant());
        tag.putInt("BreedingCooldown", breedingCooldown);
        tag.putFloat("FishScale", this.getScale());
        tag.putInt("FishLevel", getLevel());
        tag.putFloat("FishExperience", getExperience());
        tag.putBoolean("InSchool", isInSchool());
        tag.putBoolean("IsSchoolLeader", isSchoolLeader());
        tag.putBoolean("SchoolingEnabled", schoolingEnabled);

        CompoundTag attributesTag = new CompoundTag();
        attributesTag.putFloat("StrBase", strengthBase);
        attributesTag.putFloat("StrGrowth", strengthGrowth);
        attributesTag.putFloat("StamBase", staminaBase);
        attributesTag.putFloat("StamGrowth", staminaGrowth);
        attributesTag.putFloat("PerceptionBase", perceptionBase);
        attributesTag.putFloat("PerceptionGrowth", perceptionGrowth);
        attributesTag.putFloat("LuckBase", luckBase);
        attributesTag.putFloat("LuckGrowth", luckGrowth);
        attributesTag.putFloat("WeightBase", weightBase);
        attributesTag.putFloat("WeightGrowth", weightGrowth);
        tag.put("Attributes", attributesTag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);

        if (this.fromBucket()) {
            return;
        }

        if (tag.contains("MaxLevelCapBackup")) {
            maxLevelCapBackup = tag.getInt("MaxLevelCapBackup");
        }
        if (tag.contains("MaxLevelCapSet")) {
            maxLevelCapSet = tag.getBoolean("MaxLevelCapSet");
        }

        if (tag.contains("FishMaxLevel")) {
            int savedMaxLevel = tag.getInt("FishMaxLevel");
            this.entityData.set(MAX_LEVEL_CAP, savedMaxLevel);
            if (maxLevelCapBackup == -1) {
                maxLevelCapBackup = savedMaxLevel;
                maxLevelCapSet = true;
            }
        }

        boolean hasLevelData = tag.contains("FishLevel");

        if (isNewlyCreated && !hasLevelData) {
            initAttributes();
            updateScaleFromLevel();
            this.isNewlyCreated = false;
            this.attributesInitialized = true;
        } else {
            if (tag.contains("IsMutant")) {
                setMutant(tag.getBoolean("IsMutant"));
            }
            if (tag.contains("BreedingCooldown")) {
                breedingCooldown = tag.getInt("BreedingCooldown");
            }
            if (tag.contains("SchoolingEnabled")) {
                schoolingEnabled = tag.getBoolean("SchoolingEnabled");
            } else {
                schoolingEnabled = false;
            }

            setInSchool(tag.getBoolean("InSchool"));
            setSchoolLeader(tag.getBoolean("IsSchoolLeader"));

            if (tag.contains("FishLevel")) {
                setLevel(tag.getInt("FishLevel"));
            }
            if (tag.contains("FishMaxLevel")) {
                setMaxLevelCap(tag.getInt("FishMaxLevel"));
            }
            if (tag.contains("FishExperience")) {
                this.entityData.set(EXPERIENCE, tag.getFloat("FishExperience"));
            }

            if (tag.contains("Attributes", Tag.TAG_COMPOUND)) {
                CompoundTag attributesTag = tag.getCompound("Attributes");
                strengthBase = attributesTag.getFloat("StrBase");
                strengthGrowth = attributesTag.getFloat("StrGrowth");
                staminaBase = attributesTag.getFloat("StamBase");
                staminaGrowth = attributesTag.getFloat("StamGrowth");
                perceptionBase = attributesTag.getFloat("PerceptionBase");
                perceptionGrowth = attributesTag.getFloat("PerceptionGrowth");
                luckBase = attributesTag.getFloat("LuckBase");
                luckGrowth = attributesTag.getFloat("LuckGrowth");
                weightBase = attributesTag.getFloat("WeightBase");
                weightGrowth = attributesTag.getFloat("WeightGrowth");
            }

            this.isNewlyCreated = false;
            this.attributesInitialized = true;
        }

        if (!this.level().isClientSide) {
            this.level().getServer().execute(() -> {
                if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
                    this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(getScaledHealth());
                    if (tag.contains("Health")) {
                        float health = tag.getFloat("Health");
                        this.setHealth(Math.min(health, this.getMaxHealth()));
                    } else {
                        this.setHealth(this.getMaxHealth());
                    }
                }
            });
        }

        if (tag.contains("BaseWidth") && tag.contains("BaseHeight")) {
            float width = tag.getFloat("BaseWidth");
            float height = tag.getFloat("BaseHeight");
            baseDimensions = EntityDimensions.scalable(width, height);
        } else {
            baseDimensions = this.getType().getDimensions();
        }

        if (tag.contains("FishScale")) {
            this.entityData.set(SCALE, tag.getFloat("FishScale"));
        }
        refreshDimensions();
    }

    @Override
    public void refreshDimensions() {
        super.refreshDimensions();
        if (!this.isInWater() && this.isAlive()) {
            this.setPos(this.getX(), this.getY() + (1.0 - getScale()) * 0.2, this.getZ());
        }
    }

    @Override
    public void saveToBucketTag(ItemStack bucket) {
        super.saveToBucketTag(bucket);
        CompoundTag tag = bucket.getOrCreateTag();

        int maxLevelToSave = getMaxLevelCap();
        tag.putFloat("FishScale", this.getScale());
        tag.putInt("FishLevel", getLevel());
        tag.putInt("FishMaxLevel", maxLevelToSave);

        CompoundTag attributesTag = new CompoundTag();
        attributesTag.putFloat("StrBase", strengthBase);
        attributesTag.putFloat("StrGrowth", strengthGrowth);
        attributesTag.putFloat("StamBase", staminaBase);
        attributesTag.putFloat("StamGrowth", staminaGrowth);
        attributesTag.putFloat("PerceptionBase", perceptionBase);
        attributesTag.putFloat("PerceptionGrowth", perceptionGrowth);
        attributesTag.putFloat("LuckBase", luckBase);
        attributesTag.putFloat("LuckGrowth", luckGrowth);
        attributesTag.putFloat("WeightBase", weightBase);
        attributesTag.putFloat("WeightGrowth", weightGrowth);
        tag.put("Attributes", attributesTag);
    }

    @Override
    public void loadFromBucketTag(CompoundTag tag) {
        super.loadFromBucketTag(tag);

        this.setFromBucket(true);
        this.isNewlyCreated = false;
        this.attributesInitialized = true;

        // --- 1. 检查是否为“无标签”创造模式桶 ---
        // 如果 NBT 中不包含 FishLevel 标签，则视为一个全新的实体，需要进行随机初始化
        if (!tag.contains("FishLevel")) {
            // **关键修复：调用你的随机属性和等级初始化逻辑**
            this.initAttributes();
            // initAttributes() 内部应该已经调用了 setRandomMaxLevel() 和 setLevel(randomLevel)
            // 确保它正确地设置了 LEVEL, SCALE 和 MaxLevelCap。
            // 现在我们只需要确保最终的同步数据刷新。
            // 属性和等级已经设置完毕，直接跳到最后的刷新步骤
            // 注意：这里不需要再从 NBT 加载其他属性，因为 initAttributes 已经生成了
        } else {
            // --- 2. 处理“有标签”的鱼桶（即保存过的鱼）---
            // 2a. 加载所有基础属性
            if (tag.contains("Attributes", Tag.TAG_COMPOUND)) {
                CompoundTag attributesTag = tag.getCompound("Attributes");
                strengthBase = attributesTag.getFloat("StrBase");
                strengthGrowth = attributesTag.getFloat("StrGrowth");
                staminaBase = attributesTag.getFloat("StamBase");
                staminaGrowth = attributesTag.getFloat("StamGrowth");
                perceptionBase = attributesTag.getFloat("PerceptionBase");
                perceptionGrowth = attributesTag.getFloat("PerceptionGrowth");
                luckBase = attributesTag.getFloat("LuckBase");
                luckGrowth = attributesTag.getFloat("LuckGrowth");
                weightBase = attributesTag.getFloat("WeightBase");
                weightGrowth = attributesTag.getFloat("WeightGrowth");
            } else {
                // 如果有 FishLevel 但没有 Attributes，说明数据不完整，仍然调用初始化
                this.initAttributes();
            }
            // 2b. 加载等级上限和当前等级
            int savedMaxLevel = MAX_LEVEL;
            if (tag.contains("FishMaxLevel")) {
                savedMaxLevel = tag.getInt("FishMaxLevel");
                setMaxLevelCap(savedMaxLevel);
            }
            int savedLevel = 1;
            if (tag.contains("FishLevel")) {
                savedLevel = tag.getInt("FishLevel");
            }
            // 2c. 根据加载到的等级，计算并设置正确的体型（沿用上一个回复的健壮设计）
            savedLevel = Mth.clamp(savedLevel, 1, getMaxLevelCap());
            float calculatedScale = getCalculatedScaleFromLevel(savedLevel);
            // 2d. 直接设置同步数据
            this.entityData.set(SCALE, calculatedScale);
            this.entityData.set(LEVEL, savedLevel);
        }

        // --- 3. 最终强制刷新属性和尺寸 (无论是加载还是随机初始化都需要) ---
        // 强制在服务器端更新生命值和刷新尺寸
        if (!level().isClientSide) {
            if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
                // 注意：getMaxHealth() 依赖于 getScaledHealth()，而 getScaledHealth() 依赖于
                // 当前的 SCALE 和属性，这些在前两步已经设置完毕。
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(getScaledHealth());
                this.setHealth(this.getMaxHealth());
            }
        }
        this.refreshDimensions();
    }

    /**
     * 新增一个方法，用于根据等级计算体型。
     * 请将你的 TestFish.TESTFISH_STAGE_SCALES 逻辑移到这里。
     */
    protected float getCalculatedScaleFromLevel(int level) {
        // 默认实现，使用 AbstractCustomFish 的 STAGE_SCALES
        int stage = Math.min(level / 5, STAGES_COUNT - 1);
        return STAGE_SCALES[stage];
    }

    @Override
    public boolean fromBucket() {
        return this.entityData.get(FROM_BUCKET);
    }

    @Override
    public void setFromBucket(boolean fromBucket) {
        this.entityData.set(FROM_BUCKET, fromBucket);
    }

    @Override
    public ItemStack getBucketItemStack() {
        return getBucketItem();
    }

    @Override
    public SoundEvent getPickupSound() {
        return SoundEvents.BUCKET_FILL_FISH;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);

        // ✅ 交配逻辑保留
        if (breedGoal != null && breedGoal.handleInteraction(player, itemstack)) {
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // ✅ 成长逻辑保留
        if (!this.level().isClientSide) {
            if (maxLevelCapBackup == -1 && attributesInitialized) {
                int currentMaxLevel = this.entityData.get(MAX_LEVEL_CAP);
                if (currentMaxLevel != 50) {
                    maxLevelCapBackup = currentMaxLevel;
                    maxLevelCapSet = true;
                } else {
                    int currentLevel = getLevel();
                    if (currentLevel > 1) {
                        int estimatedMax;
                        if (currentLevel <= 5) {
                            estimatedMax = 15 + random.nextInt(16);
                        } else if (currentLevel <= 10) {
                            estimatedMax = 20 + random.nextInt(16);
                        } else if (currentLevel <= 15) {
                            estimatedMax = 25 + random.nextInt(16);
                        } else {
                            estimatedMax = Math.max(currentLevel + 5, 30 + random.nextInt(21));
                        }
                        estimatedMax = Math.min(estimatedMax, 50);
                        setMaxLevelCap(estimatedMax);
                    }
                }
            }
        }

        // ✅ 捕捞逻辑：先判断木桶
        if (itemstack.getItem() == ModItems.WOODEN_BUCKET.get()) {
            ItemStack bucketWithFish = this.getBucketItemForWoodenBucket(); // 🔑 调用具体类提供的实现
            this.saveToBucketTag(bucketWithFish); // 保存 NBT
            if (this.hasCustomName()) {
                bucketWithFish.setHoverName(this.getCustomName());
            }

            if (!player.getAbilities().instabuild) {
                itemstack.shrink(1);
            }
            if (!player.getInventory().add(bucketWithFish)) {
                player.drop(bucketWithFish, false);
            }

            this.discard(); // 移除实体
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // ✅ 兜底：保留铁桶逻辑（原版）
        return Bucketable.bucketMobPickup(player, hand, this).orElse(super.mobInteract(player, hand));
    }
    public void setBreedGoal(SimpleBreedGoal breedGoal) {
        this.breedGoal = breedGoal;
    }

    @Override
    protected void dropAllDeathLoot(DamageSource source) {
        super.dropAllDeathLoot(source);
        if (!this.level().isClientSide) {
            ItemStack fishDrop = new ItemStack(Items.COD);
            int count = 1 + (int) getScale();
            fishDrop.setCount(count);
            this.spawnAtLocation(fishDrop);
            if (getScale() > 1.0f) {
                ItemStack boneMealDrop = new ItemStack(Items.BONE_MEAL, 1 + (int) getScale());
                this.spawnAtLocation(boneMealDrop);
            }
        }
    }

    @Override
    protected SoundEvent getSwimSound() {
        return SoundEvents.FISH_SWIM;
    }

    public abstract ItemStack getBucketItem();
    protected abstract SoundEvent getDeathSound();
    protected abstract SoundEvent getHurtSound(DamageSource source);
    protected abstract SoundEvent getFlopSound();

    public static AttributeSupplier.Builder createBaseAttributes() {
        return AbstractFish.createAttributes()
                .add(Attributes.MAX_HEALTH, 3.0)
                .add(Attributes.MOVEMENT_SPEED, 0.4);
    }

    @Override
    public RandomSource getRandom() {
        return this.random;
    }

    @Override
    public PathNavigation getNavigation() {
        return this.navigation;
    }

    @Override
    public Vec3 getDeltaMovement() {
        return super.getDeltaMovement();
    }

    @Override
    public void setDeltaMovement(Vec3 motion) {
        super.setDeltaMovement(motion);
    }

    @Override
    public void setDeltaMovement(double x, double y, double z) {
        super.setDeltaMovement(x, y, z);
    }

    @Override
    public BlockPos blockPosition() {
        return super.blockPosition();
    }

    @Override
    public Level level() {
        return super.level();
    }

    @Override
    public Vec3 getLookAngle() {
        return super.getLookAngle();
    }

    @Override
    public boolean onGround() {
        return super.onGround();
    }

    @Override
    public boolean isHorizontalCollision() {
        return this.horizontalCollision;
    }

    @Override
    public boolean isVerticalCollision() {
        return this.verticalCollision;
    }

    @Override
    public boolean isInWater() {
        return super.isInWater();
    }

    @Override
    public Entity getEntity() {
        return this;
    }

    public int getMaxLevelCap() {
        if (maxLevelCapSet && maxLevelCapBackup != -1) {
            return maxLevelCapBackup;
        }
        return this.entityData.get(MAX_LEVEL_CAP);
    }

    public void setMaxLevelCap(int maxLevelCap) {
        int newValue = Math.max(1, Math.min(maxLevelCap, MAX_LEVEL));
        this.maxLevelCapBackup = newValue;
        this.maxLevelCapSet = true;
        this.entityData.set(MAX_LEVEL_CAP, newValue);
    }

    @Override
    public int getLevel() {
        return this.entityData.get(LEVEL);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
    }

    // 鱼群相关方法
    public boolean isInSchool() {
        return this.entityData.get(IN_SCHOOL);
    }

    public void setInSchool(boolean inSchool) {
        this.entityData.set(IN_SCHOOL, inSchool);
    }

    public boolean isSchoolLeader() {
        return this.entityData.get(IS_SCHOOL_LEADER);
    }

    public void setSchoolLeader(boolean isLeader) {
        this.entityData.set(IS_SCHOOL_LEADER, isLeader);
        if (schoolMembers != null) {
            if (isLeader) {
                schoolMembers.clear();
                schoolMembers.add(this);
            } else {
                schoolMembers.clear();
            }
        }
    }

    public boolean hasSchoolLeader() {
        return schoolLeader != null;
    }

    public AbstractCustomFish getSchoolLeader() {
        return schoolLeader;
    }

    public void setSchoolLeader(AbstractCustomFish leader) {
        this.schoolLeader = leader;
    }

    public List<AbstractCustomFish> getSchoolMembers() {
        return schoolMembers;
    }

    public int getSchoolSize() {
        return schoolMembers.size();
    }

    public void addToSchool(AbstractCustomFish fish) {
        if (schoolMembers != null && !schoolMembers.contains(fish) && schoolMembers.size() < getMaxSchoolSize()) {
            schoolMembers.add(fish);
            fish.setSchoolLeader(this);
            fish.setInSchool(true);
        }
    }

    public void removeFromSchool(AbstractCustomFish fish) {
        if (schoolMembers != null) {
            schoolMembers.remove(fish);
            fish.setSchoolLeader(null);
            fish.setInSchool(false);
        }
    }

    public void enableSchooling(boolean enabled) {
        this.schoolingEnabled = enabled;
        if (fullyInitialized) {
            if (!enabled) {
                leaveSchool();
            }
        }
    }

    public void markAsFullyInitialized() {
        this.fullyInitialized = true;
        if (this.schoolingEnabled) {
            // 可以在这里执行任何需要的初始化
        }
    }

    public boolean isSchoolingEnabled() {
        return schoolingEnabled;
    }

    protected int getMaxSchoolSize() {
        return 15;
    }

    protected double getSchoolFollowRange() {
        return 8.0;
    }

    protected double getSchoolCohesionFactor() {
        return 0.5;
    }

    protected double getSchoolSeparationFactor() {
        return 0.3;
    }

    protected double getSchoolAlignmentFactor() {
        return 0.2;
    }

    protected double getSchoolJoinProbability() {
        return 0.7;
    }

    protected double getSchoolLeaveProbability() {
        return 0.01;
    }

    protected double getSchoolSpeedModifier() {
        return 1.0;
    }

    protected int getSchoolCheckInterval() {
        return 40;
    }
    protected void leaveSchool() {
        if (schoolLeader != null && schoolLeader != this) {
            schoolLeader.removeFromSchool(this);
        }
        setInSchool(false);
        setSchoolLeader(false);
        schoolLeader = null;
    }
    public boolean isMutant() {
        return this.entityData.get(IS_MUTANT);
    }
    public void setMutant(boolean mutant) {
        this.entityData.set(IS_MUTANT, mutant);
    }
    public float getRequiredXpForNextLevel() {
        int currentLevel = getLevel();
        int maxLevelCap = getMaxLevelCap();

        if (currentLevel >= maxLevelCap) {
            return -1; // 达到该鱼的最高等级
        }
        return (float) (10 + Math.pow(currentLevel, 1.5) * 5);
    }

    /**
     * 添加经验值
     */
    public void addExperience(float xp) {
        if (this.level().isClientSide) {
            return;
        }

        float currentXp = getExperience();
        float requiredXp = getRequiredXpForNextLevel();
        int maxLevelCap = getMaxLevelCap();

        // 如果已达该鱼的最高等级，不再增加经验
        if (requiredXp == -1 || getLevel() >= maxLevelCap) {
            return;
        }

        currentXp += xp;

        // 检查是否升级
        while (currentXp >= requiredXp && getLevel() < maxLevelCap) {
            currentXp -= requiredXp;
            setLevel(getLevel() + 1);
            requiredXp = getRequiredXpForNextLevel();

            // 达到该鱼的最高等级后，将经验值归零
            if (requiredXp == -1 || getLevel() >= maxLevelCap) {
                currentXp = 0;
                break;
            }
        }
        this.entityData.set(EXPERIENCE, currentXp);
    }
    /**
     * 获取当前经验值
     */
    public float getExperience() {
        return this.entityData.get(EXPERIENCE);
    }
    private float calculateExperienceMultiplier(int currentLevel) {
        if (currentLevel < 15) {
            // 小鱼阶段：经验获取效率高
            return 2.0f;
        } else if (currentLevel < 30) {
            // 青年鱼阶段：正常经验获取
            return 1.0f;
        } else {
            // 成年鱼阶段：经验获取效率低
            return 0.3f;
        }
    }
    public void setRandomMaxLevel() {
        RandomSource rand = this.random;
        if (rand == null) {
            rand = RandomSource.create();
        }
        float roll = rand.nextFloat();
        int maxLevel;
        if (roll < 0.4f) {
            maxLevel = 15 + rand.nextInt(16); // 15-30
        } else if (roll < 0.9f) {
            maxLevel = 25 + rand.nextInt(16); // 20-40
        } else {
            maxLevel = 40 + rand.nextInt(11); // 40-50
        }
        setMaxLevelCap(maxLevel);
    }
    public boolean isVegetarian() {
        return this.isVegetarian;
    }

    public void setVegetarian(boolean isVegetarian) {
        this.isVegetarian = isVegetarian;
    }
    public void setMovementTarget(Vec3 target, double speed) {
        if (this.getNavigation() != null) {
            this.getNavigation().moveTo(target.x, target.y, target.z, speed);
        }
    }
    public void markInitialized() {
        this.attributesInitialized = true;
        this.isNewlyCreated = false;
    }
    public ItemStack getBucketItemForWoodenBucket() {
        return new ItemStack(ModItems.TEXTFISH_WOODEN.get());
    }
}

