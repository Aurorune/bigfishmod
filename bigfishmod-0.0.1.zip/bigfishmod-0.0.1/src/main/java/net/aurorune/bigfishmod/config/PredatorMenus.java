package net.aurorune.bigfishmod.config;

import net.aurorune.bigfishmod.api.PredatorConfig;
import net.aurorune.bigfishmod.entity.ModEntities;
import net.aurorune.bigfishmod.entity.custom.*;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.player.Player;

public class PredatorMenus {
    // 默认捕食菜单 - 适合中等大小的捕食者
    public static final PredatorConfig[] DEFAULT_MENU = {
            new PredatorConfig(Minnow.class, 0, 30),
            new PredatorConfig(Guppy.class, 0, 30),
            new PredatorConfig(Loach.class, 0, 40),
            new PredatorConfig(Sailfish.class, 0, 35),
            new PredatorConfig(TestFish.class, 0, 50),
            new PredatorConfig(ArcherFish.class, 5, 45)
    };
    public static final PredatorConfig[] SMALL_PREDATOR_MENU = {
            new PredatorConfig(Minnow.class, 0, 30),
            new PredatorConfig(Guppy.class, 0, 30),
            new PredatorConfig(Loach.class, 0, 40),
            new PredatorConfig(Sardine.class, 0, 35),
            new PredatorConfig(TestFish.class, 0, 50),
            new PredatorConfig(ArcherFish.class, 5, 45)
    };
    // 小型捕食者菜单 - 只能捕食很小的猎物
    public static final PredatorConfig[] TESTFISH_PREDATOR_MENU = {
            new PredatorConfig(TestFish.class, 0, 100),
    };
    public static final PredatorConfig[] SIAMESE_FIGHTING_FISH_PREDATOR_MENU = {
            new PredatorConfig(SiameseFightingFish.class, 0, 100),
    };
    // 中型捕食者菜单 - 捕食中小型鱼类
    public static final PredatorConfig[] MEDIUM_PREDATOR_MENU = {
            new PredatorConfig(Minnow.class, 0, 20),
            new PredatorConfig(Guppy.class, 0, 20),
            new PredatorConfig(Loach.class, 0, 25),
            new PredatorConfig(Sardine.class, 0, 20),
            new PredatorConfig(TestFish.class, 0, 30),
            new PredatorConfig(ArcherFish.class, 0, 35),
            new PredatorConfig(Tilapia.class, 5, 40),
            new PredatorConfig(Haddock.class, 5, 45),
            new PredatorConfig(Plecostomus.class, 10, 50)
    };

    // 大型捕食者菜单 - 捕食中型鱼类
    public static final PredatorConfig[] LARGE_PREDATOR_MENU = {
            new PredatorConfig(Tilapia.class, 0, 35),
            new PredatorConfig(Haddock.class, 0, 30),
            new PredatorConfig(Plecostomus.class, 0, 40),
            new PredatorConfig(GrassCarp.class, 5, 45),
            new PredatorConfig(NorthernPike.class, 10, 50),
            new PredatorConfig(SiameseFightingFish.class, 0, 30),
            new PredatorConfig(Piranha.class, 5, 35),
            new PredatorConfig(Lanternfish.class, 0, 25)
    };

    // 顶级捕食者菜单 - 捕食大型鱼类
    public static final PredatorConfig[] APEX_PREDATOR_MENU = {
            new PredatorConfig(GrassCarp.class, 0, 40),
            new PredatorConfig(NorthernPike.class, 0, 45),
            new PredatorConfig(NilePerch.class, 5, 50),
            new PredatorConfig(Sailfish.class, 10, 60),
            new PredatorConfig(MekongGiantCatfish.class, 20, 80),
            new PredatorConfig(BelugaSturgeon.class, 25, 100),
            new PredatorConfig(AtlanticBluefinTuna.class, 15, 70)
    };

    // 攻击性鱼类菜单 - 专门针对攻击性鱼类
    public static final PredatorConfig[] AGGRESSIVE_PREDATOR_MENU = {
            new PredatorConfig(SiameseFightingFish.class, 0, 40),
            new PredatorConfig(Piranha.class, 0, 45),
            new PredatorConfig(NorthernPike.class, 5, 50),
            new PredatorConfig(ArcherFish.class, 0, 35),
            new PredatorConfig(TestFish.class, 0, 30)
    };

    // 其他菜单配置保持一致...

    // 创建自定义菜单的辅助方法
    public static PredatorConfig[] createCustomMenu(PredatorConfig... configs) {
        return configs;
    }

    // 创建基于等级的菜单
    public static PredatorConfig[] createLevelBasedMenu(int predatorLevel) {
        if (predatorLevel < 10) {
            return SMALL_PREDATOR_MENU;
        } else if (predatorLevel < 25) {
            return MEDIUM_PREDATOR_MENU;
        } else if (predatorLevel < 40) {
            return LARGE_PREDATOR_MENU;
        } else {
            return APEX_PREDATOR_MENU;
        }
    }
}