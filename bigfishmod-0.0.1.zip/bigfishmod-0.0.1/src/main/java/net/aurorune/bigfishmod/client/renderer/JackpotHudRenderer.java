package net.aurorune.bigfishmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.aurorune.bigfishmod.api.BuffMessageUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.awt.*;
import java.util.Random;

@Mod.EventBusSubscriber(modid = "bigfishmod", value = Dist.CLIENT)
public class JackpotHudRenderer {
    private static String hudMessage = "";
    private static int displayTicks = 0;
    private static BuffMessageUtil.BuffType currentType = null; // 存储当前消息类型

    private static final int DURATION = 300;
    private static final int FADE_OUT_TICKS = 40;
    private static final long RAINBOW_SPEED = 8L;

    // 降低 Curse 震动强度
    private static final float CURSE_SHAKING_STRENGTH = 3.5f;
    // Jackpot 无震动
    private static final float DEFAULT_SHAKING_STRENGTH = 0.0f;

    private static final Random random = new Random();

    public static void showSpecialMessage(String message, BuffMessageUtil.BuffType type) {
        hudMessage = message;
        currentType = type;
        displayTicks = DURATION;
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (displayTicks <= 0 || hudMessage.isEmpty()) {
            return;
        }

        GuiGraphics guiGraphics = event.getGuiGraphics();
        PoseStack poseStack = guiGraphics.pose();
        Minecraft mc = Minecraft.getInstance();

        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int screenHeight = mc.getWindow().getGuiScaledHeight();

        int x = 0;
        int y = 0;

        if (currentType == BuffMessageUtil.BuffType.JACKPOT) {
            int textWidth = mc.font.width(hudMessage);
            x = (screenWidth - textWidth) / 2;
            y = screenHeight / 2 + screenHeight / 5 - 2;
        } else if (currentType == BuffMessageUtil.BuffType.CURSE) {
            int textWidth = mc.font.width(hudMessage);
            x = (screenWidth - textWidth) / 2;
            y = screenHeight / 2 + screenHeight / 5-2;
        } else {
            return;
        }

        poseStack.pushPose();
        float scale = 1.4f;
        poseStack.scale(scale, scale, scale);

        renderSpecialText(guiGraphics, hudMessage, (int)(x / scale), (int)(y / scale), currentType);

        poseStack.popPose();
        displayTicks--;
    }

    private static void renderSpecialText(GuiGraphics guiGraphics, String text, int x, int y, BuffMessageUtil.BuffType type) {
        Minecraft mc = Minecraft.getInstance();
        long currentTime = System.currentTimeMillis();

        float alpha = 1.0f;
        if (displayTicks < FADE_OUT_TICKS) {
            alpha = (float) displayTicks / FADE_OUT_TICKS;
        }
        int alphaInt = (int) (alpha * 255);

        // 关键改动：根据类型动态设置震动强度
        float shakingStrength = (type == BuffMessageUtil.BuffType.CURSE) ? CURSE_SHAKING_STRENGTH : DEFAULT_SHAKING_STRENGTH;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            String charStr = String.valueOf(c);

            int color = 0;

            if (type == BuffMessageUtil.BuffType.JACKPOT) {
                int phaseOffset = i * 20;
                int hue = (int) ((currentTime / RAINBOW_SPEED + phaseOffset) % 360);
                color = Color.HSBtoRGB(hue / 360f, 0.9f, 1.0f);
            } else { // Curse
                color = (random.nextBoolean()) ? 0x2B2B2B : 0x550000;
            }

            color = (alphaInt << 24) | (color & 0x00FFFFFF);

            int charX = x + mc.font.width(text.substring(0, i));

            // 只有当 shakingStrength > 0 时才应用偏移
            int offsetX = (int) ((shakingStrength > 0) ? (random.nextFloat() * shakingStrength - shakingStrength / 2) : 0);
            int offsetY = (int) ((shakingStrength > 0) ? (random.nextFloat() * shakingStrength - shakingStrength / 2) : 0);

            guiGraphics.drawString(
                    mc.font,
                    charStr,
                    charX + offsetX,
                    y + offsetY,
                    color,
                    true // 加粗效果
            );
        }
    }
}