package net.aurorune.bigfishmod.blockentity.custom;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.api.LogUtil;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class TrophyBaseBlockEntity extends BlockEntity {
    private ItemStack fishStack = ItemStack.EMPTY;
    private int rotation;
    public TrophyBaseBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        BigFishMod.LOGGER.debug("Created TrophyBaseBlockEntity at {}", pos);
    }
    public TrophyBaseBlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.TROPHY_BASE.get(), pos, state);
        BigFishMod.LOGGER.debug("Created TrophyBaseBlockEntity at {}", pos);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, TrophyBaseBlockEntity blockEntity) {
        // 可以留空或添加逻辑
    }
    public boolean hasFish() {
        return !fishStack.isEmpty();
    }
    public boolean isEmpty() {
        return fishStack.isEmpty();
    }
    public void setFishStack(ItemStack stack) {
        this.fishStack = stack.copy();
        this.fishStack.setCount(1);
        setChanged();
    }
    public ItemStack removeFish() {
        ItemStack stack = fishStack.copy();
        fishStack = ItemStack.EMPTY;
        setChanged();
        return stack;
    }
    public ItemStack getFishStack() {
        return fishStack;
    }
    public void setRotation(int rotation) {
        // 带状态变化的日志
        if (this.rotation != rotation) {
            LogUtil.debug("trophybase.rotation",
                    () -> "Rotation changed from " + this.rotation + " to " + rotation + " at " + worldPosition
            );
        }
        this.rotation = rotation % 360;
        setChanged();
    }

    public int getRotation() {
        return rotation;
    }

    public float getScale() {
        if (fishStack.hasTag()) {
            CompoundTag tag = fishStack.getTag();
            if (tag != null && tag.contains("FishLevel")) {
                int level = tag.getInt("FishLevel");
                // 确保最小可见尺寸
                return Math.max(0.8f, 0.8f + level * 0.05f);
            }
        }
        return 1.0f;
    }
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (!fishStack.isEmpty()) {
            tag.put("FishItem", fishStack.save(new CompoundTag()));
        }
        tag.putInt("Rotation", rotation);
    }
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains("FishItem")) {
            fishStack = ItemStack.of(tag.getCompound("FishItem"));
        } else {
            fishStack = ItemStack.EMPTY;
        }
        rotation = tag.getInt("Rotation");
        BigFishMod.LOGGER.debug("Loaded TrophyBaseBlockEntity at {} with fish: {}", worldPosition, fishStack);
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        if (pkt.getTag() != null) {
            load(pkt.getTag());
            if (level != null && level.isClientSide) {
                level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), Block.UPDATE_ALL);
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }
}