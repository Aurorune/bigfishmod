package net.aurorune.bigfishmod.capabilities;

import net.minecraft.nbt.CompoundTag;

//耐力
public class PlayerStamina {
    private int stamina = 100;
    private final int MIN_STAMINA = 0;
    private int maxStamina = 100;
    // 获取当前耐力值
    public int getStamina(){
        return stamina;
    }
    public int getMaxStamina() {
        return maxStamina;
    }
    // 设置最大耐力值（装备/效果调用）
    public void setMaxStamina(int max) {
        this.maxStamina = Math.max(MIN_STAMINA + 1, max);
        // 确保当前耐力不超过新上限
        this.stamina = Math.min(stamina, maxStamina);
    }
    public void addStamina(int add){
        this.stamina = Math.min(stamina +add, maxStamina);
    }
    public int subStamina(int sub){
        int actualReduction = Math.min(sub, stamina);
        this.stamina = Math.max(stamina - sub, MIN_STAMINA);
        return actualReduction;
    }
    public void copyFrom(PlayerStamina source){
        this.stamina = source.stamina;
        this.maxStamina = source.maxStamina;
    }
    public void saveNBTData(CompoundTag nbt){
        nbt.putInt("stamina",stamina);
        nbt.putInt("maxStamina", maxStamina);
    }
    public void loadNBTData(CompoundTag nbt){
        stamina = nbt.getInt("stamina");
        maxStamina = nbt.getInt("maxStamina");
    }

}
