package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.datagen.provider.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Mod.EventBusSubscriber(modid = BigFishMod.MOD_ID,bus = Mod.EventBusSubscriber.Bus.MOD)

public class DataGenerators {
    @SubscribeEvent
    public static void gatherData(GatherDataEvent event){
        DataGenerator generator = event.getGenerator();
        PackOutput output = generator.getPackOutput();
        CompletableFuture<HolderLookup.Provider> lookupProvider = event.getLookupProvider();
        ExistingFileHelper helper = event.getExistingFileHelper();

        generator.addProvider(event.includeClient(),new ModItemModelGen(output,helper));
        generator.addProvider(event.includeClient(),new ModLangGen(output,"en_us"));
        generator.addProvider(event.includeClient(), new ModLangGen(output, "zh_cn"));
        generator.addProvider(event.includeClient(),new ModBlockModelGen(output,helper));
        // 先创建方块标签生成器并保存为变量
        ModBlockTagsProvider blockTagsGen = new ModBlockTagsProvider(output,lookupProvider,helper);
        generator.addProvider(event.includeServer(), blockTagsGen);
        // 然后使用这个变量创建物品标签生成器
        generator.addProvider(event.includeServer(),
                new ModItemTagsGen(output, lookupProvider, blockTagsGen.contentsGetter(), helper));
        generator.addProvider(event.includeServer(),new ModRecipesGen(output));
        generator.addProvider(event.includeServer(), new LootTableProvider(output, Collections.emptySet(),
                List.of(
                        new LootTableProvider.SubProviderEntry(ModLootTableGen::new, LootContextParamSets.BLOCK),
                        new LootTableProvider.SubProviderEntry(ModLootTableProvider.FishingLoot::new, LootContextParamSets.FISHING)
                )));
        generator.addProvider(event.includeServer(),new ModPlaceableTagProvider(output,lookupProvider,helper));
        generator.addProvider(event.includeServer(),new ModPoiTypeTagProvider(output,lookupProvider,helper));
        generator.addProvider(event.includeServer(),new ModWorldGen(output,lookupProvider));
        generator.addProvider(event.includeServer(), new ModBiomeModifiersProvider(output, lookupProvider, helper));
    }
}