package net.aurorune.bigfishmod.config;

import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.*;

public class FishDecomposingConfig {
    private static final Map<String, DecomposeRecipe> CUSTOM_FISH_RECIPES = new HashMap<>();
    private static final Map<Item, DecomposeRecipe> VANILLA_FISH_RECIPES = new HashMap<>();

    // 分解配方类
    public static class DecomposeRecipe {
        private final List<ItemResult> results;
        private final boolean levelScaling; // 是否启用等级缩放

        public DecomposeRecipe(List<ItemResult> results, boolean levelScaling) {
            this.results = results;
            this.levelScaling = levelScaling;
        }

        public List<ItemResult> getResults() {
            return results;
        }

        public boolean hasLevelScaling() {
            return levelScaling;
        }
    }

    // 物品结果类
    public static class ItemResult {
        private final Item item;
        private final int baseAmount;
        private final float probability;
        private final int minAmount;
        private final int maxAmount;
        private final int minFishLevel;

        public ItemResult(Item item, int minAmount, int maxAmount, float probability, int minFishLevel) {
            this.item = item;
            this.baseAmount = minAmount;
            this.minAmount = minAmount;
            this.maxAmount = maxAmount;
            this.probability = probability;
            this.minFishLevel = minFishLevel;
        }

        // 默认构造，支持不指定最低等级
        public ItemResult(Item item, int baseAmount, float probability) {
            this(item, baseAmount, baseAmount, probability, 1); // 默认最低等级为1
        }

        public Item getItem() { return item; }
        public int getBaseAmount() { return baseAmount; }
        public float getProbability() { return probability; }
        public int getMinAmount() { return minAmount; }
        public int getMaxAmount() { return maxAmount; }
        public int getMinFishLevel() { return minFishLevel; }

        // 获取随机数量
        public int getRandomAmount(RandomSource random) {
            if (minAmount == maxAmount) return minAmount;
            return minAmount + random.nextInt(maxAmount - minAmount + 1);
        }
    }

    static {
        initCustomFishRecipes();
        initVanillaFishRecipes();
    }

    private static void initCustomFishRecipes() {
        // TESTFISH 分解配方 - 第一级分解（NBT鱼 → 无NBT鱼 + 特殊物品）
        List<ItemResult> testfishResults = Arrays.asList(
                new ItemResult(ModItems.TESTFISH_ITEM.get(), 1, 1, 1.0f, 15), // 1个TESTFISH，100%概率，最低15级
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 3, 0.8f, 15)// 1-2个骨粉，80%概率
        );
        CUSTOM_FISH_RECIPES.put("testfish", new DecomposeRecipe(testfishResults, true));
        // LOACH 分解配方
        List<ItemResult> loachResults = Arrays.asList(
                new ItemResult(ModItems.LOACH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,2, 0.8f, 15)
        );
        CUSTOM_FISH_RECIPES.put("loach", new DecomposeRecipe(loachResults, true));
        // MINNOW 分解配方
        List<ItemResult> minnowResults = Arrays.asList(
                new ItemResult(ModItems.MINNOW_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,2, 0.8f, 15)
        );
        CUSTOM_FISH_RECIPES.put("minnow", new DecomposeRecipe(minnowResults, true));
        // PIRANHA 分解配方
        List<ItemResult> piranhaResults = Arrays.asList(
                new ItemResult(ModItems.PIRANHA_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 3, 0.9f, 15)
        );
        CUSTOM_FISH_RECIPES.put("piranha", new DecomposeRecipe(piranhaResults, true));
        // SARDINE 分解配方
        List<ItemResult> sardineResults = Arrays.asList(
                new ItemResult(ModItems.SARDINE_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,2, 0.6f, 15),
                new ItemResult(ModItems.SHARP_FISH_TOOTH.get(), 1,2, 0.5f, 25) // 10级以上才掉落鱼油
        );
        CUSTOM_FISH_RECIPES.put("sardine", new DecomposeRecipe(sardineResults, true));
        // PLECOSTOMUS 分解配方
        List<ItemResult> plecostomusResults = Arrays.asList(
                new ItemResult(ModItems.PLECOSTOMUS_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 3, 0.8f, 15)
        );
        CUSTOM_FISH_RECIPES.put("plecostomus", new DecomposeRecipe(plecostomusResults, true));
        // BELUGA_STURGEON 分解配方（高级鱼类）
        List<ItemResult> belugaSturgeonResults = Arrays.asList(
                new ItemResult(ModItems.BELUGA_STURGEON_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.BLACK_CAVIAR.get(), 1, 3, 0.6f, 25), // 5级以上才掉落鱼子酱
                new ItemResult(Items.BONE_MEAL, 2, 6, 0.9f, 15),
                new ItemResult(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.PUTRID_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.LUCKY_STAR.get(), 1,1, 0.3f, 35),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(ModItems.BLACK_CAVIAR.get(), 1,3, 0.5f, 25)
        );
        CUSTOM_FISH_RECIPES.put("beluga_sturgeon", new DecomposeRecipe(belugaSturgeonResults, true));
        // NILE_PERCH 分解配方（中级鱼类）
        List<ItemResult> nilePerchResults = Arrays.asList(
                new ItemResult(ModItems.NILE_PERCH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 4, 0.8f, 15),
                new ItemResult(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.PUTRID_GLAND.get(), 1,1, 0.3f, 30)
        );
        CUSTOM_FISH_RECIPES.put("nile_perch", new DecomposeRecipe(nilePerchResults, true));
        // MEKONG_GIANT_CATFISH 分解配方（大型鱼类）
        List<ItemResult> mekongCatfishResults = Arrays.asList(
                new ItemResult(ModItems.MEKONG_GIANT_CATFISH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 3, 5, 1.0f, 15),
                new ItemResult(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.PUTRID_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.ANCIENT_GASTROLITH.get(), 1,1, 0.3f, 35) ,
                new ItemResult(ModItems.CONCEBTRATED_PHEROMONER.get(), 2,4, 0.8f, 20)
        );
        CUSTOM_FISH_RECIPES.put("mekong_giant_catfish", new DecomposeRecipe(mekongCatfishResults, true));
        // TILAPIA 分解配方
        List<ItemResult> tilapiaResults = Arrays.asList(
                new ItemResult(ModItems.TILAPIA_ITEM.get(), 1, 3, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 3,0.5f, 15)
        );
        CUSTOM_FISH_RECIPES.put("tilapia", new DecomposeRecipe(tilapiaResults, true));
        // GUPPY 分解配方（小型观赏鱼）
        List<ItemResult> guppyResults = Arrays.asList(
                new ItemResult(ModItems.GUPPY_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,1, 0.3f, 15)
        );
        CUSTOM_FISH_RECIPES.put("guppy", new DecomposeRecipe(guppyResults, true));
        // SAILFISH 分解配方（高速鱼类）
        List<ItemResult> sailfishResults = Arrays.asList(
                new ItemResult(ModItems.SAILFISH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 2, 3, 0.9f, 15),
                new ItemResult(ModItems.SWORDFISH_BILL.get(), 0,1, 0.5f, 35),
                new ItemResult(ModItems.SEA_BREEZE_ESSENCE.get(), 1,1, 0.3f, 35) ,
                new ItemResult(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.PUTRID_GLAND.get(), 1,1, 0.3f, 30)
        );
        CUSTOM_FISH_RECIPES.put("sailfish", new DecomposeRecipe(sailfishResults, true));
        // HADDOCK 分解配方
        List<ItemResult> haddockResults = Arrays.asList(
                new ItemResult(ModItems.HADDOCK_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 2, 4, 0.7f, 15),
                new ItemResult(ModItems.FISH_OIL.get(), 1,3, 0.7f, 25) // 10级以上才掉落鱼牙
        );
        CUSTOM_FISH_RECIPES.put("haddock", new DecomposeRecipe(haddockResults, true));
        // NORTHERN_PIKE 分解配方（捕食鱼类）
        List<ItemResult> northernPikeResults = Arrays.asList(
                new ItemResult(ModItems.NORTHERN_PIKE_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 3, 0.7f, 15),
                new ItemResult(ModItems.SHARP_FISH_TOOTH.get(), 1,3, 0.6f, 25)
        );
        CUSTOM_FISH_RECIPES.put("northern_pike", new DecomposeRecipe(northernPikeResults, true));
        // SIAMESE_FIGHTING_FISH 分解配方（观赏鱼）
        List<ItemResult> siameseFightingFishResults = Arrays.asList(
                new ItemResult(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,1,0.4f, 15)
        );
        CUSTOM_FISH_RECIPES.put("siamese_fighting_fish", new DecomposeRecipe(siameseFightingFishResults, true));

        // LANTERNFISH 分解配方（深海鱼）
        List<ItemResult> lanternfishResults = Arrays.asList(
                new ItemResult(ModItems.LANTERNFISH_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1,1, 0.3f, 15)
        );
        CUSTOM_FISH_RECIPES.put("lanternfish", new DecomposeRecipe(lanternfishResults, true));
        // ATLANTIC_BLUEFIN_TUNA 分解配方（顶级鱼类）
        List<ItemResult> atlanticBluefinTunaResults = Arrays.asList(
                new ItemResult(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get(), 1, 1, 1.0f, 15),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 3, 5, 1.0f, 15),
                new ItemResult(ModItems.OCEAN_GEM.get(), 1,1, 0.3f, 35) ,
                new ItemResult(ModItems.ACTIVE_SWIM_BLADDER_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.PUTRID_GLAND.get(), 1,1, 0.3f, 30),
                new ItemResult(ModItems.FISH_OIL.get(), 2,4, 0.8f, 20)
        );
        CUSTOM_FISH_RECIPES.put("atlantic_bluefin_tuna", new DecomposeRecipe(atlanticBluefinTunaResults, true));

        // GRASS_CARP 分解配方
        List<ItemResult> grassCarpResults = Arrays.asList(
                new ItemResult(ModItems.GRASS_CARP_ITEM.get(), 1, 1, 1.0f, 1),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 2, 0.7f, 1),
                new ItemResult(ModItems.ACERATED_SEAWEED.get(), 1,3, 0.7f, 20) // 10级以上才掉落水滴
        );
        CUSTOM_FISH_RECIPES.put("grass_carp", new DecomposeRecipe(grassCarpResults, true));
        // ARCHER_FISH 分解配方（特殊技能鱼）
        List<ItemResult> archerFishResults = Arrays.asList(
                new ItemResult(ModItems.ARCHER_FISH_ITEM.get(), 1, 1, 1.0f, 1),
                new ItemResult(ModItems.ROE.get(), 1,3, 0.3f, 30),
                new ItemResult(Items.BONE_MEAL, 1, 0.6f),
                new ItemResult(ModItems.WATER_DROPLET.get(), 1,4, 0.6f, 10)
        );
        CUSTOM_FISH_RECIPES.put("archer_fish", new DecomposeRecipe(archerFishResults, true));
    }
    private static void initVanillaFishRecipes() {
        // 小鱼（100% 1种1个）
        VANILLA_FISH_RECIPES.put(ModItems.TESTFISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f) // 100%概率获得1个鱼片A
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.LOACH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f) // 100%概率获得1个鱼片B
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.MINNOW_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.GUPPY_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.SIAMESE_FIGHTING_FISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.LANTERNFISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 1.0f)
        ), false));

        // 中鱼（1-2种，每种1-2个）
        VANILLA_FISH_RECIPES.put(ModItems.PIRANHA_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 2, 1.0f, 1) // 1-2个鱼片B
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.SARDINE_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 2, 1.0f, 1) // 1-2个鱼片A
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.TILAPIA_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.HADDOCK_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.NORTHERN_PIKE_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.ARCHER_FISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.FISH_FILLET_A.get(), 1, 2, 1.0f, 1)
        ), false));

        // 大鱼（2种，每种2-3个）
        VANILLA_FISH_RECIPES.put(ModItems.PLECOSTOMUS_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 1, 2, 0.8f, 1),
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.BELUGA_STURGEON_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.BELUGA_STURGEON_MEAT.get(), 1, 2, 1.0f, 1),
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 1, 2, 0.8f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.NILE_PERCH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.PERCH_FILLET.get(), 1, 2, 0.6f, 1),
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.MEKONG_GIANT_CATFISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 2, 3, 1.0f, 1),
                new ItemResult(ModItems.FISH_FILLET_A.get(), 2, 3, 1.0f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.GRASS_CARP_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 1, 2, 0.6f, 1),
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 2, 1.0f, 1)
        ), false));

        // 顶级鱼（3种鱼排，每种2-4个）
        VANILLA_FISH_RECIPES.put(ModItems.ATLANTIC_BLUEFIN_TUNA_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.PRIME_TUNA_MEAT.get(), 1, 4, 1f, 1),
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 1, 3, 0.8f, 1),
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 3, 0.8f, 1)
        ), false));

        VANILLA_FISH_RECIPES.put(ModItems.SAILFISH_ITEM.get(), new DecomposeRecipe(Arrays.asList(
                new ItemResult(ModItems.SAILFISH_STEAK.get(), 1, 4, 1.0f, 1),
                new ItemResult(ModItems.BULK_FISH_MEAT.get(), 1, 3, 0.8f, 1),
                new ItemResult(ModItems.FISH_FILLET_B.get(), 1, 3, 0.8f, 1)
        ), false));
    }

    // 获取自定义鱼类分解结果（简化版，不需要Level和BlockPos）
    public static List<ItemStack> getDecomposeResults(String fishType, int fishLevel, RandomSource random) {
        DecomposeRecipe recipe = CUSTOM_FISH_RECIPES.get(fishType);
        if (recipe == null) return new ArrayList<>();
        return processRecipe(recipe, fishLevel, random);
    }

    // 获取原版鱼类分解结果 - 支持批量处理
    public static List<ItemStack> getDecomposeResults(Item fishItem, int quantity, RandomSource random) {
        DecomposeRecipe recipe = VANILLA_FISH_RECIPES.get(fishItem);
        if (recipe == null) return new ArrayList<>();

        List<ItemStack> totalResults = new ArrayList<>();

        // 对每个鱼分别计算结果
        for (int i = 0; i < quantity; i++) {
            List<ItemStack> singleResult = processRecipe(recipe, 1, random);
            // 合并结果
            mergeItemStacks(totalResults, singleResult);
        }

        return totalResults;
    }
    private static void mergeItemStacks(List<ItemStack> targetList, List<ItemStack> sourceList) {
        for (ItemStack newStack : sourceList) {
            if (newStack.isEmpty()) continue;

            boolean merged = false;
            // 尝试与现有物品堆叠
            for (ItemStack existingStack : targetList) {
                if (ItemStack.isSameItemSameTags(existingStack, newStack)) {
                    int maxStackSize = existingStack.getMaxStackSize();
                    int currentAmount = existingStack.getCount();
                    int newAmount = newStack.getCount();
                    int totalAmount = currentAmount + newAmount;

                    if (totalAmount <= maxStackSize) {
                        // 可以完全合并
                        existingStack.setCount(totalAmount);
                        merged = true;
                        break;
                    } else {
                        // 部分合并，填满现有堆叠
                        existingStack.setCount(maxStackSize);
                        newStack.setCount(totalAmount - maxStackSize);
                        // 剩余部分会在下面作为新堆叠添加
                    }
                }
            }

            // 如果没有合并或者有剩余，添加为新堆叠
            if (!merged) {
                targetList.add(newStack.copy());
            }
        }
    }
    // 保持向后兼容的单个处理方法
    public static List<ItemStack> getDecomposeResults(Item fishItem, RandomSource random) {
        return getDecomposeResults(fishItem, 1, random);
    }

    // 处理配方逻辑（删除了经验相关处理）
    private static List<ItemStack> processRecipe(DecomposeRecipe recipe, int fishLevel, RandomSource random) {
        List<ItemStack> results = new ArrayList<>();

        for (ItemResult itemResult : recipe.getResults()) {
            // 如果鱼的等级小于掉落物的最低等级，跳过该奖励
            if (fishLevel < itemResult.getMinFishLevel()) {
                continue;
            }

            // 概率检查
            if (random.nextFloat() > itemResult.getProbability()) {
                continue;
            }

            // 计算数量
            int amount = itemResult.getRandomAmount(random);

            // 等级缩放：从该物品的最低掉落等级开始计算
            if (recipe.hasLevelScaling() && fishLevel > itemResult.getMinFishLevel()) {
                int levelDifference = fishLevel - itemResult.getMinFishLevel();
                int levelBonus = levelDifference / 15;
                amount += levelBonus;
            }

            if (amount > 0) {
                results.add(new ItemStack(itemResult.getItem(), amount));
            }
        }
        return results;
    }

    // 检查是否可以分解
    public static boolean canDecompose(ItemStack stack) {
        if (stack.isEmpty()) return false;

        if (stack.getItem() instanceof CustomFishTrophyItem) {
            CustomFishTrophyItem fishItem = (CustomFishTrophyItem) stack.getItem();
            return CUSTOM_FISH_RECIPES.containsKey(fishItem.getCustomFishType());
        }
        return VANILLA_FISH_RECIPES.containsKey(stack.getItem());
    }

    // 添加新的自定义鱼类配方（运行时添加）
    public static void addCustomFishRecipe(String fishType, DecomposeRecipe recipe) {
        CUSTOM_FISH_RECIPES.put(fishType, recipe);
    }

    // 添加新的原版鱼类配方
    public static void addVanillaFishRecipe(Item item, DecomposeRecipe recipe) {
        VANILLA_FISH_RECIPES.put(item, recipe);
    }
}