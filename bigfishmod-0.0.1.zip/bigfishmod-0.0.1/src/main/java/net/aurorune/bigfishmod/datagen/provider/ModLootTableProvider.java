package net.aurorune.bigfishmod.datagen.provider;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.SetFishNbtFunction;
import net.minecraft.advancements.critereon.LocationPredicate;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootTableReference;
import net.minecraft.world.level.storage.loot.functions.SetNbtFunction;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.predicates.LocationCheck;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

import java.util.Collections;
import java.util.List;
import java.util.function.BiConsumer;

public class ModLootTableProvider extends LootTableProvider {
    public ModLootTableProvider(PackOutput output) {
        super(output, Collections.emptySet(), List.of(
                new LootTableProvider.SubProviderEntry(FishingLoot::new, LootContextParamSets.FISHING),
                new LootTableProvider.SubProviderEntry(BlockLoot::new, LootContextParamSets.BLOCK) // 添加方块战利品
        ));
    }

    public static class FishingLoot implements LootTableSubProvider {
        private static final ResourceLocation VANILLA_FISHING = BuiltInLootTables.FISHING;

        @Override
        public void generate(BiConsumer<ResourceLocation, LootTable.Builder> consumer) {
            // 主钓鱼战利品表
            consumer.accept(VANILLA_FISHING, createMainFishingTable());

            // 鱼类子表
            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/fish"),
                    createFishSubTable()
            );

            // 垃圾子表
            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/junk"),
                    createJunkSubTable()
            );

            // 宝藏子表
            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/treasure"),
                    createTreasureSubTable()
            );

            // MOD鱼类总表
            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/mod_fish"),
                    createModFishTable()
            );

            // 不同水系的鱼类子表
            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/river_fish"),
                    createRiverFishTable()
            );

            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/ocean_fish"),
                    createOceanFishTable()
            );

            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/swamp_fish"),
                    createSwampFishTable()
            );

            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/jungle_fish"),
                    createJungleFishTable()
            );

            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/cold_ocean_fish"),
                    createColdOceanFishTable()
            );

            consumer.accept(
                    ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/deep_ocean_fish"),
                    createDeepOceanFishTable()
            );
        }

        // ==================== 主钓鱼表 ====================
        private LootTable.Builder createMainFishingTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .name("main")
                            .setRolls(ConstantValue.exactly(1))

                            // 宝藏（受海之眷顾影响）
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/treasure"))
                                    .setWeight(5)
                                    .setQuality(2)
                            )

                            // 垃圾（受海之眷顾负面影响）
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/junk"))
                                    .setWeight(10)
                                    .setQuality(-2)
                            )

                            // 鱼类（主要掉落）
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/fish"))
                                    .setWeight(85)
                                    .setQuality(-1)
                            )
                    );
        }

        // ==================== 鱼类总表 ====================
        private LootTable.Builder createFishSubTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))

                            // 原版鱼
                            .add(LootItem.lootTableItem(Items.COD).setWeight(30))
                            .add(LootItem.lootTableItem(Items.SALMON).setWeight(15))
                            .add(LootItem.lootTableItem(Items.TROPICAL_FISH).setWeight(2))
                            .add(LootItem.lootTableItem(Items.PUFFERFISH).setWeight(8))

                            // MOD鱼类
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/mod_fish"))
                                    .setWeight(150)
                            )
                    );
        }

        // ==================== MOD鱼类总表（按水系分发） ====================
        private LootTable.Builder createModFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))

                            // 河流鱼类
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/river_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.RIVER)
                                    ))
                            )

                            // 冻河
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/river_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.FROZEN_RIVER)
                                    ))
                            )

                            // 海洋鱼类
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.OCEAN)
                                    ))
                            )

                            // 温暖海洋
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.WARM_OCEAN)
                                    ))
                            )

                            // 温和海洋
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.LUKEWARM_OCEAN)
                                    ))
                            )

                            // 寒冷海洋
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/cold_ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.COLD_OCEAN)
                                    ))
                            )

                            // 冰冻海洋
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/cold_ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.FROZEN_OCEAN)
                                    ))
                            )

                            // 深海
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/deep_ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.DEEP_OCEAN)
                                    ))
                            )

                            // 寒冷深海
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/deep_ocean_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.DEEP_COLD_OCEAN)
                                    ))
                            )

                            // 沼泽
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/swamp_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.SWAMP)
                                    ))
                            )

                            // 红树林沼泽
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/swamp_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.MANGROVE_SWAMP)
                                    ))
                            )

                            // 丛林
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/jungle_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.JUNGLE)
                                    ))
                            )

                            // 稀疏丛林
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/jungle_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.SPARSE_JUNGLE)
                                    ))
                            )

                            // 竹林
                            .add(LootTableReference.lootTableReference(
                                            ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "gameplay/fishing/jungle_fish"))
                                    .setWeight(1)
                                    .when(LocationCheck.checkLocation(
                                            LocationPredicate.Builder.location()
                                                    .setBiome(Biomes.BAMBOO_JUNGLE)
                                    ))
                            )
                    );
        }

        // ==================== 辅助方法：创建随机鱼类NBT ====================
        private CompoundTag createRandomFishNbt(String fishType, String rarity) {
            CompoundTag tag = new CompoundTag();
            RandomSource rand = RandomSource.create();

            // 根据稀有度设置等级上限和当前等级
            int maxLevel;
            int level;

            switch (rarity) {
                case "common":
                    maxLevel = 15 + rand.nextInt(16); // 15-30
                    level = 1 + rand.nextInt(10); // 1-10级
                    break;
                case "uncommon":
                    maxLevel = 20 + rand.nextInt(21); // 20-40
                    level = 5 + rand.nextInt(16); // 5-20级
                    break;
                case "rare":
                    maxLevel = 30 + rand.nextInt(16); // 30-45
                    level = 10 + rand.nextInt(21); // 10-30级
                    break;
                case "epic":
                    maxLevel = 35 + rand.nextInt(16); // 35-50
                    level = 15 + rand.nextInt(26); // 15-40级
                    break;
                case "legendary":
                    maxLevel = 40 + rand.nextInt(11); // 40-50
                    level = 20 + rand.nextInt(31); // 20-50级
                    break;
                default:
                    maxLevel = 25 + rand.nextInt(16); // 25-40
                    level = 1 + rand.nextInt(20); // 1-20级
            }

            // 计算对应的体型
            int stage = Math.min(level / 5, AbstractCustomFish.STAGES_COUNT - 1);
            float scale = AbstractCustomFish.STAGE_SCALES[stage];

            // 设置随机属性
            float strengthBase = 8 + rand.nextInt(8);
            float strengthGrowth = 0.2f + rand.nextFloat() * 0.4f;
            float staminaBase = 6 + rand.nextInt(8);
            float staminaGrowth = 0.15f + rand.nextFloat() * 0.3f;
            float perceptionBase = 4 + rand.nextInt(10);
            float perceptionGrowth = 0.25f + rand.nextFloat() * 0.35f;
            float luckBase = 3 + rand.nextInt(12);
            float luckGrowth = 0.1f + rand.nextFloat() * 0.5f;
            float weightBase = 0.5f + rand.nextFloat() * 2.0f;
            float weightGrowth = 0.1f + rand.nextFloat() * 0.3f;

            // 设置基础NBT
            tag.putInt("FishLevel", level);
            tag.putFloat("FishScale", scale);
            tag.putInt("FishMaxLevel", maxLevel);
            tag.putBoolean("MaxLevelCapSet", true);
            tag.putInt("MaxLevelCapBackup", maxLevel);

            // 设置属性
            CompoundTag attributesTag = new CompoundTag();
            attributesTag.putFloat("StrBase", strengthBase);
            attributesTag.putFloat("StrGrowth", strengthGrowth);
            attributesTag.putFloat("StamBase", staminaBase);
            attributesTag.putFloat("StamGrowth", staminaGrowth);
            attributesTag.putFloat("PerceptionBase", perceptionBase);
            attributesTag.putFloat("PerceptionGrowth", perceptionGrowth);
            attributesTag.putFloat("LuckBase", luckBase);
            attributesTag.putFloat("LuckGrowth", luckGrowth);
            attributesTag.putFloat("WeightBase", weightBase);
            attributesTag.putFloat("WeightGrowth", weightGrowth);
            tag.put("Attributes", attributesTag);

            return tag;
        }

        // ==================== 河流鱼类 ====================
        private LootTable.Builder createRiverFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(ModItems.LOACH.get()).setWeight(40)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("loach", "common"))))
                            .add(LootItem.lootTableItem(ModItems.MINNOW.get()).setWeight(45)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("minnow", "common"))))
                            .add(LootItem.lootTableItem(ModItems.GRASS_CARP.get()).setWeight(25)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("grasscarp", "uncommon"))))
                            .add(LootItem.lootTableItem(ModItems.NORTHERN_PIKE.get()).setWeight(15)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("northernpike", "rare"))))
                            .add(LootItem.lootTableItem(ModItems.BELUGA_STURGEON.get()).setWeight(2)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("belugasturgeon", "legendary"))))
                    );
        }

        // ==================== 海洋鱼类 ====================
        private LootTable.Builder createOceanFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(ModItems.SARDINE.get()).setWeight(50)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("sardine", "common"))))
                            .add(LootItem.lootTableItem(ModItems.HADDOCK.get()).setWeight(35)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("haddock", "common"))))
                            .add(LootItem.lootTableItem(ModItems.SAILFISH.get()).setWeight(8)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("sailfish", "epic"))))
                            .add(LootItem.lootTableItem(ModItems.ATLANTIC_BLUEFIN_TUNA.get()).setWeight(5)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("atlanticbluefintuna", "legendary"))))
                    );
        }

        // ==================== 寒冷海洋鱼类 ====================
        private LootTable.Builder createColdOceanFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(Items.SALMON).setWeight(40))
                            .add(LootItem.lootTableItem(ModItems.HADDOCK.get()).setWeight(45)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("haddock", "common"))))
                            .add(LootItem.lootTableItem(ModItems.ATLANTIC_BLUEFIN_TUNA.get()).setWeight(10)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("atlanticbluefintuna", "epic"))))
                    );
        }

        // ==================== 深海鱼类 ====================
        private LootTable.Builder createDeepOceanFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(ModItems.LANTERNFISH.get()).setWeight(30)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("lanternfish", "uncommon"))))
                            .add(LootItem.lootTableItem(ModItems.ATLANTIC_BLUEFIN_TUNA.get()).setWeight(15)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("atlanticbluefintuna", "epic"))))
                            .add(LootItem.lootTableItem(ModItems.MEKONG_GIANT_CATFISH.get()).setWeight(3)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("mekonggiantcatfish", "legendary"))))
                    );
        }

        // ==================== 沼泽鱼类 ====================
        private LootTable.Builder createSwampFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(ModItems.PLECOSTOMUS.get()).setWeight(35)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("plecostomus", "common"))))
                            .add(LootItem.lootTableItem(ModItems.TILAPIA.get()).setWeight(40)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("tilapia", "common"))))
                            .add(LootItem.lootTableItem(ModItems.NILE_PERCH.get()).setWeight(12)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("nileperch", "rare"))))
                    );
        }

        // ==================== 丛林鱼类 ====================
        private LootTable.Builder createJungleFishTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(ModItems.PIRANHA.get()).setWeight(30)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("piranha", "uncommon"))))
                            .add(LootItem.lootTableItem(ModItems.ARCHER_FISH.get()).setWeight(25)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("archerfish", "uncommon"))))
                            .add(LootItem.lootTableItem(ModItems.GUPPY.get()).setWeight(40)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("guppy", "common"))))
                            .add(LootItem.lootTableItem(ModItems.SIAMESE_FIGHTING_FISH.get()).setWeight(20)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("siamesefightingfish", "rare"))))
                            .add(LootItem.lootTableItem(ModItems.MEKONG_GIANT_CATFISH.get()).setWeight(2)
                                    .apply(SetNbtFunction.setTag(createRandomFishNbt("mekonggiantcatfish", "legendary"))))
                    );
        }

        // ==================== 垃圾表 ====================
        private LootTable.Builder createJunkSubTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(Items.BOWL).setWeight(10))
                            .add(LootItem.lootTableItem(Items.FISHING_ROD).setWeight(2))
                            .add(LootItem.lootTableItem(Items.LEATHER).setWeight(10))
                            .add(LootItem.lootTableItem(Items.LEATHER_BOOTS).setWeight(10))
                            .add(LootItem.lootTableItem(Items.ROTTEN_FLESH).setWeight(10))
                            .add(LootItem.lootTableItem(Items.STICK).setWeight(5))
                            .add(LootItem.lootTableItem(Items.STRING).setWeight(5))
                            .add(LootItem.lootTableItem(Items.POTION).setWeight(10))
                            .add(LootItem.lootTableItem(Items.BONE).setWeight(10))
                            .add(LootItem.lootTableItem(Items.INK_SAC).setWeight(1))
                            .add(LootItem.lootTableItem(Items.TRIPWIRE_HOOK).setWeight(10))
                            .add(LootItem.lootTableItem(Items.LILY_PAD).setWeight(17))
                    );
        }

        // ==================== 宝藏表 ====================
        private LootTable.Builder createTreasureSubTable() {
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1))
                            .add(LootItem.lootTableItem(Items.NAME_TAG).setWeight(16))
                            .add(LootItem.lootTableItem(Items.SADDLE).setWeight(16))
                            .add(LootItem.lootTableItem(Items.BOW).setWeight(16))
                            .add(LootItem.lootTableItem(Items.FISHING_ROD).setWeight(16))
                            .add(LootItem.lootTableItem(Items.BOOK).setWeight(5))
                            .add(LootItem.lootTableItem(Items.NAUTILUS_SHELL).setWeight(16))
                    );
        }
    }

    public static class BlockLoot extends BlockLootSubProvider {
        protected BlockLoot() {
            super(Collections.emptySet(), FeatureFlags.REGISTRY.allFlags());
        }

        @Override
        protected void generate() {
            // 修改草（grass）的战利品表，让它像小麦种子一样掉落
            this.add(Blocks.GRASS, block ->
                    LootTable.lootTable()
                            // 原版掉落（什么都不掉）
                            .withPool(LootPool.lootPool()
                                    .setRolls(ConstantValue.exactly(1))
                                    .add(LootItem.lootTableItem(Items.WHEAT_SEEDS))
                                    .when(LootItemRandomChanceCondition.randomChance(0.125f)) // 小麦种子概率
                            )
                            // 玉米种子掉落
                            .withPool(LootPool.lootPool()
                                    .setRolls(ConstantValue.exactly(1))
                                    .add(LootItem.lootTableItem(ModItems.CORN_SEED.get()))
                                    .when(LootItemRandomChanceCondition.randomChance(0.125f)) // 12.5%概率
                            )
            );

            // 如果你还想从高草中掉落
            this.add(Blocks.TALL_GRASS, block ->
                    LootTable.lootTable()
                            .withPool(LootPool.lootPool()
                                    .setRolls(ConstantValue.exactly(2))
                                    .add(LootItem.lootTableItem(Items.WHEAT_SEEDS))
                                    .when(LootItemRandomChanceCondition.randomChance(0.125f))
                            )
                            .withPool(LootPool.lootPool()
                                    .setRolls(ConstantValue.exactly(1))
                                    .add(LootItem.lootTableItem(ModItems.CORN_SEED.get()))
                                    .when(LootItemRandomChanceCondition.randomChance(0.125f))
                            )
            );
        }

        @Override
        protected Iterable<Block> getKnownBlocks() {
            return List.of(Blocks.GRASS, Blocks.TALL_GRASS); // 处理草和高草
        }
    }
}