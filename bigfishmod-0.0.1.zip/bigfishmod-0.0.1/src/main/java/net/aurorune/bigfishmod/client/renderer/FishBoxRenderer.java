package net.aurorune.bigfishmod.client.renderer;


import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.aurorune.bigfishmod.block.custom.FishBoxBlock;
import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.aurorune.bigfishmod.client.model.FishBoxModel;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class FishBoxRenderer extends GeoBlockRenderer<FishBoxBlockEntity> {
    private static final ResourceLocation modelResource = ResourceLocation.fromNamespaceAndPath("bigfishmod", "geo/fish_box.geo.json");
    private static final ResourceLocation textureResource = ResourceLocation.fromNamespaceAndPath("bigfishmod", "textures/block/fish_box.png");
    private static final ResourceLocation animationResource = ResourceLocation.fromNamespaceAndPath("bigfishmod", "animations/fish_box.animation.json");

    public FishBoxRenderer(BlockEntityRendererProvider.Context context) {
        super(new FishBoxModel());
    }
    public ResourceLocation getModelResource(FishBoxBlockEntity animatable) {
        return modelResource;
    }
    public ResourceLocation getTextureResource(FishBoxBlockEntity animatable) {
        return textureResource;
    }
    public ResourceLocation getAnimationResource(FishBoxBlockEntity animatable) {
        return animationResource;
    }

    @Override
    public RenderType getRenderType(FishBoxBlockEntity animatable, ResourceLocation texture,
                                    MultiBufferSource bufferSource, float partialTick) {
        return RenderType.entityTranslucent(texture);
    }
    @Override
    public void preRender(PoseStack poseStack, FishBoxBlockEntity animatable,
                          BakedGeoModel model, MultiBufferSource bufferSource,
                          VertexConsumer buffer, boolean isReRender, float partialTick,
                          int packedLight, int packedOverlay, float red, float green,
                          float blue, float alpha) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer,
                isReRender, partialTick, packedLight, packedOverlay,
                red, green, blue, alpha);
    }
}