package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Guppy;
import net.aurorune.bigfishmod.entity.custom.Haddock;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class HaddockGeoModel extends GeoModel<Haddock> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/haddock.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/haddock.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/haddock.animation.json");

    @Override
    public ResourceLocation getModelResource( Haddock object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( Haddock object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( Haddock object) {
        return ANIMATION;
    }

}
