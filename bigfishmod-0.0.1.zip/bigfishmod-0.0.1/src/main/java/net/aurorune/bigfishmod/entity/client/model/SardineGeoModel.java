package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Sardine;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SardineGeoModel extends GeoModel<Sardine> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/sardine.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/sardine.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/sardine.animation.json");

    @Override
    public ResourceLocation getModelResource(Sardine object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Sardine object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Sardine object) {
        return ANIMATION;
    }

}
