package net.aurorune.bigfishmod.api;

import java.util.Base64;

public class TextProtection {
    private static final String SECRET_KEY = "BigFish_Secret_2024"; // 你的密钥

    // 编码文本
    public static String encodeText(String text) {
        StringBuilder encoded = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            char keyChar = SECRET_KEY.charAt(i % SECRET_KEY.length());
            encoded.append((char) (c ^ keyChar));
        }
        return Base64.getEncoder().encodeToString(encoded.toString().getBytes());
    }

    // 解码文本
    public static String decodeText(String encodedText) {
        try {
            String decoded = new String(Base64.getDecoder().decode(encodedText));
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < decoded.length(); i++) {
                char c = decoded.charAt(i);
                char keyChar = SECRET_KEY.charAt(i % SECRET_KEY.length());
                result.append((char) (c ^ keyChar));
            }
            return result.toString();
        } catch (Exception e) {
            return "文本已被篡改！";
        }
    }
}
