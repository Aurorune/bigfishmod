package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.aurorune.bigfishmod.entity.custom.AtlanticBluefinTuna;
import net.aurorune.bigfishmod.entity.custom.GrassCarp;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class GrassCarpGeoModel extends GeoModel<GrassCarp> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/grass_carp.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/grass_carp.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/grass_carp.animation.json");

    @Override
    public ResourceLocation getModelResource( GrassCarp object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource( GrassCarp object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource( GrassCarp object) {
        return ANIMATION;
    }

}
