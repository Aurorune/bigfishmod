package net.aurorune.bigfishmod.client.Handler;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.item.ModItems;
import net.aurorune.bigfishmod.item.custom.CustomFishBucket;
import net.aurorune.bigfishmod.item.custom.CustomFishTrophyItem;
import net.aurorune.bigfishmod.item.custom.WoodenMobBucketItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = BigFishMod.MOD_ID)
public class BucketRetentionHandler {

    @SubscribeEvent
    public static void onItemCrafted(PlayerEvent.ItemCraftedEvent event) {
        ItemStack result = event.getCrafting();
        CraftingContainer craftingInventory = (CraftingContainer) event.getInventory();
        Player player = event.getEntity();

        // 检查是否是鱼桶分解合成（支持铁桶和木桶）
        if (result.getItem() instanceof CustomFishTrophyItem) {
            // 寻找合成网格中的鱼桶
            ItemStack bucketStack = ItemStack.EMPTY;
            for (int i = 0; i < craftingInventory.getContainerSize(); i++) {
                ItemStack stack = craftingInventory.getItem(i);
                if (stack.getItem() instanceof CustomFishBucket || stack.getItem() instanceof WoodenMobBucketItem) {
                    bucketStack = stack;
                    break;
                }
            }

            if (!bucketStack.isEmpty()) {
                // 复制NBT数据到鱼标本
                CompoundTag bucketTag = bucketStack.getTag();
                if (bucketTag != null) {
                    CustomFishTrophyItem.setFishData(
                            result,
                            bucketTag.getInt("FishLevel"),
                            bucketTag.getInt("FishMaxLevel"),
                            bucketTag.getCompound("Attributes")
                    );
                }

                // 根据桶的类型添加对应的桶到玩家背包
                ItemStack returnBucket;
                if (bucketStack.getItem() instanceof CustomFishBucket) {
                    returnBucket = new ItemStack(Items.WATER_BUCKET); // 铁桶返回水桶
                } else {
                    returnBucket = new ItemStack(ModItems.WOODEN_BUCKET.get()); // 木桶返回空木桶
                    returnBucket.getOrCreateTag().putBoolean("HasWater", false);
                }

                if (!player.getInventory().add(returnBucket)) {
                    player.drop(returnBucket, false);
                }
            }
        }
    }
}
