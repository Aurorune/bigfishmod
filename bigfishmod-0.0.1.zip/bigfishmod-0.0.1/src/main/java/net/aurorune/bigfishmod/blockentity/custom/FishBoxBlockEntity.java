package net.aurorune.bigfishmod.blockentity.custom;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.custom.FishBoxBlock;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.aurorune.bigfishmod.client.gui.FishBoxMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.network.NetworkHooks;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;

// FishBoxBlockEntity.java
public class FishBoxBlockEntity extends BlockEntity implements GeoBlockEntity, MenuProvider {
    private final AnimatableInstanceCache animatableCache = GeckoLibUtil.createInstanceCache(this);
    private boolean isOpen = false;
    private int playersUsing = 0;
    private boolean scheduledClose = false;
    // 添加动画状态跟踪
    private boolean animationPlaying = false;
    private String lastAnimation = "";
    private final ItemStackHandler itemHandler = new ItemStackHandler(27) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    public FishBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FISH_BOX.get(), pos, state);
    }
    public IItemHandler getItemHandler() {
        return itemHandler;
    }
    // 修改后的 setOpen 方法 - 处理状态更新和动画触发
    public void setOpen(boolean open) {
        if (this.isOpen != open) {
            // 移除过多的日志输出
            this.isOpen = open;
            lastAnimation = ""; // 重置动画状态，强制触发动画
            
            // 确保方块状态与实体状态一致
            if (level != null) {
                BlockState state = getBlockState();
                
                // 只在服务器端更新方块状态
                if (!level.isClientSide) {
                    if (state.getValue(FishBoxBlock.OPEN) != open) {
                        level.setBlock(worldPosition, state.setValue(FishBoxBlock.OPEN, open), Block.UPDATE_ALL);
                    }
                    
                    // 播放音效
                    SoundEvent sound = open ?
                            SoundEvents.BARREL_OPEN : SoundEvents.BARREL_CLOSE;
                    level.playSound(null, worldPosition, sound, SoundSource.BLOCKS, 0.5F, 1.0F);
                    
                    // 强制同步到客户端
                    setChanged();
                    level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
                    
                    // 显式发送方块实体数据包给附近玩家
                    Packet<?> packet = getUpdatePacket();
                    if (packet != null && level instanceof ServerLevel serverLevel) {
                        serverLevel.getChunkSource().chunkMap.getPlayers(
                            serverLevel.getChunkAt(worldPosition).getPos(), false)
                            .forEach(p -> p.connection.send(packet));
                    }
                } else {
                    // 在客户端，强制重置动画控制器
                    if (animatableCache != null) {
                        try {
                            AnimatableManager<?> manager = animatableCache.getManagerForId(0);
                            if (manager != null) {
                                manager.tryTriggerAnimation("controller");
                            }
                        } catch (Exception e) {
                            BigFishMod.LOGGER.error("FishBox at {}: Error resetting animation controller: {}", 
                                worldPosition, e.getMessage());
                        }
                    }
                }
            }
        }
    }
    // 确保加载时初始化动画状态
    @Override
    public void onLoad() {
        super.onLoad();
        
        // 初始化动画状态
        lastAnimation = isOpen ? "open" : "close";
        
        try {
            // 确保方块状态与实体状态一致
            if (level != null) {
                BlockState state = getBlockState();
                if (state.getValue(FishBoxBlock.OPEN) != isOpen) {
                    // 只在状态不匹配时记录日志
                    if (!level.isClientSide) {
                        // 在服务器端，更新方块状态
                        level.setBlock(worldPosition, state.setValue(FishBoxBlock.OPEN, isOpen), Block.UPDATE_ALL);
                        level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
                    } else {
                        // 在客户端，更新本地视图
                        level.setBlockAndUpdate(worldPosition, state.setValue(FishBoxBlock.OPEN, isOpen));
                    }
                }
            }
        } catch (Exception e) {
            BigFishMod.LOGGER.error("FishBox at {}: Error during onLoad: {}", worldPosition, e.getMessage());
        }
    }
    public boolean isOpen() {
        return isOpen;
    }
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("inventory", itemHandler.serializeNBT());
        tag.putBoolean("isOpen", isOpen);
    }
    
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        boolean oldOpen = isOpen;
        
        if (tag.contains("inventory")) {
            itemHandler.deserializeNBT(tag.getCompound("inventory"));
        }
        
        if (tag.contains("isOpen")) {
            isOpen = tag.getBoolean("isOpen");
        }
        
        // 如果状态发生变化，重置动画状态
        if (oldOpen != isOpen) {
            lastAnimation = "";  // 强制下次状态检测时触发动画
            animationPlaying = false;
        }
    }
    public void incrementPlayersUsing() {
        playersUsing++;
        scheduledClose = false;
        // 确保箱子打开
        if (!isOpen) {
            setOpen(true);
        }
    }
    public void decrementPlayersUsing() {
        if (playersUsing > 0) {
            playersUsing--;
        }
        // 当最后一个玩家关闭界面时，安排延迟关闭
        if (playersUsing == 0 && isOpen && !scheduledClose) {
            if (level != null && !level.isClientSide) {
                level.scheduleTick(worldPosition, getBlockState().getBlock(), 10); // 10 ticks = 0.5秒延迟
                scheduledClose = true;
            }
        }
    }
    // 添加静默设置方法（不播放声音/动画）
    public void setOpenSilently(boolean open) {
        this.isOpen = open;
        this.lastAnimation = open ? "open" : "close"; // 同步动画状态
    }
    public boolean shouldCloseAfterDelay() {
        return playersUsing == 0 && isOpen && scheduledClose;
    }
    // 修复动画控制器逻辑
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        try {
            // 创建一个更高响应性的动画控制器
            AnimationController<FishBoxBlockEntity> controller = new AnimationController<>(
                this, 
                "controller", 
                0, // 过渡时间
                this::predicate
            );
            
            // 设置控制器属性以提高响应性
            controller.setAnimationSpeed(1.0); // 正常速度
            
            // 注册控制器
            controllers.add(controller);
            
            // 移除调试日志
        } catch (Exception e) {
            // 如果注册过程中出现异常，记录错误
            BigFishMod.LOGGER.error("FishBox at {}: Error registering animation controller: {}", 
                worldPosition, e.getMessage());
        }
    }
    
    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> state) {
        // 获取当前控制器状态
        AnimationController.State controllerState = state.getController().getAnimationState();
        
        // 安全地获取当前动画名称
        String currentAnimation = "none";
        try {
            // 尝试使用控制器获取当前动画
            if (state.getController().getCurrentAnimation() != null) {
                currentAnimation = state.getController().getCurrentAnimation().animation().name();
            }
        } catch (Exception e) {
            // 如果出现异常，记录错误并继续
            BigFishMod.LOGGER.error("FishBox at {}: Error getting current animation: {}", worldPosition, e.getMessage());
        }
        
        // 移除每帧都会执行的调试日志
            
        // 处理动画状态变化
        if (isOpen && !"open".equals(lastAnimation)) {
            // 移除不必要的信息日志
            try {
                // 确保动画从头开始播放
                state.getController().forceAnimationReset();
                state.setAnimation(RawAnimation.begin().thenPlay("animation.fish_box.open"));
                lastAnimation = "open";
                animationPlaying = true;
            } catch (Exception e) {
                BigFishMod.LOGGER.error("FishBox at {}: Error setting open animation: {}", 
                    worldPosition, e.getMessage());
            }
            return PlayState.CONTINUE;
        } 
        else if (!isOpen && !"close".equals(lastAnimation)) {
            // 移除不必要的信息日志
            try {
                // 确保动画从头开始播放
                state.getController().forceAnimationReset();
                state.setAnimation(RawAnimation.begin().thenPlay("animation.fish_box.close"));
                lastAnimation = "close";
                animationPlaying = true;
            } catch (Exception e) {
                BigFishMod.LOGGER.error("FishBox at {}: Error setting close animation: {}", 
                    worldPosition, e.getMessage());
            }
            return PlayState.CONTINUE;
        }
        
        // 如果有动画正在播放，继续播放
        if (controllerState == AnimationController.State.RUNNING) {
            return PlayState.CONTINUE;
        }
        
        // 如果动画已经完成但标记为播放中，更新状态
        if (animationPlaying && controllerState == AnimationController.State.STOPPED) {
            // 移除调试日志
            animationPlaying = false;
        }
        
        // 如果没有动画需要播放，保持当前状态
        if (isOpen) {
            // 保持打开状态
            if (!"open".equals(currentAnimation)) {
                // 设置打开动画
                try {
                    state.setAnimation(RawAnimation.begin().thenPlay("animation.fish_box.open"));
                    // 移除调试日志
                } catch (Exception e) {
                    BigFishMod.LOGGER.error("FishBox at {}: Error setting open animation: {}", worldPosition, e.getMessage());
                }
            }
            return PlayState.CONTINUE;
        } else {
            // 保持关闭状态
            if (!"close".equals(currentAnimation) && !"none".equals(currentAnimation)) {
                // 设置关闭动画
                try {
                    state.setAnimation(RawAnimation.begin().thenPlay("animation.fish_box.close"));
                    // 移除调试日志
                } catch (Exception e) {
                    BigFishMod.LOGGER.error("FishBox at {}: Error setting close animation: {}", worldPosition, e.getMessage());
                }
            }
            return PlayState.STOP; // 关闭状态可以停止动画控制器
        }
    }


    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return animatableCache;
    }
    @Override
    public Component getDisplayName() {
        return Component.translatable("container.bigfishmod.fish_box");
    }
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInv, Player player) {
        return new FishBoxMenu(containerId, playerInv, this);
    }
    // 处理方块更新
    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }
    @Override
    public void handleUpdateTag(CompoundTag tag) {
        boolean wasOpen = isOpen;
        super.handleUpdateTag(tag);
        load(tag);
        
        // 客户端接收到更新时处理动画状态
        if (level != null && level.isClientSide) {
            // 移除不必要的信息日志
                
            // 只有当状态实际变化时才重置动画
            if (wasOpen != isOpen) {
                // 移除不必要的信息日志
                lastAnimation = ""; // 强制下次状态检测时触发动画
                animationPlaying = false; // 重置动画播放状态
                
                // 立即触发动画控制器更新
                if (animatableCache != null) {
                    try {
                        AnimatableManager<?> manager = animatableCache.getManagerForId(0);
                        if (manager != null) {
                            // 移除调试日志
                            manager.tryTriggerAnimation("controller");
                        }
                    } catch (Exception e) {
                        BigFishMod.LOGGER.error("FishBox at {}: Error triggering animation controller: {}", 
                            worldPosition, e.getMessage());
                    }
                }
                
                // 确保方块状态与实体状态一致
                BlockState state = getBlockState();
                if (state.getValue(FishBoxBlock.OPEN) != isOpen) {
                    // 移除调试日志
                    level.setBlockAndUpdate(worldPosition, state.setValue(FishBoxBlock.OPEN, isOpen));
                }
            }
        }
    }
    
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        // 创建一个包含所有必要数据的更新数据包
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag); // 确保包含所有状态
        
        // 移除调试日志
        return ClientboundBlockEntityDataPacket.create(this);
    }
}