package net.aurorune.bigfishmod.api;

import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;
import java.util.function.Predicate;

public class SimpleBreedGoal extends Goal {
    private final AbstractCustomFish fish;
    AbstractCustomFish partner;  // 改为包可见
    int loveTicks;              // 改为包可见
    int breedingCooldown;       // 改为包可见
    boolean inLove = false;
    int canUseCheckCooldown = 0; // 包可见，初始为0，表示马上可检查
    // 配置参数
    private static final int MIN_PARENT_LEVEL = 20;
    private static final int BREEDING_COOLDOWN = 24000; // 20分钟冷却
    private static final double MUTATION_CHANCE = 0.05; // 5%突变概率
    private final Predicate<ItemStack> breedingFood;
    private int loveCause;
    private static final float Y_OFFSET = 0.5F; // 垂直方向偏移
    public SimpleBreedGoal(AbstractCustomFish fish, Predicate<ItemStack> breedingFood) {
        this.fish = fish;
        this.breedingFood = breedingFood;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        // 检查冷却时间
        if (breedingCooldown > 0) {
            breedingCooldown--;
            return false;
        }
        boolean shouldUse = false;
        // 2) 节流逻辑：如果节流计数器 > 0，则只做最小检查并返回 false
        if (canUseCheckCooldown > 0) {
            canUseCheckCooldown--;
            return false;
        }
        // 检查等级要求
        if (fish.getLevel() < MIN_PARENT_LEVEL) {
            return false;
        }

        // 只要处于恋爱状态就启动Goal，不管有没有配偶
        shouldUse = isInLove();
        if (shouldUse) {
            // 成功触发一次完整判断后，设置节流，100 ticks = 5 秒（Minecraft 20 tick/s）
            this.canUseCheckCooldown = 100;
        } else {
            // 如果判定不通过，也可以设置一个短节流避免每 tick 刷新（可选）
            // 例如这里我们给 20 ticks 的短节流，减少负担（你可以注释掉下一行以保持每 tick 检查）
            this.canUseCheckCooldown = 20;
        }

        return shouldUse;
    }

    @Override
    public boolean canContinueToUse() {
        // 只要还在恋爱状态且时间未超时就继续
        return this.inLove && this.loveTicks < 600;
    }

    @Override
    public void start() {
        this.loveTicks = 0;
        // 显示爱心粒子效果
        spawnLoveParticles();
    }

    @Override
    public void stop() {
        this.partner = null;
        this.loveTicks = 0;
        this.inLove = false;
    }

    @Override
    public void tick() {
        // 增加求爱时间
        loveTicks++;

        // 每20 ticks（1秒）显示一次爱心粒子 - 无论有没有配偶都显示
        if (this.loveTicks % 5 == 0) {
            this.spawnLoveParticles();
        }

        // 如果没有配偶，继续寻找
        if (partner == null || !partner.isAlive()) {
            partner = findPartner();
            if (partner == null) {
                // 没有配偶时，仍然继续显示爱心粒子，但不进行繁殖行为
                // 如果求爱时间超过30秒，停止
                if (this.loveTicks >= 600) {
                    this.stop();
                }
                return; // 继续等待配偶
            }
        }

        // 有配偶时的行为
        // 看向配偶
        fish.getLookControl().setLookAt(partner, 10.0F, (float) fish.getMaxHeadXRot());

        // 向配偶移动
        if (fish.getNavigation().isDone()) {
            double targetX = partner.getX() + (fish.getRandom().nextDouble() - 0.5D);
            double targetY = partner.getY() + Y_OFFSET;
            double targetZ = partner.getZ() + (fish.getRandom().nextDouble() - 0.5D);
            fish.getNavigation().moveTo(targetX, targetY, targetZ, 1.0D);
        }

        // 如果足够接近且求爱时间足够，开始繁殖
        if (fish.distanceToSqr(partner) < getBreedDistanceSqr() && loveTicks >= 60) {
            breed();
            return;
        }

        // 如果求爱时间超过30秒，停止
        if (this.loveTicks >= 600) {
            this.stop();
        }
    }
    private double getBreedDistanceSqr() {
        // 获取当前鱼的碰撞箱尺寸
        float fishWidth = fish.getBbWidth();
        // 获取伴侣的碰撞箱尺寸
        float partnerWidth = partner.getBbWidth();
        // 距离应该大于两只鱼的平均宽度，以避免碰撞，同时保持足够近
        // 这里我们设置距离为两只鱼平均宽度的一半，然后加上一个常数
        float minDistance = (fishWidth + partnerWidth) / 3.0F + 1.0F; // 0.1F 为一个最小间隙

        return minDistance * minDistance;
    }
    private AbstractCustomFish findPartner() {
        List<AbstractCustomFish> list = fish.level().getEntitiesOfClass(
                AbstractCustomFish.class,
                fish.getBoundingBox().inflate(8.0D),
                this::isSuitablePartner
        );

        double closestDistance = Double.MAX_VALUE;
        AbstractCustomFish closestFish = null;

        for (AbstractCustomFish potentialPartner : list) {
            double distance = fish.distanceToSqr(potentialPartner);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestFish = potentialPartner;
            }
        }

        return closestFish;
    }

    private boolean isSuitablePartner(AbstractCustomFish potentialPartner) {
        // 不能是自己
        if (potentialPartner == fish) {
            return false;
        }

        // 必须是同种类
        if (potentialPartner.getType() != fish.getType()) {
            return false;
        }

        // 必须满足等级要求
        if (potentialPartner.getLevel() < MIN_PARENT_LEVEL) {
            return false;
        }

        // 必须能够繁殖（不在冷却中）
        if (potentialPartner instanceof SimpleBreedGoalAccessor) {
            SimpleBreedGoalAccessor accessor = (SimpleBreedGoalAccessor) potentialPartner;
            if (accessor.getBreedingCooldown() > 0) {
                return false;
            }
        }

        // 关键修改：检查配偶是否也处于恋爱状态
        if (potentialPartner.getBreedGoal() == null || !potentialPartner.getBreedGoal() .isInLove()) {
            return false;
        }

        return true;
    }

    private void spawnLoveParticles() {
        // 确保在服务端执行粒子生成
        if (fish.level() instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel) fish.level();
            RandomSource rand = fish.getRandom();

            // 类似MC原版：每次只生成1-3个爱心粒子
            int particleCount = 1 + rand.nextInt(3); // 1-3个粒子

            for (int i = 0; i < particleCount; ++i) {
                // 更小的随机偏移，让粒子更集中在鱼身边
                double offsetX = (rand.nextDouble() - 0.5D) * 0.5D;
                double offsetY = rand.nextDouble() * 0.3D + 0.2D; // 稍微向上偏移
                double offsetZ = (rand.nextDouble() - 0.5D) * 0.5D;

                // 更小的速度，让粒子飘得更慢
                double velocityX = rand.nextGaussian() * 0.01D;
                double velocityY = rand.nextGaussian() * 0.01D + 0.05D; // 轻微向上飘
                double velocityZ = rand.nextGaussian() * 0.01D;

                serverLevel.sendParticles(
                        ParticleTypes.HEART,
                        fish.getX() + offsetX,
                        fish.getY() + fish.getBbHeight() * 0.5D + offsetY,
                        fish.getZ() + offsetZ,
                        1, // 每次发送1个粒子
                        velocityX, velocityY, velocityZ,
                        0.0D // 额外速度为0
                );
            }
        }}
    private void breed() {
        ServerLevel serverLevel = (ServerLevel) fish.level();
        RandomSource rand = fish.getRandom();

        // 创建后代
        AbstractCustomFish offspring = fish.getBreedOffspring(serverLevel, partner);
        if (offspring == null) {
            return;
        }
        // 保存配偶引用，在重置partner为null之前
        AbstractCustomFish partnerFish = this.partner;
        // 设置冷却时间
        breedingCooldown = BREEDING_COOLDOWN;
        if (partnerFish instanceof SimpleBreedGoalAccessor) {
            ((SimpleBreedGoalAccessor) partnerFish).setBreedingCooldown(BREEDING_COOLDOWN);
        }
        // 1. 设置后代的最大等级限制
        setOffspringMaxLevel(offspring, partnerFish);
        // 2. 遗传属性
        inheritAttributes(offspring, partnerFish);
        // 3. 突变检查
        if (rand.nextDouble() < MUTATION_CHANCE) {
            applyMutation(offspring);
        }

        // 4. 设置后代的位置和状态，并设置一个合理的初始等级
        offspring.moveTo(fish.getX(), fish.getY(), fish.getZ(), 0.0F, 0.0F);
        offspring.setBaby(true);
        // 【关键修改】确保 setLevel() 发生在所有属性设置之后
        offspring.setLevel(1 + rand.nextInt(5));

        // 添加到世界
        serverLevel.addFreshEntity(offspring);

        // 经验奖励
        if (serverLevel.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            serverLevel.addFreshEntity(new ExperienceOrb(
                    serverLevel, fish.getX(), fish.getY(), fish.getZ(),
                    rand.nextInt(7) + 1
            ));
        }

        serverLevel.broadcastEntityEvent(fish, (byte)18);

        // 先重置配偶的恋爱状态（在partner变为null之前）
        SimpleBreedGoal partnerBreedGoal = partnerFish.getBreedGoal();
        if (partnerBreedGoal != null) {
            partnerBreedGoal.partner = null;
            partnerBreedGoal.loveTicks = 0;
            partnerBreedGoal.inLove = false;
        }

        // 最后重置自己的状态
        this.partner = null;
        this.loveTicks = 0;
        this.inLove = false;
    }

    private void inheritAttributes(AbstractCustomFish offspring, AbstractCustomFish partner) {
        RandomSource rand = fish.getRandom();

        // 获取后代的成长上限，用于调整属性遗传
        int offspringMaxLevel = offspring.getMaxLevelCap();
        float potentialMultiplier = offspringMaxLevel / 50.0f; // 基于成长上限的潜力系数

        // 遗传基础属性时考虑成长潜力
        offspring.strengthBase = inheritFloat(
                fish.strengthBase, partner.strengthBase, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f); // 成长上限越高，基础属性越好

        offspring.strengthGrowth = inheritFloat(
                fish.strengthGrowth, partner.strengthGrowth, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);
        offspring.staminaBase = inheritFloat(
                fish.staminaBase, partner.staminaBase, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);
        offspring.staminaGrowth = inheritFloat(
                fish.staminaGrowth, partner.staminaGrowth, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.perceptionBase = inheritFloat(
                fish.perceptionBase, partner.perceptionBase, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.perceptionGrowth = inheritFloat(
                fish.perceptionGrowth, partner.perceptionGrowth, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.luckBase = inheritFloat(
                fish.luckBase, partner.luckBase, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.luckGrowth = inheritFloat(
                fish.luckGrowth, partner.luckGrowth, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.weightBase = inheritFloat(
                fish.weightBase, partner.weightBase, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);

        offspring.weightGrowth = inheritFloat(
                fish.weightGrowth, partner.weightGrowth, 0.05f, 0.15f, rand
        ) * (0.8f + potentialMultiplier * 0.4f);
    }

    private float inheritFloat(float parent1, float parent2, float minVariation, float maxVariation, RandomSource random) {
        float baseValue = (parent1 + parent2) / 2.0F;
        float variation = minVariation + random.nextFloat() * (maxVariation - minVariation);

        if (random.nextBoolean()) {
            return baseValue * (1 + variation);
        } else {
            return baseValue * (1 - variation);
        }
    }

    private void applyMutation(AbstractCustomFish offspring) {
        // 标记为突变体
        offspring.setMutant(true);
        RandomSource rand = fish.getRandom();
        // 幸运值翻倍（实现爆率翻倍）
        offspring.luckBase *= 2.0f;
        offspring.luckGrowth *= 2.0f;

        // 突变特效
        if (fish.level().isClientSide) {
            for (int i = 0; i < 15; i++) {
                fish.level().addParticle(
                        ParticleTypes.GLOW,
                        offspring.getX() + (rand.nextDouble() - 0.5) * offspring.getBbWidth(),
                        offspring.getY() + rand.nextDouble() * offspring.getBbHeight(),
                        offspring.getZ() + (rand.nextDouble() - 0.5) * offspring.getBbWidth(),
                        0.0D, 0.1D, 0.0D
                );
            }
        }
    }

    // 访问器接口，用于跨类访问私有字段
    public interface SimpleBreedGoalAccessor {
        int getBreedingCooldown();
        void setBreedingCooldown(int cooldown);
    }

    public boolean handleInteraction(Player player, ItemStack itemstack) {
        if (this.breedingFood.test(itemstack)) {
            // 先检查条件，只有满足条件才消耗物品
            if (breedingCooldown > 0 || fish.getLevel() < MIN_PARENT_LEVEL) {
                return false; // 条件不满足，不消耗物品
            }

            // 条件满足，消耗物品
            if (!player.getAbilities().instabuild) {
                itemstack.shrink(1);
            }

            // 设置求偶状态
            this.setInLove(player);
            return true;
        }
        return false;
    }
    public void setInLove(@Nullable Player player) {
        // 检查是否在冷却期
        if (breedingCooldown > 0) {
            return; // 在冷却期内，直接返回，不设置恋爱状态也不生成粒子
        }

        // 检查等级要求
        if (fish.getLevel() < MIN_PARENT_LEVEL) {
            return; // 等级不够，不设置恋爱状态
        }

        this.inLove = true; // 设置恋爱状态标记
        this.loveTicks = 0;  // 重置计时器

        if (player != null) {
            this.loveCause = player.getId();
        }

        // 只有成功设置恋爱状态后才生成爱心粒子效果
        spawnLoveParticles();
    }
    public boolean isInLove() {
        // 如果超过30秒，自动重置状态
        if (this.loveTicks >= 600 && this.inLove) {
            this.inLove = false;
            this.loveTicks = 0;
        }
        return this.inLove;
    }

    private void setOffspringMaxLevel(AbstractCustomFish offspring, AbstractCustomFish partner) {
        RandomSource rand = fish.getRandom();

        // 获取父母的等级
        int parent1Level = fish.getLevel();
        int parent2Level = partner.getLevel();

        float averageParentLevel = (parent1Level + parent2Level) / 2.0f;

        float growthPotentialMultiplier;
        float potentialRangeStart = 0.4f;
        float potentialRangeEnd = 1.2f;
        float levelRange = 50.0f - 20.0f; // 30
        // 确保父母等级至少为20，以避免除零错误
        if (averageParentLevel < 20.0f) {
            averageParentLevel = 20.0f;
        }
        // 计算基于父母等级的潜力系数基础值
        float potentialBase = potentialRangeStart +
                (averageParentLevel - 20.0f) * (potentialRangeEnd - potentialRangeStart) / levelRange;
        // 加上随机性，让后代潜力在一定范围内浮动
        float randomVariation = rand.nextFloat() * 0.2f - 0.1f; // -0.1 到 +0.1 的随机变化
        growthPotentialMultiplier = potentialBase + randomVariation;
        // 确保乘数在合理范围内
        growthPotentialMultiplier = Math.max(0.4f, Math.min(growthPotentialMultiplier, 1.3f));
        // 计算后代的最大等级上限
        int offspringMaxLevel = (int) (averageParentLevel * growthPotentialMultiplier);

        // 这里我们使用 Math.max(1, ...) 来确保等级至少为1
        offspringMaxLevel = Math.max(10, Math.min(offspringMaxLevel, 50));
        offspring.setMaxLevelCap(offspringMaxLevel);
    }
}
