package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Minnow;
import net.aurorune.bigfishmod.entity.custom.TestFish;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class MinnowGeoModel extends GeoModel<Minnow> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/minnow.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/minnow.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/minnow.animation.json");

    @Override
    public ResourceLocation getModelResource(Minnow object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Minnow object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Minnow object) {
        return ANIMATION;
    }

}