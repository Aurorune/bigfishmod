package net.aurorune.bigfishmod.entity.client.model;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.entity.custom.Sardine;
import net.aurorune.bigfishmod.entity.custom.Tilapia;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class TilapiaGeoModel extends GeoModel<Tilapia> {
    private static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "geo/tilapia.geo.json");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/tilapia.png");
    private static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "animations/tilapia.animation.json");

    @Override
    public ResourceLocation getModelResource(Tilapia object) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(Tilapia object) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(Tilapia object) {
        return ANIMATION;
    }

}
