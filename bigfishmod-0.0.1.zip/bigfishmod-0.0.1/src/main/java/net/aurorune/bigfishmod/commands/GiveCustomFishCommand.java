package net.aurorune.bigfishmod.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Collection;
import java.util.Random;


public class GiveCustomFishCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("givefish")
                .requires(source -> source.hasPermission(2)) // 需要权限等级2
                .then(Commands.argument("target", EntityArgument.players())
                        .then(Commands.argument("fish_type", StringArgumentType.string())
                                .suggests((context, builder) -> {
                                    // 为鱼类型提供建议 - 使用你的实际mod id
                                    builder.suggest("testfish");
                                    builder.suggest("loach");
                                    builder.suggest("minnow");
                                    builder.suggest("piranha");
                                    builder.suggest("sardine");
                                    builder.suggest("plecostomus");
                                    builder.suggest("beluga_sturgeon");
                                    builder.suggest("nile_perch");
                                    builder.suggest("mekong_giant_catfish");
                                    builder.suggest("tilapia");
                                    builder.suggest("guppy");
                                    builder.suggest("sailfish");
                                    builder.suggest("haddock");
                                    builder.suggest("northern_pike");
                                    builder.suggest("siamese_fighting_fish");
                                    builder.suggest("lanternfish");
                                    builder.suggest("atlantic_bluefin_tuna");
                                    builder.suggest("grass_carp");
                                    builder.suggest("archer_fish");
                                    return builder.buildFuture();
                                })
                                .then(Commands.argument("level", IntegerArgumentType.integer(1, 50))
                                        .executes(context -> giveFish(
                                                context,
                                                EntityArgument.getPlayers(context, "target"),
                                                StringArgumentType.getString(context, "fish_type"),
                                                IntegerArgumentType.getInteger(context, "level")
                                        ))
                                )
                                .executes(context -> giveFish(
                                        context,
                                        EntityArgument.getPlayers(context, "target"),
                                        StringArgumentType.getString(context, "fish_type"),
                                        1 // 默认等级1
                                ))
                        )
                )
        );
    }

    private static int giveFish(CommandContext<CommandSourceStack> context,
                                Collection<ServerPlayer> targets,
                                String fishType,
                                int level) throws CommandSyntaxException {

        ItemStack fishItem = createCustomFishItem(fishType, level);

        if (fishItem.isEmpty()) {
            context.getSource().sendFailure(Component.literal("未知的鱼类类型: " + fishType));
            return 0;
        }

        int count = 0;
        for (ServerPlayer player : targets) {
            // 创建每个玩家的独立副本
            ItemStack playerFishItem = fishItem.copy();
            boolean added = player.getInventory().add(playerFishItem);
            if (added) {
                count++;
                player.inventoryMenu.sendAllDataToRemote();
            }
        }

        if (count > 0) {
            String message = String.format("成功给予 %d 名玩家 %s (等级: %d)",
                    count, getFishDisplayName(fishType), level);
            context.getSource().sendSuccess(() -> Component.literal(message), true);
        } else {
            context.getSource().sendFailure(Component.literal("无法给予物品，玩家背包可能已满"));
        }

        return count;
    }

    private static ItemStack createCustomFishItem(String fishType, int level) {
        ItemStack fishStack = ItemStack.EMPTY;
        Random random = new Random();

        // 根据你的mod id和物品注册名来获取物品
        // 将 "bigfishmod" 替换为你的实际mod id
        String modId = "bigfishmod"; // 替换为你的 MOD_ID

        switch (fishType.toLowerCase()) {
            case "testfish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "testfish"))); // 使用 "testfish" 而不是 "testfish_trophy"
                break;
            case "loach":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "loach")));
                break;
            case "minnow":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "minnow")));
                break;
            case "piranha":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "piranha")));
                break;
            case "sardine":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "sardine")));
                break;
            case "plecostomus":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "plecostomus")));
                break;
            case "beluga_sturgeon":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "beluga_sturgeon")));
                break;
            case "nile_perch":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "nile_perch")));
                break;
            case "mekong_giant_catfish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "mekong_giant_catfish")));
                break;
            case "tilapia":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "tilapia")));
                break;
            case "guppy":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "guppy")));
                break;
            case "sailfish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "sailfish")));
                break;
            case "haddock":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "haddock")));
                break;
            case "northern_pike":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "northern_pike")));
                break;
            case "siamese_fighting_fish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "siamese_fighting_fish")));
                break;
            case "lanternfish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "lanternfish")));
                break;
            case "atlantic_bluefin_tuna":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "atlantic_bluefin_tuna")));
                break;
            case "grass_carp":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "grass_carp")));
                break;
            case "archer_fish":
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, "archer_fish")));
                break;
            default:
                // 尝试从注册表中获取
                fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                        new ResourceLocation(modId, fishType)));
                if (fishStack.isEmpty()) {
                    // 如果还是找不到，尝试使用原版物品
                    fishStack = new ItemStack(ForgeRegistries.ITEMS.getValue(
                            new ResourceLocation(fishType)));
                }
        }

        if (fishStack.isEmpty()) {
            return ItemStack.EMPTY;
        }

        // 为物品添加NBT数据 - 按照你的CustomFishTrophyItem期望的格式
        CompoundTag fishData = new CompoundTag();

        // 基础属性
        fishData.putInt("FishLevel", level);
        fishData.putInt("FishMaxLevel", 50); // 固定最大等级为50

        // 生成随机属性（模拟鱼的随机属性生成）
        CompoundTag attributes = new CompoundTag();

        // 力量属性
        float strengthBase = 8 + random.nextInt(8);
        float strengthGrowth = 0.2f + random.nextFloat() * 0.4f;
        attributes.putFloat("StrBase", strengthBase);
        attributes.putFloat("StrGrowth", strengthGrowth);

        // 耐力属性
        float staminaBase = 6 + random.nextInt(8);
        float staminaGrowth = 0.15f + random.nextFloat() * 0.3f;
        attributes.putFloat("StamBase", staminaBase);
        attributes.putFloat("StamGrowth", staminaGrowth);

        // 感知属性 - 注意：使用PerceptionBase而不是PerceptionBase
        float perceptionBase = 4 + random.nextInt(10);
        float perceptionGrowth = 0.25f + random.nextFloat() * 0.35f;
        attributes.putFloat("PerceptionBase", perceptionBase); // 修正字段名
        attributes.putFloat("PerceptionGrowth", perceptionGrowth); // 修正字段名

        // 运气属性
        float luckBase = 3 + random.nextInt(12);
        float luckGrowth = 0.1f + random.nextFloat() * 0.5f;
        attributes.putFloat("LuckBase", luckBase);
        attributes.putFloat("LuckGrowth", luckGrowth);

        // 重量属性
        float weightBase = 0.5f + random.nextFloat() * 2.0f;
        float weightGrowth = 0.1f + random.nextFloat() * 0.3f;
        attributes.putFloat("WeightBase", weightBase);
        attributes.putFloat("WeightGrowth", weightGrowth);

        fishData.put("Attributes", attributes);

        // 设置自定义显示名称
        CompoundTag displayTag = new CompoundTag();
        String displayName = String.format("{\"text\":\"%s Trophy (Lv.%d)\",\"italic\":false}",
                getFishDisplayName(fishType), level);
        displayTag.putString("Name", displayName);
        fishData.put("display", displayTag);

        // 应用NBT到物品
        fishStack.setTag(fishData);

        return fishStack;
    }

    private static String getFishDisplayName(String fishType) {
        // 简单的格式转换：testfish -> Test Fish
        String[] words = fishType.toLowerCase().split("_");
        StringBuilder displayName = new StringBuilder();

        for (String word : words) {
            if (!word.isEmpty()) {
                displayName.append(word.substring(0, 1).toUpperCase())
                        .append(word.substring(1))
                        .append(" ");
            }
        }
        return displayName.toString().trim();
    }
}
