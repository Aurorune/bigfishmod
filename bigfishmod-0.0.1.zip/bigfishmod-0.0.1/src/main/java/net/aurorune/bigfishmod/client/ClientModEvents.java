package net.aurorune.bigfishmod.client;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.blockentity.ModBlockEntities;
import net.aurorune.bigfishmod.client.gui.FishBoxScreen;
import net.aurorune.bigfishmod.client.gui.ModMenuTypes;
import net.aurorune.bigfishmod.client.renderer.FishBoxRenderer;
import net.aurorune.bigfishmod.client.renderer.TrophyBaseRenderer;
import net.aurorune.bigfishmod.entity.ModEntities;
import net.aurorune.bigfishmod.entity.client.model.*;
import net.aurorune.bigfishmod.entity.client.renderer.GenericFishRenderer;
import net.aurorune.bigfishmod.item.ModItems;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.aurorune.bigfishmod.entity.client.renderer.GenericGeckoFishRenderer;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = BigFishMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // 注册鱼箱GUI屏幕
            MenuScreens.register(
                    ModMenuTypes.FISH_BOX_MENU.get(),
                    FishBoxScreen::new
            );

        });
        registerItemProperties();
    }
    public static void registerItemProperties() {
        ItemProperties.register(
                ModItems.WOODEN_BUCKET.get(),
                ResourceLocation.fromNamespaceAndPath("bigfishmod", "has_water"),
                (stack, level, entity, seed) -> {
                    if (stack != null && !stack.isEmpty() && stack.hasTag()) {
                        CompoundTag tag = stack.getTag();
                        return tag.getBoolean("HasWater") ? 1.0F : 0.0F;
                    }
                    return 0.0F;
                }
        );

        // 调试输出
        System.out.println("Wooden Bucket Item Properties registered successfully");
    }

    // 注册模型层定义
    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
//        event.registerLayerDefinition(ModModelLayers.TESTFISH_LAYER, TestFishModel::createBodyLayer);
        event.registerLayerDefinition(ModModelLayers.LOACH_LAYER, LoachModel::createBodyLayer);
    }
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(
                ModBlockEntities.FISH_BOX.get(),
                FishBoxRenderer::new);
        event.registerBlockEntityRenderer(
                ModBlockEntities.TROPHY_BASE.get(),
                TrophyBaseRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.FISH_BOX.get(), FishBoxRenderer::new);
        event.registerEntityRenderer(ModEntities.THROWN_FEED.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.TESTFISH.get(), context -> {
            TestFishGeoModel geoModel = new TestFishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});
        event.registerEntityRenderer(ModEntities.THROWN_WATER_DROP.get(),
                ThrownItemRenderer::new); // 自带的投掷物渲染器
        event.registerEntityRenderer(ModEntities.RAIN_CLOUD.get(),
                ctx -> new NoopRenderer<>(ctx));
        event.registerEntityRenderer(ModEntities.THROWN_ROE.get(), ThrownItemRenderer::new);

        event.registerEntityRenderer(ModEntities.LOACH.get(), context ->
                new GenericFishRenderer<>(context,
                        new LoachModel<>(context.bakeLayer(ModModelLayers.LOACH_LAYER)),
                        ResourceLocation.fromNamespaceAndPath(BigFishMod.MOD_ID, "textures/entity/fish/loach.png")));

        event.registerEntityRenderer(ModEntities.MINNOW.get(), context -> {
            MinnowGeoModel geoModel = new MinnowGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.PIRANHA.get(), context -> {
            PiranhaGeoModel geoModel = new PiranhaGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.SARDINE.get(), context -> {
            SardineGeoModel geoModel = new SardineGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.PLECOSTOMUS.get(), context -> {
            PlecostomusGeoModel geoModel = new PlecostomusGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.BELUGA_STURGEON.get(), context -> {
            BelugaSturgeonGeoModel geoModel = new BelugaSturgeonGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.NILE_PERCH.get(), context -> {
            NilePerchGeoModel geoModel = new NilePerchGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.MEKONG_GIANT_CATFISH.get(), context -> {
            MekongGiantCatfishGeoModel geoModel = new MekongGiantCatfishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.TILAPIA.get(), context -> {
            TilapiaGeoModel geoModel = new TilapiaGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.GUPPY.get(), context -> {
            GuppyGeoModel geoModel = new GuppyGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.SAILFISH.get(), context -> {
            SailfishGeoModel geoModel = new SailfishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.HADDOCK.get(), context -> {
            HaddockGeoModel geoModel = new HaddockGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.NORTHERN_PIKE.get(), context -> {
            NorthernPikeGeoModel geoModel = new NorthernPikeGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.SIAMESE_FIGHTING_FISH.get(), context -> {
            SiameseFightingFishGeoModel geoModel = new SiameseFightingFishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});
        event.registerEntityRenderer(ModEntities.LANTERNFISH.get(), context -> {
            LanternfishGeoModel geoModel = new LanternfishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.ATLANTIC_BLUEFIN_TUNA.get(), context -> {
            AtlanticBluefinTunaGeoModel geoModel = new AtlanticBluefinTunaGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.GRASS_CARP.get(), context -> {
            GrassCarpGeoModel geoModel = new GrassCarpGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

        event.registerEntityRenderer(ModEntities.ARCHER_FISH.get(), context -> {
            ArcherFishGeoModel geoModel = new ArcherFishGeoModel();
            return new GenericGeckoFishRenderer<>(context, geoModel);});

    }

}