package net.aurorune.bigfishmod.config;

import net.aurorune.bigfishmod.entity.ModEntities;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.world.entity.EntityType;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

public class RoeConfig {
    private static final List<Supplier<? extends EntityType<? extends AbstractCustomFish>>> FISH_TYPES = new ArrayList<>();
    private static final Random RANDOM = new Random();
    // 在 mod 初始化时调用，注册可能孵化的鱼类
    public static void registerFishTypes() {
        FISH_TYPES.add(ModEntities.LOACH::get);
        FISH_TYPES.add(ModEntities.MINNOW::get);
        FISH_TYPES.add(ModEntities.PIRANHA::get);
        FISH_TYPES.add(ModEntities.SARDINE::get);
        FISH_TYPES.add(ModEntities.PLECOSTOMUS::get);
        FISH_TYPES.add(ModEntities.BELUGA_STURGEON::get);
        FISH_TYPES.add(ModEntities.NILE_PERCH::get);
        FISH_TYPES.add(ModEntities.MEKONG_GIANT_CATFISH::get);
        FISH_TYPES.add(ModEntities.TILAPIA::get);
        FISH_TYPES.add(ModEntities.GUPPY::get);
        FISH_TYPES.add(ModEntities.SAILFISH::get);
        FISH_TYPES.add(ModEntities.HADDOCK::get);
        FISH_TYPES.add(ModEntities.LOACH::get);
        FISH_TYPES.add(ModEntities.NORTHERN_PIKE::get);
        FISH_TYPES.add(ModEntities.SIAMESE_FIGHTING_FISH::get);
        FISH_TYPES.add(ModEntities.LANTERNFISH::get);
        FISH_TYPES.add(ModEntities.ATLANTIC_BLUEFIN_TUNA::get);
        FISH_TYPES.add(ModEntities.GRASS_CARP::get);
        FISH_TYPES.add(ModEntities.ARCHER_FISH::get);
    }

    public static EntityType<? extends AbstractCustomFish> getRandomFishType() {
        if (FISH_TYPES.isEmpty()) {
            return null;
        }
        Supplier<? extends EntityType<? extends AbstractCustomFish>> supplier =
                FISH_TYPES.get(RANDOM.nextInt(FISH_TYPES.size()));
        return supplier.get();
    }
}
