package net.aurorune.bigfishmod.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.aurorune.bigfishmod.blockentity.custom.FishBoxBlockEntity;
import net.aurorune.bigfishmod.entity.custom.AbstractCustomFish;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.List;

public class AnimationTestCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("fishschool")
                .then(Commands.literal("enable")
                        .executes(context -> {
                            CommandSourceStack source = context.getSource();
                            Entity entity = source.getEntity();
                            if (entity instanceof Player) {
                                Player player = (Player) entity;
                                List<AbstractCustomFish> nearbyFish = player.level().getEntitiesOfClass(
                                        AbstractCustomFish.class,
                                        player.getBoundingBox().inflate(20),
                                        f -> true
                                );

                                for (AbstractCustomFish fish : nearbyFish) {
                                    fish.enableSchooling(true);
                                }

                                source.sendSuccess(() -> Component.literal("Enabled schooling for " + nearbyFish.size() + " fish"), false);
                            }
                            return 1;
                        })
                )
                .then(Commands.literal("disable")
                        .executes(context -> {
                            CommandSourceStack source = context.getSource();
                            Entity entity = source.getEntity();
                            if (entity instanceof Player) {
                                Player player = (Player) entity;
                                List<AbstractCustomFish> nearbyFish = player.level().getEntitiesOfClass(
                                        AbstractCustomFish.class,
                                        player.getBoundingBox().inflate(20),
                                        f -> true
                                );

                                for (AbstractCustomFish fish : nearbyFish) {
                                    fish.enableSchooling(false);
                                }

                                source.sendSuccess(() -> Component.literal("Disabled schooling for " + nearbyFish.size() + " fish"), false);
                            }
                            return 1;
                        })
                )
        );
    }

}

