package net.aurorune.bigfishmod.datagen;

import net.aurorune.bigfishmod.BigFishMod;
import net.aurorune.bigfishmod.block.custom.CronCropBlock;
import net.aurorune.bigfishmod.block.ModBlocks;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.client.model.generators.*;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.registries.ForgeRegistries;

//方块模型添加
public class ModBlockModelGen extends BlockStateProvider {
    public ModBlockModelGen(PackOutput output, ExistingFileHelper existingFileHelper){
        super(output, BigFishMod.MOD_ID,existingFileHelper);
    }
    @Override
    protected void registerStatesAndModels() {
        this.registerBlockModelAndItem(ModBlocks.GRAPHITE_BLOCK.get());
        this.registerBlockModelAndItem(ModBlocks.DEEPSLATE_GRAPHITE_ORE.get());
        this.registerBlockModelAndItem(ModBlocks.GRAPHITE_ORE.get());
        this.registerTallCrop(ModBlocks.CORN_CROP.get());

    }
    //6面一样方块方法
    public void registerBlockModelAndItem(Block block){
        this.simpleBlockWithItem(block,this.cubeAll(block));
    }

    public void registerTallCrop(Block block) {
        int max_age = CronCropBlock.MAX_AGE;
        MultiPartBlockStateBuilder builder = getMultipartBuilder(block);
        // 底部模型（所有阶段都需要）
        for (int i = 0; i <= max_age; i++) {
            // 创建底部模型文件
            ModelFile bottomModel = models().crop("corn_bottom_stage" + i,
                    cropTextureSuffix(block, "_bottom_stage" + i)).renderType("cutout");
            // 添加底部模型
            builder.part().modelFile(bottomModel)
                    .addModel().condition(CronCropBlock.AGE, i)
                    .condition(CronCropBlock.TOP,false);}
        // 顶部模型（仅阶段4-6）
        for (int i = CronCropBlock.TOP_START_AGE; i <= max_age; i++) {
            // 创建顶部模型文件
            ModelFile topModel = models().crop("corn_top_stage" + i,
                    cropTextureSuffix(block, "_top_stage" + i)).renderType("cutout");
            // 添加顶部模型（使用变换）
            builder.part().modelFile(topModel)
                    .addModel().condition(CronCropBlock.AGE, i)
                    .condition(CronCropBlock.TOP,true);}
    }
    protected int getBonemealAgeIncrease(Level level) {
        // 随机增加2-3岁，确保能跳过TOP_START_AGE
        return  level.random.nextInt(3);
    }

    //7段作物
    public void registerCrop (Block block){
        int max_age = CronCropBlock.MAX_AGE;
        VariantBlockStateBuilder variantBuilder =getVariantBuilder(block);
        ResourceLocation blockKey = ForgeRegistries.BLOCKS.getKey(block);
        String blockName = blockKey.getPath();
        String baseName = blockName.split("_")[0];
        for (int i=0;i<7;i++){
            variantBuilder.partialState().with(CronCropBlock.AGE,i).modelForState()
                    .modelFile(models().crop(baseName+"_stage"+i,cropTextureSuffix(block,"_stage"+i)).renderType("cutout")).addModel();
        }
    }
    private ResourceLocation cropTextureSuffix(Block block, String suffix) {
        ResourceLocation blockKey = ForgeRegistries.BLOCKS.getKey(block);
        String path = blockKey.getPath().split("_")[0] + suffix;
        return  ResourceLocation.fromNamespaceAndPath(
                blockKey.getNamespace(),
                ModelProvider.BLOCK_FOLDER + "/" + path
        );
    }

}
